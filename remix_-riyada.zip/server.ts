import express from 'express';
import path from 'path';
import fs from 'fs';
import pg from 'pg';
import { createServer as createViteServer } from 'vite';
import { ChargilyClient } from '@chargily/chargily-pay';

const { Pool } = pg;

// 1. CONFIG AND STATE
const PORT = Number(process.env.PORT || 3000);

// Support reading from raw .env directly or falling back to .env.example to ensure process.env has complete variables even during complex deployments
try {
  let envPath = path.join(process.cwd(), '.env');
  if (!fs.existsSync(envPath)) {
    const backupPath = path.join(process.cwd(), '.env.example');
    if (fs.existsSync(backupPath)) {
      envPath = backupPath;
    }
  }
  if (fs.existsSync(envPath)) {
    const dotenvContent = fs.readFileSync(envPath, 'utf8');
    const dotenvLines = dotenvContent.split('\n');
    dotenvLines.forEach(line => {
      const match = line.match(/^\s*([\w.\-_]+)\s*=\s*(.*)?\s*$/);
      if (match) {
        const key = match[1];
        let val = (match[2] || '').trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.substring(1, val.length - 1);
        }
        // Only override if not already in process.env or if process.env holds a placeholder, or if the .env value is a solid, non-placeholder credential
        const existing = process.env[key];
        const existingIsPlaceholder = !existing || existing.includes('<PASSWORD>') || existing.includes('<') || existing.includes('[redacted]');
        const valIsPlaceholder = !val || val.includes('<') || val.includes('YOUR_') || val.includes('PLACEHOLDER');
        
        if (!valIsPlaceholder && (existingIsPlaceholder || !existing || existing === 'undefined' || existing === 'null')) {
          process.env[key] = val;
        } else if (!valIsPlaceholder && val !== existing) {
          // If the .env file has a specific real credential, prioritize it over generic system environmental state
          process.env[key] = val;
        }
      }
    });
    console.log(`✅ Synchronized and populated all secure system credentials from ${path.basename(envPath)}.`);
  }
} catch (err: any) {
  console.warn('Failed to load database credentials from local config:', err.message);
}

const AIVEN_POSTGRES_URL = process.env.AIVEN_POSTGRES_URL || 'postgres://avnadmin:AVNS_oQyY0dxjQ7j7XNU1KES@riyada-db-riyada-p.g.aivencloud.com:20118/defaultdb?sslmode=require';
const AIVEN_DB_USER = process.env.AIVEN_DB_USER || 'avnadmin';
const AIVEN_DB_PASSWORD = process.env.AIVEN_DB_PASSWORD || 'AVNS_oQyY0dxjQ7j7XNU1KES';
const AIVEN_DB_HOST = process.env.AIVEN_DB_HOST || 'riyada-db-riyada-p.g.aivencloud.com';
const AIVEN_DB_PORT = process.env.AIVEN_DB_PORT || '20118';
const AIVEN_DB_NAME = process.env.AIVEN_DB_NAME || 'defaultdb';

const CHARGILY_SECRET_KEY = process.env.CHARGILY_SECRET_KEY || 'api_test_dummy_key_riyada';
const ABLY_API_KEY = process.env.VITE_ABLY_API_KEY || 'dummy_ably_key_abc123';

let pool: pg.Pool | null = null;
let dbConnected = false;
let dbError: string | null = null;
let usingSafeModeBackup = false; // Intentionally removed but keep var to avoid breaking other references if missed.
let dbInitPromise: Promise<boolean> | null = null;

async function runQuery(sql: string, params: any[]): Promise<{ rows: any[]; rowCount: number }> {
  if (dbConnected && pool) {
    return new Promise((resolve, reject) => {
      queryQueue.push({
        sql,
        params,
        resolve,
        reject
      });
      processQueue();
    });
  } else {
    throw new Error('Database service is offline or not yet initialized.');
  }
}

interface QueuedQuery {
  sql: string;
  params: any[];
  resolve: (value: { rows: any[]; rowCount: number }) => void;
  reject: (reason: any) => void;
}

const MAX_CONCURRENT_QUERIES = 15;
const queryQueue: QueuedQuery[] = [];
let activeQueriesCount = 0;

function processQueue() {
  if (queryQueue.length === 0 || activeQueriesCount >= MAX_CONCURRENT_QUERIES) {
    return;
  }
  const queued = queryQueue.shift();
  if (!queued) return;

  activeQueriesCount++;
  (async () => {
    try {
      if (pool) {
        const result = await pool.query(queued.sql, queued.params || []);
        queued.resolve({ rows: result.rows, rowCount: result.rowCount || 0 });
      } else {
        throw new Error('Database connection pool is offline.');
      }
    } catch (err: any) {
      queued.reject(err);
    } finally {
      activeQueriesCount--;
      processQueue();
    }
  })();
}

// 2. STABLE CONNECTION POOL INITIALIZATION
// Ensure pool is always initialized to delegate either to standard AIVEN_POSTGRES_URL or granular credentials parameters,
// ensuring robust fallback and prioritizing full connectivity attempts before entering safe mode.
let connectionConfig: any = {};

if (AIVEN_POSTGRES_URL && !AIVEN_POSTGRES_URL.includes('<redacted>')) {
  const cleanedUrl = AIVEN_POSTGRES_URL.includes('?') ? AIVEN_POSTGRES_URL.split('?')[0] : AIVEN_POSTGRES_URL;
  connectionConfig.connectionString = cleanedUrl;
} else if (AIVEN_DB_HOST) {
  connectionConfig.host = AIVEN_DB_HOST;
  connectionConfig.user = AIVEN_DB_USER || 'avnadmin';
  connectionConfig.password = AIVEN_DB_PASSWORD;
  connectionConfig.port = AIVEN_DB_PORT ? parseInt(AIVEN_DB_PORT, 10) : 20118;
  connectionConfig.database = AIVEN_DB_NAME || 'defaultdb';
} else if (AIVEN_POSTGRES_URL && AIVEN_POSTGRES_URL.includes('<redacted>') && AIVEN_DB_PASSWORD) {
  const repairedUrl = AIVEN_POSTGRES_URL.replace('<redacted>', AIVEN_DB_PASSWORD);
  const cleanedUrl = repairedUrl.includes('?') ? repairedUrl.split('?')[0] : repairedUrl;
  connectionConfig.connectionString = cleanedUrl;
}

pool = new Pool({
  ...connectionConfig,
  ssl: {
    rejectUnauthorized: false
  },
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle database client:', err.message);
  dbConnected = false;
});

// Ensure database tables exist safely
function initializeSchemaAndVerify(): Promise<boolean> {
  if (dbInitPromise) return dbInitPromise;

  dbInitPromise = (async () => {
    const schemaSql = `
    CREATE TABLE IF NOT EXISTS workspaces (
        id VARCHAR(100) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(100) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        created_at BIGINT NOT NULL,
        settings JSONB NOT NULL DEFAULT '{}'::jsonb
    );

    CREATE TABLE IF NOT EXISTS products (
        id VARCHAR(100) PRIMARY KEY,
        workspace_id VARCHAR(100) REFERENCES workspaces(id) ON DELETE CASCADE,
        vendor_id VARCHAR(100),
        vendor_name VARCHAR(255),
        wilaya VARCHAR(100),
        name VARCHAR(255) NOT NULL,
        price NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
        stock INTEGER NOT NULL DEFAULT 0,
        category VARCHAR(100) NOT NULL,
        image TEXT,
        description TEXT,
        verified BOOLEAN NOT NULL DEFAULT FALSE,
        sponsored BOOLEAN NOT NULL DEFAULT FALSE,
        dynamic_data JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS customers (
        id VARCHAR(100) PRIMARY KEY,
        workspace_id VARCHAR(100) REFERENCES workspaces(id) ON DELETE CASCADE,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        blacklisted BOOLEAN NOT NULL DEFAULT FALSE,
        orders_count INTEGER NOT NULL DEFAULT 0,
        total_spent NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
        created_at BIGINT NOT NULL,
        CONSTRAINT unique_phone_per_workspace UNIQUE (workspace_id, phone)
    );

    CREATE TABLE IF NOT EXISTS orders (
        id VARCHAR(100) PRIMARY KEY,
        workspace_id VARCHAR(100) REFERENCES workspaces(id) ON DELETE CASCADE,
        customer_id VARCHAR(100) REFERENCES customers(id) ON DELETE SET NULL,
        items JSONB NOT NULL DEFAULT '[]'::jsonb,
        total NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
        delivery_fee NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
        status VARCHAR(100) NOT NULL DEFAULT 'pending',
        wilaya VARCHAR(100) NOT NULL,
        address TEXT NOT NULL,
        notes TEXT,
        risk_score NUMERIC(5, 2) DEFAULT 0.00,
        payment_method VARCHAR(100),
        payment_status VARCHAR(100) NOT NULL DEFAULT 'pending',
        receipt_image TEXT,
        transaction_reference VARCHAR(255),
        payment_tx_id VARCHAR(255),
        payment_proof_file TEXT,
        verified_by_seller BOOLEAN NOT NULL DEFAULT FALSE,
        created_at BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS interactions (
        id VARCHAR(100) PRIMARY KEY,
        product_id VARCHAR(100) NOT NULL,
        type VARCHAR(50) NOT NULL,
        timestamp BIGINT NOT NULL,
        user_id VARCHAR(100),
        vendor_id VARCHAR(100)
    );

    CREATE TABLE IF NOT EXISTS favorites (
        id VARCHAR(100) PRIMARY KEY,
        timestamp BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payment_events (
        id VARCHAR(100) PRIMARY KEY,
        order_id VARCHAR(100) NOT NULL,
        status VARCHAR(100) NOT NULL,
        payload TEXT NOT NULL,
        created_at BIGINT NOT NULL,
        processed INTEGER NOT NULL DEFAULT 0
    );
  `;

  // Retries loop for transient database initializations (supporting up to 6 progressive attempts to survive warming-up DNS resolution)
  const backoffs = [1000, 2000, 3000, 5000, 8000, 10000];
  const maxAttempts = 6;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      console.log(`Database initialization attempt ${attempt}/${maxAttempts} connecting to Aiven...`);
      const client = await pool.connect();
      
      // Perform ping health check first
      await client.query('SELECT NOW()');
      
      // Bootstrap schema
      await client.query(schemaSql);
      
      client.release();
      dbConnected = true;
      dbError = null;
      usingSafeModeBackup = false;
      console.log('Aiven PostgreSQL initialized successfully and schema is verified.');
      return true;
    } catch (err: any) {
      console.error(`Database connection or schema setup failed on attempt ${attempt}:`, err.message);
      dbConnected = false;
      dbError = err.message;
      if (attempt < maxAttempts) {
        const delay = backoffs[attempt - 1] || 2000;
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

      console.warn('⚡ Initial PG Aiven Connection Failed after retries.');
      dbConnected = false;
      // Do not activate any mock/safe mode; leave as offline.

  // Set up a background reconnect loop if it continues failing
  const healInterval = setInterval(async () => {
    if (dbConnected) {
      clearInterval(healInterval);
      return;
    }
    try {
      const client = await pool!.connect();
      await client.query('SELECT NOW()');
      await client.query(schemaSql);
      client.release();
      dbConnected = true;
      dbError = null;
      usingSafeModeBackup = false;
      console.log('✅ Background reconnect worker successfully connected and schema verified! Safe Mode deactivated.');
      clearInterval(healInterval);
    } catch (err: any) {
      dbError = err.message;
    }
  }, 15000);
  
  if (typeof (healInterval as any).unref === 'function') {
    (healInterval as any).unref();
  }

  return true;
  })();
  return dbInitPromise;
}

// 3. ABLY EMISSIONS HELPER
async function publishAblyEvent(event: string, payload: any): Promise<boolean> {
  if (!ABLY_API_KEY) {
    console.log(`[ABLY_MOCK_PUBLISHED] Event "${event}" simulated on server side.`);
    return true;
  }
  try {
    const [keyId, keySecret] = ABLY_API_KEY.split(':');
    const authHeader = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
    const res = await fetch('https://rest.ably.io/channels/riyada_events/messages', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${authHeader}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: event,
        data: payload
      })
    });
    return res.ok;
  } catch (error: any) {
    console.error(`Ably publish server error: ${error.message}`);
    return false;
  }
}

// 4. SERVER SYSTEM BOOT
async function startServer() {
  const app = express();
  
  // Connect and prepare database in the background promptly
  initializeSchemaAndVerify();

  // Webhooks raw parser middleware specifically for signature validation
  app.use((req, res, next) => {
    if (req.originalUrl.includes('/webhook') || req.originalUrl.includes('/chargily')) {
      let data = '';
      req.setEncoding('utf8');
      req.on('data', (chunk) => {
        data += chunk;
      });
      req.on('end', () => {
        (req as any).rawBody = data;
        next();
      });
    } else {
      next();
    }
  });

  // Standard JSON Parser
  app.use(express.json());

  // HEALTH CHECK ENDPOINT
  app.get('/api/health', async (req, res) => {
    const alive = await initializeSchemaAndVerify();
    let dbLatency: number | null = null;
    let dbStatus = 'offline';
    
    if (dbConnected && pool) {
      try {
        const start = Date.now();
        await pool.query('SELECT NOW()');
        dbLatency = Date.now() - start;
        dbStatus = 'online';
      } catch (err: any) {
        dbError = err.message;
        dbStatus = 'offline';
      }
    } else {
      dbStatus = 'offline';
    }

    res.json({
      database: dbStatus,
      dbLatency,
      usingBackupMode: false,
      activeQueries: activeQueriesCount,
      queueLength: queryQueue.length,
      realtime: ABLY_API_KEY ? 'online' : 'simulation',
      backup: process.env.VITE_NPOINT_ID ? 'active' : 'simulation',
      error: dbError,
      env: {
        AIVEN_POSTGRES_URL_CONFIGURED: !!AIVEN_POSTGRES_URL,
        CHARGILY_SECRET_KEY_CONFIGURED: !!CHARGILY_SECRET_KEY,
        VITE_ABLY_API_KEY_CONFIGURED: !!ABLY_API_KEY,
        VITE_NPOINT_ID_CONFIGURED: !!process.env.VITE_NPOINT_ID,
        VITE_CHARGILY_PUBLIC_KEY_CONFIGURED: !!process.env.VITE_CHARGILY_PUBLIC_KEY
      }
    });
  });

  // SECURE PARAMETERIZED QUERY BRIDGE (Proxying database requests safely from client)
  app.post('/api/query', async (req, res) => {
    const { sql, params } = req.body;
    if (!sql) {
      return res.status(400).json({ error: 'SQL string query is required.' });
    }
    if (!dbConnected) {
      return res.status(503).json({ error: 'Database is not yet initialized.' });
    }

    try {
      const result = await runQuery(sql, params || []);
      res.json(result);
    } catch (err: any) {
      console.error(`Database Query Error: ${err.message}`, { sql });
      res.status(500).json({ error: err.message });
    }
  });

  // SECURE PAYMENT GATEWAY INTEGRATION
  app.post('/api/payments/createCheckout', async (req, res) => {
    const { orderId, amount, email } = req.body;
    if (!orderId || !amount) {
      return res.status(400).json({ success: false, error: 'orderId and amount are required.' });
    }

    try {
      console.log(`Handling secure checkout checkout session request: Order=${orderId}, Amount=${amount}`);

      // Verify actual order validity on the database first
      const orderCheck = await runQuery('SELECT * FROM orders WHERE id = $1', [orderId]);
      if (orderCheck.rowCount === 0) {
        return res.status(404).json({ success: false, error: 'الطلب المحدد غير مسجل بقاعدة البيانات.' });
      }

      // Check key
      if (!CHARGILY_SECRET_KEY) {
        // Safe standby bypass URL
        const APP_URL = req.headers.referer ? new URL(req.headers.referer).origin : 'http://localhost:3000';
        const sandboxUrl = `https://chargi.ly/wadoud?orderId=${orderId}&amount=${amount}&ref=riyada`;
        return res.json({
          success: true,
          data: {
            id: `ch_v2_sb_${Math.floor(10000 + Math.random() * 90000)}`,
            checkout_url: sandboxUrl,
            status: 'pending',
            amount
          }
        });
      }

      const isLive = CHARGILY_SECRET_KEY.startsWith('api_li_');
      const chargily = new ChargilyClient({
        api_key: CHARGILY_SECRET_KEY,
        mode: isLive ? 'live' : 'test'
      });

      const APP_URL = req.headers.referer ? new URL(req.headers.referer).origin : 'http://localhost:3000';
      const checkout = await chargily.createCheckout({
        amount: Number(amount),
        currency: 'dzd',
        success_url: `${APP_URL}/dashboard/orders?payment_status=success&orderId=${orderId}`,
        failure_url: `${APP_URL}/dashboard/orders?payment_status=failed&orderId=${orderId}`,
        webhook_endpoint: `${APP_URL}/api/webhooks/chargily`,
        metadata: { orderId },
        description: `طلب شراء ريادة #${orderId}`,
        locale: 'ar'
      });

      res.json({
        success: true,
        data: {
          id: checkout.id,
          checkout_url: checkout.checkout_url,
          status: checkout.status,
          amount: checkout.amount
        }
      });
    } catch (error: any) {
      console.error('Chargily Payment Session Creation Failure:', error.message);
      res.status(500).json({ success: false, error: error.message });
    }
  });

  // CRYPTOGRAPHIC WEBHOOK PROCESSOR
  const handleWebhook = async (req: express.Request, res: express.Response) => {
    const rawBody = (req as any).rawBody || '';
    const signature = req.headers['signature'] || req.headers['x-signature'] || req.headers['chargily-signature'] || '';
    
    if (typeof signature !== 'string') {
      return res.status(400).send('Malformed signature.');
    }

    if (!CHARGILY_SECRET_KEY) {
      console.warn('Webhook bypass permitted due to missing CHARGILY_SECRET_KEY on host.');
    } else {
      // CRYPTOGRAPHIC VERIFICATION
      try {
        const encoder = new TextEncoder();
        const keyData = encoder.encode(CHARGILY_SECRET_KEY);
        const messageData = encoder.encode(rawBody);

        const cryptoKey = await crypto.subtle.importKey(
          'raw',
          keyData,
          { name: 'HMAC', hash: 'SHA-256' },
          false,
          ['verify', 'sign']
        );

        const computedSigBuffer = await crypto.subtle.sign(
          'HMAC',
          cryptoKey,
          messageData
        );

        const calculatedSigHex = Array.from(new Uint8Array(computedSigBuffer))
          .map(b => b.toString(16).padStart(2, '0'))
          .join('');

        if (calculatedSigHex !== signature.trim()) {
          console.error('[SECURITY_ALERT] Invalid HMAC signature detected onto payment webhook.');
          return res.status(401).send('Invalid signature.');
        }
      } catch (err: any) {
        console.error('Signature verification error:', err.message);
        return res.status(500).send('Signature verification failed.');
      }
    }

    try {
      const payload = JSON.parse(rawBody);
      const eventType = payload.type || 'checkout.paid';
      const data = payload.data || payload;

      const checkoutId = data.id;
      const checkoutStatus = data.status;
      const orderId = data.metadata?.orderId;
      const amount = data.amount;

      if (!checkoutId || !orderId) {
        return res.status(400).send('Malformed payload mapping options missing.');
      }

      console.log(`Webhook Event received: ${eventType}, Checkout: ${checkoutId}, Order: ${orderId}`);

      if (!dbConnected) {
        return res.status(503).send('Database connection unavailable.');
      }

      // Check if order exists
      const orderCheckResult = await runQuery('SELECT * FROM orders WHERE id = $1', [orderId]);
      if (orderCheckResult.rowCount === 0) {
        console.error(`Order ${orderId} does not exist for verified payment webhook.`);
        return res.status(404).send('Order not found.');
      }

      const order = orderCheckResult.rows[0];
      if (order.status === 'paid' || order.payment_status === 'PAID') {
        console.log(`Order ${orderId} is already marked as PAID.`);
        return res.status(200).send('Order already processed.');
      }

      // 5. UPDATE ORDER STATE SAFELY IN AIVEN DB
      if (checkoutStatus === 'paid' || eventType === 'checkout.paid') {
        await runQuery(
          'UPDATE orders SET status = $1, payment_status = $2, payment_tx_id = $3 WHERE id = $4',
          ['paid', 'PAID', checkoutId, orderId]
        );

        // Emit realtime Ably integration notification
        await publishAblyEvent('payment_confirmed', { orderId, amount, transactionId: checkoutId });
        console.log(`Order ${orderId} updated to PAID securely.`);
      } else if (checkoutStatus === 'failed' || eventType === 'checkout.failed') {
        await runQuery(
          'UPDATE orders SET status = $1, payment_status = $2 WHERE id = $3',
          ['cancelled', 'FAILED', orderId]
        );
        await publishAblyEvent('payment_failed', { orderId, transactionId: checkoutId });
      } else if (checkoutStatus === 'expired' || eventType === 'checkout.expired') {
        await runQuery(
          'UPDATE orders SET status = $1, payment_status = $2 WHERE id = $3',
          ['expired', 'EXPIRED', orderId]
        );
      }

      res.status(200).send('Webhook processed successfully.');
    } catch (err: any) {
      console.error('Webhook payload parsing or processing failure:', err.message);
      res.status(500).send(err.message);
    }
  };

  // Bind to BOTH webhook endpoints
  app.post('/api/webhooks/chargily', handleWebhook);
  app.post('/chargily/webhook', handleWebhook);

  // VITE DEV OR STATIC SERVER ENGINE MIDDLEWARES
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Bind
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Fullstack RIYADA Production Environment running on port ${PORT}`);
  });
}

startServer();
