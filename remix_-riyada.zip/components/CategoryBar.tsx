// /components/CategoryBar.tsx - Next.js category filtering bar
import React from 'react';

const CATEGORIES = [
  { id: 'all', name: 'الكل' },
  { id: 'products', name: 'السلع والمبيعات' },
  { id: 'services', name: 'الخدمات والحرفيين' },
  { id: 'jobs', name: 'عروض التوظيف' },
  { id: 'workers', name: 'العمال المستقلين' }
];

export default function NextCategoryBar() {
  return (
    <div className="flex border-b border-white/10 overflow-x-auto pb-2 gap-2 text-right justify-start md:justify-center" dir="rtl">
      {CATEGORIES.map((cat) => (
        <button key={cat.id} className="px-4 py-2 text-xs font-bold text-white/70 hover:text-white rounded-lg hover:bg-white/5 transition-colors whitespace-nowrap">
          {cat.name}
        </button>
      ))}
    </div>
  );
}
