// /components/ListingCard.tsx - Next.js responsive cards structure
import React from 'react';

export interface ListingProps {
  id: string;
  title: string;
  price: string;
  category: string;
  location: string;
  boost: boolean;
}

export default function NextListingCard({ item }: { item: ListingProps }) {
  return (
    <div className={`rounded-2xl border bg-[#0a0f18] p-5 space-y-3 transition-transform hover:-translate-y-1 ${
      item.boost ? 'border-[#1AAE8A]/40 shadow-[0_0_15px_rgba(26,174,138,0.05)]' : 'border-white/10'
    }`} dir="rtl">
      <div className="flex items-center justify-between">
        <span className="text-[10px] bg-white/5 border border-white/10 text-white/60 px-2 py-0.5 rounded-full">
          {item.category}
        </span>
        <span className="text-[10px] text-white/40">{item.location}</span>
      </div>

      <h3 className="font-bold text-sm text-white line-clamp-1">{item.title}</h3>
      
      <div className="flex items-center justify-between pt-2 border-t border-white/5">
        <span className="text-xs font-mono text-[#1AAE8A]">{item.price} د.ج</span>
        <a href={`/listing/${item.id}`} className="text-[10px] text-brand-400 hover:underline">
          تفاصيل العرض ←
        </a>
      </div>
    </div>
  );
}
