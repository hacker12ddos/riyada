// /components/Hero.tsx - Next.js Hero Banner Section
import React from 'react';

export default function NextHero() {
  return (
    <div className="relative overflow-hidden border-b border-white/10 bg-[#0a0f18] py-20 px-6 text-center font-sans" dir="rtl">
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight">
          سوق الجزائر الرقمي للسلع والوظائف الحرة
        </h1>
        <p className="text-sm md:text-base text-white/60 max-w-xl mx-auto leading-relaxed">
          ريادة هي المنصة الجزائية الشاملة للعمال والتجار. تصفح عروض التوظيف والخدمات المحلية مجاناً بضمان وتأمين بريدي موب والـ CCP.
        </p>
        <div className="pt-4 flex items-center justify-center gap-4">
          <a href="/marketplace" className="px-6 py-3 rounded-2xl bg-[#1AAE8A] hover:bg-emerald-600 text-white text-xs font-bold transition-colors">
            استكشف المعروضات
          </a>
          <a href="/setup-wizard" className="px-6 py-3 rounded-2xl border border-white/10 hover:bg-white/5 text-white text-xs font-bold transition-colors">
            إنشاء خادم سيكوال مجاناً
          </a>
        </div>
      </div>
    </div>
  );
}
