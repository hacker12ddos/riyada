// /components/CreateListingForm.tsx - Creation Form component template
import React from 'react';

export default function NextCreateListingForm() {
  return (
    <form className="space-y-4 text-right" dir="rtl">
      <div className="space-y-1">
        <label className="text-xs font-bold text-white/70 block">إسم العرض أو الخدمة</label>
        <input type="text" placeholder="مثال: مصلح تدفئة معتمد" className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" required />
      </div>

      <div className="space-y-1">
        <label className="text-xs font-bold text-white/70 block">سعر الخدمة التقديري (د.ج)</label>
        <input type="number" placeholder="مثال: 1500" className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" required />
      </div>

      <button type="submit" className="w-full py-3.5 rounded-2xl bg-[#1AAE8A] hover:bg-[#1AAE8A]/85 text-white text-xs font-bold transition-colors">
        تفعيل وإدراج السلعة في سوبابيس
      </button>
    </form>
  );
}
