// /components/Footer.tsx - Next.js Footer template
import React from 'react';

export default function NextFooter() {
  return (
    <footer className="bg-[#05070a] border-t border-white/10 py-12 px-6 font-sans text-right" dir="rtl">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="space-y-4">
          <h4 className="text-sm font-extrabold text-white">منصة ريادة الاقتصادية</h4>
          <p className="text-xs text-white/50 leading-relaxed">
            المنتدى الرقمي الرائد في الجزائر لتنمية المبيعات والتجارة المستقلة والوظائف الصغرى مجاناً بالكامل.
          </p>
        </div>

        <div className="space-y-2 text-xs">
          <h4 className="font-bold text-white mb-2">أقسام السوق</h4>
          <a href="/marketplace" className="block text-white/60 hover:text-[#1AAE8A]">المصنوعات والسلع</a>
          <a href="/services" className="block text-white/60 hover:text-[#1AAE8A]">الحرف والخدمات المنزلية</a>
          <a href="/jobs" className="block text-white/60 hover:text-[#1AAE8A]">فرص العمل والمهن</a>
        </div>

        <div className="space-y-2 text-xs">
          <h4 className="font-bold text-white mb-2">الأمان والدعم</h4>
          <a href="/trust-center" className="block text-white/60 hover:text-[#1AAE8A]">مركز الأمان العائلي</a>
          <a href="/payment-center" className="block text-white/60 hover:text-[#1AAE8A]">تسوية براهين CCP</a>
          <a href="/setup-wizard" className="block text-white/60 hover:text-[#1AAE8A]">مركّب المعالج التثبيتي</a>
        </div>

        <div className="space-y-2 text-xs">
          <h4 className="font-bold text-white mb-2">سياسات النشر</h4>
          <a href="/terms" className="block text-white/60 hover:text-[#1AAE8A]">قواعد التجارة والوساطة</a>
          <a href="/privacy" className="block text-white/60 hover:text-[#1AAE8A]">بيان التشفير لصور بريدي موب</a>
          <a href="/about" className="block text-white/60 hover:text-[#1AAE8A]">فلسفتنا وراء المبادرة</a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto border-t border-white/5 mt-8 pt-6 text-center text-[10px] text-white/30">
        © {new Date().getFullYear()} ريادة الجزائر. جميع الحقوق والشيفرات مفتوحة للمجتمع.
      </div>
    </footer>
  );
}
