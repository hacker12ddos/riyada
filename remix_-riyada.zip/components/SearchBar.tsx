// /components/SearchBar.tsx - Next.js Search Filter Component
import React from 'react';

export default function NextSearchBar() {
  return (
    <div className="w-full max-w-2xl mx-auto font-sans" dir="rtl">
      <div className="relative">
        <input 
          type="text" 
          placeholder="ابحث عن هاتف، سيارة، حرفي مصلح، أو عروض عمل..." 
          className="w-full py-4 pl-12 pr-6 rounded-2xl bg-[#0a0f18] text-white text-sm border border-white/10 focus:outline-none focus:border-brand-500 placeholder-white/40 shadow-lg text-right"
        />
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>
    </div>
  );
}
