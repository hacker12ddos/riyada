// /components/ListingGrid.tsx - Next.js Grid Layout template
import React from 'react';
import ListingCard, { ListingProps } from './ListingCard';

const DEMO_ITEMS: ListingProps[] = [
  {
    id: 'PRD-1',
    title: 'شاحنة نقل البضائع وسياقة آمنة',
    price: '2500',
    category: 'خدمات نقل',
    location: 'الجزائر العاصمة',
    boost: true,
  },
  {
    id: 'PRD-2',
    title: 'ترصيص وتصليح صمامات الأمان المنزلي',
    price: '1500',
    category: 'صيانة وتدقيق',
    location: 'قسنطينة',
    boost: false,
  },
  {
    id: 'PRD-3',
    title: 'تصميم هويات بصرية وبوسترات سوشيال ميديا',
    price: '5000',
    category: 'عمل رقمي ومستقل',
    location: 'وهران',
    boost: true,
  }
];

export default function NextListingGrid({ category }: { category?: string }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 font-sans">
      {DEMO_ITEMS.map((item) => (
        <div key={item.id}>
          <ListingCard item={item} />
        </div>
      ))}
    </div>
  );
}
