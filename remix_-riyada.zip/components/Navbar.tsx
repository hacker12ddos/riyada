// /components/Navbar.tsx - Next.js Nav Header template
import React from 'react';

export default function NextNavbar() {
  return (
    <nav className="border-b border-white/10 bg-[#0a0f18] px-6 py-4 flex items-center justify-between text-right font-sans" dir="rtl">
      <div className="flex items-center gap-6">
        <span className="text-lg font-extrabold text-white tracking-tight">ريادة <strong className="text-brand-400">RIYADA</strong></span>
        <div className="hidden md:flex items-center gap-4 text-xs text-white/70">
          <a href="/marketplace" className="hover:text-white">السلع</a>
          <a href="/services" className="hover:text-white">الخدمات</a>
          <a href="/jobs" className="hover:text-white">الوظائف</a>
          <a href="/workers" className="hover:text-white">العمال المستقلين</a>
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        <a href="/create" className="px-4 py-2 rounded-xl bg-[#1AAE8A] hover:bg-emerald-600 text-white font-bold text-xs transition-colors">
          أضف إعلانك مجاناً
        </a>
      </div>
    </nav>
  );
}
