// /components/SellerStats.tsx - Next.js Seller Stats Indicators
import React from 'react';

export default function NextSellerStats() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 font-sans text-right" dir="rtl">
      <div className="p-6 rounded-2xl bg-[#0a0f18] border border-white/10 space-y-1">
        <div className="text-2xl font-extrabold text-white">450 د.ج</div>
        <div className="text-xs text-white/50">إجمالي المبيعات المحققة</div>
      </div>
      <div className="p-6 rounded-2xl bg-[#0a0f18] border border-white/10 space-y-1">
        <div className="text-2xl font-extrabold text-brand-400">92%</div>
        <div className="text-xs text-white/50">معدل تقييم الثقة لمتجركم</div>
      </div>
      <div className="p-6 rounded-2xl bg-[#0a0f18] border border-white/10 space-y-1">
        <div className="text-2xl font-extrabold text-indigo-400">12 إعلان</div>
        <div className="text-xs text-white/50">المعروضات النشطة السحابية</div>
      </div>
    </div>
  );
}
