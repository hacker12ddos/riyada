// /components/TrustBadge.tsx - Next.js Seller Verification Status
import React from 'react';

export default function NextTrustBadge({ isVerified = true }) {
  if (!isVerified) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-[#1AAE8A] px-2.5 py-1 rounded-full font-bold font-sans">
      <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
      </svg>
      <span>حساب ريادي موثق</span>
    </span>
  );
}
