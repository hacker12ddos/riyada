-- ==========================================================
-- 🏢 RIYADA - AIVEN POSTGRESQL PRIMARY DATABASE SCHEMA
-- ==========================================================
-- This SQL file defines the relational tables, index patterns,
-- and constraint structures optimized for Algerian commerce flow.

-- 1. Workspaces Table (Sellers and Stores)
CREATE TABLE IF NOT EXISTS workspaces (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    created_at BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000,
    settings JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- 2. Products Table
CREATE TABLE IF NOT EXISTS products (
    id VARCHAR(100) PRIMARY KEY,
    workspace_id VARCHAR(100) REFERENCES workspaces(id) ON DELETE CASCADE,
    vendor_id VARCHAR(100),
    vendor_name VARCHAR(255),
    wilaya VARCHAR(100),
    name VARCHAR(255) NOT NULL,
    price NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    stock INTEGER NOT NULL DEFAULT 0,
    category VARCHAR(100) NOT NULL,
    image TEXT,
    description TEXT,
    verified BOOLEAN NOT NULL DEFAULT FALSE,
    sponsored BOOLEAN NOT NULL DEFAULT FALSE,
    dynamic_data JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000
);

-- 3. Customers Table (Buyer Profiles tracked by phone)
CREATE TABLE IF NOT EXISTS customers (
    id VARCHAR(100) PRIMARY KEY,
    workspace_id VARCHAR(100) REFERENCES workspaces(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    blacklisted BOOLEAN NOT NULL DEFAULT FALSE,
    orders_count INTEGER NOT NULL DEFAULT 0,
    total_spent NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    created_at BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000,
    CONSTRAINT unique_phone_per_workspace UNIQUE (workspace_id, phone)
);

-- 4. Orders Table (With CCP & BaridiMob proof points)
CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(100) PRIMARY KEY,
    workspace_id VARCHAR(100) REFERENCES workspaces(id) ON DELETE CASCADE,
    customer_id VARCHAR(100) REFERENCES customers(id) ON DELETE SET NULL,
    items JSONB NOT NULL DEFAULT '[]'::jsonb,
    total NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    delivery_fee NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    status VARCHAR(100) NOT NULL DEFAULT 'pending',
    wilaya VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    notes TEXT,
    risk_score NUMERIC(5, 2) DEFAULT 0.00,
    payment_method VARCHAR(100),
    payment_status VARCHAR(100) NOT NULL DEFAULT 'pending',
    receipt_image TEXT,
    transaction_reference VARCHAR(255),
    payment_tx_id VARCHAR(255),
    payment_proof_file TEXT,
    verified_by_seller BOOLEAN NOT NULL DEFAULT FALSE,
    created_at BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000
);

-- 5. Interactions Table (Clicks telemetry, reports, and phone views)
CREATE TABLE IF NOT EXISTS interactions (
    id VARCHAR(100) PRIMARY KEY,
    product_id VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'view', 'whatsapp', 'favorite', 'report'
    timestamp BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000,
    user_id VARCHAR(100),
    vendor_id VARCHAR(100)
);

-- 6. Favorites Table
CREATE TABLE IF NOT EXISTS favorites (
    id VARCHAR(100) PRIMARY KEY, -- maps to product_id
    timestamp BIGINT NOT NULL DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000
);

-- ==========================================================
-- 🚀 HIGH PERFORMANCE INDEXING PATTERNS
-- ==========================================================
CREATE INDEX IF NOT EXISTS idx_products_workspace ON products(workspace_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_wilaya ON products(wilaya);

CREATE INDEX IF NOT EXISTS idx_orders_workspace ON orders(workspace_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

CREATE INDEX IF NOT EXISTS idx_customers_workspace ON customers(workspace_id);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);

CREATE INDEX IF NOT EXISTS idx_interactions_product ON interactions(product_id);
CREATE INDEX IF NOT EXISTS idx_interactions_vendor ON interactions(vendor_id);
CREATE INDEX IF NOT EXISTS idx_interactions_type ON interactions(type);
