// /app/auth/register/page.tsx - Register user page for Next.js with Supabase Auth
import React from 'react';

export default function NextRegister() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white flex items-center justify-center p-6 text-right font-sans" dir="rtl">
      <div className="w-full max-w-md p-8 rounded-3xl border border-white/10 bg-[#0a0f18] space-y-6">
        <h2 className="text-2xl font-bold text-center">إنشاء حساب ريادي جديد</h2>
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs text-white/60 block">الإسم بالكامل</label>
            <input type="text" placeholder="مثال: سفيان بلعيدي" className="w-full p-3 rounded-xl bg-[#05070a] border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-white/60 block">البريد الإلكتروني</label>
            <input type="email" placeholder="example@gmail.com" className="w-full p-3 rounded-xl bg-[#05070a] border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-white/60 block">كلمة السر</label>
            <input type="password" placeholder="••••••••" className="w-full p-3 rounded-xl bg-[#05070a] border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" />
          </div>
          <button className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors">
            إنشاء وتأكيد الحساب
          </button>
        </div>
      </div>
    </div>
  );
}
