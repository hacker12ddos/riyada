# RIYADA Next.js/Vercel Route Templates (/app)

This folder contains high-performance layout and code skeletons ready to be dropped into a **Next.js App Router** project for Vercel Hobby tier production.

## Directory Map

- `/app/home/page.tsx` - High conversion homepage
- `/app/marketplace/page.tsx` - Searchable Algerian marketplace listing index
- `/app/services/page.tsx` - Local craftsman & microservice index
- `/app/jobs/page.tsx` - Youth employment gig postings
- `/app/workers/page.tsx` - Dynamic worker/freelance catalog
- `/app/seller/page.tsx` - Merchant shop setup and inventory dashboard
- `/app/payment-center/page.tsx` - Manual coordinate CCP & BaridiMob proof hub
- `/app/security-center/page.tsx` - Anti-fraud, game theory score validator
- `/app/privacy-center/page.tsx` - Plain translation privacy directives
- `/app/admin/page.tsx` - Core metrics, platform integrity overview
- `/app/setup-wizard/page.tsx` - In-app deployment assistant

These structures reference our unified `supabaseClient.ts` and `db.ts` routines.
