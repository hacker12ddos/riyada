// /app/privacy-center/page.tsx - Plain translation privacy directives
import React from 'react';

export default function NextPrivacyPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans">
      <div className="max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">مبادئ الأمان والخصوصية المحلية لـ ريادة</h1>
        <p className="text-sm text-white/50 leading-relaxed">
          ريادة مصممة لحماية خصوصيتك التامة بالكامل: لا توجد إعلانات تعقب، لا يتم بيع بيانات الزبائن، ولا يتم تخزين فهارس الاتصال على خوادم خارجية إلا برغبتك وتخويلك.
        </p>
      </div>
    </div>
  );
}
