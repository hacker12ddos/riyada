// /app/jobs/page.tsx - Youth employment gig postings
import React from 'react';

export default function NextJobsPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8">
      <div className="max-w-7xl mx-auto space-y-4">
        <h1 className="text-3xl font-bold">عروض العمل والفرص العاجلة</h1>
        <p className="text-sm text-white/50 font-sans">وظائف يومية ومشاريع حرة للشباب النشط داخل الولايات الجزائرية.</p>
      </div>
    </div>
  );
}
