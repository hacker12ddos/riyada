// /app/payment-center/page.tsx - Manual coordinate CCP & BaridiMob proof hub
import React from 'react';

export default function NextPaymentPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8">
      <div className="max-w-7xl mx-auto space-y-4">
        <h1 className="text-3xl font-bold">مركّز تسوية وتوثيق الدفع اليدوي</h1>
        <p className="text-sm text-white/50 font-sans">تنسيق وتصديق براهين سداد بريدي موب والـ CCP لتفادي النزاعات والاحتيال.</p>
      </div>
    </div>
  );
}
