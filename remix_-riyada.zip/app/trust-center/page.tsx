// /app/trust-center/page.tsx - Next.js Trust and Safety Hub
import React from 'react';

export default function NextTrustCenter() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="border-b border-white/10 pb-6">
          <h1 className="text-3xl font-extrabold text-white">مركز الأمان ومكافحة الاحتيال 🛡️</h1>
          <p className="text-sm text-white/50 mt-1">نظام ريادة الآمن لمراجعة نزاهة المعاملات، الحرفيين، وطلبات السيطرة البريدية.</p>
        </div>

        <div className="p-6 rounded-2xl border border-dashed border-red-500/20 bg-red-500/5 space-y-4">
          <h3 className="font-bold text-sm text-red-400">إرشادات هامة للحماية من النصب المعاملاتي</h3>
          <p className="text-xs text-white/70 leading-relaxed">
            قبل استلام السلعة أو تحويل كامل المبلغ عبر بريدي موب (BaridiMob)، نوصي بشدة بالتحقق من تقييم التاجر ونسبة نقاط نزاهته. لا تشحن عربوناً كبيراً إلا للتاجر المزود بشعار العلامة الفضية المعتمدة (Verified ✓).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-2">
            <h4 className="font-bold text-sm text-white">ما هي نقاط السمعة (Trust Score)؟</h4>
            <p className="text-xs text-white/60 leading-relaxed">
              هو مؤشر حسابي تلقائي يبدأ من 70 نقطة ويرتفع حتى 100 نقطة بالاعتماد على سرعة الرد، إثباتات السداد المقبولة بـ CCP وخلو المتجر من تقارير النصب الكيدية أو الحقيقية.
            </p>
          </div>
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-2">
            <h4 className="font-bold text-sm text-white">الإبلاغ عن سلوك احتيالي</h4>
            <p className="text-xs text-white/60 leading-relaxed">
              في حال تعرضك لنزاع مالي، قم فوراً بالضغط على خيار (تقديم بلاغ) من صفحة المنتج وإرفاق لقطة شاشة لعملية بريدي موب لحضر وحذف السجل تلقائياً.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
