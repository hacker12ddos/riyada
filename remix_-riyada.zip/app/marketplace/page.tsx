// /app/marketplace/page.tsx - Searchable Algerian marketplace listing index
import React from 'react';

export default function NextMarketplacePage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">معرض السلع المفتوح</h1>
        <p className="text-sm text-white/50">تصفح سلع ومنتجات تجار ريادة الموثقين في مختلف الولايات الجزائرية.</p>
      </div>
    </div>
  );
}
