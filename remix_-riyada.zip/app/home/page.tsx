// /app/home/page.tsx - RIYADA High Conversion Homepage
import React from 'react';

export default function NextHomePage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white flex flex-col justify-center items-center p-8 text-right">
      <div className="max-w-4xl space-y-6">
        <div className="text-brand-400 font-mono tracking-widest text-sm uppercase">منصة ريادة الاقتصادية v23</div>
        <h1 className="text-5xl font-extrabold tracking-tight md:text-6xl text-white">
          اقتصاد الخدمة والتجارة الموثوقة بالجزائر
        </h1>
        <p className="text-lg text-white/70 max-w-2xl leading-relaxed">
          ريادة هي منصتك المحلية المتكاملة المفتوحة المصدر للمتاجر الناشئة، وظائف الشباب، مقدمي الخدمات، وتأمين المعاملات اليدوية CCP وبريدي موب مجاناً بالكامل.
        </p>
      </div>
    </div>
  );
}
