// /app/listing/[id]/page.tsx - Next.js Detail Page template
import React from 'react';

export default function NextListingDetail({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="bg-[#0a0f18] border border-white/10 rounded-3xl p-8 space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs bg-brand-500/10 text-brand-400 border border-brand-500/20 px-3 py-1 rounded-full">
              الرقم التعريفي: {params.id}
            </span>
            <span className="text-xs text-white/40">تحديث فوري منذ ساعة ✨</span>
          </div>

          <h1 className="text-3xl font-extrabold text-white">تفاصيل الإعلان أو العرض المختار</h1>
          <p className="text-sm text-white/70 leading-relaxed">
            هذا القالب جاهز بالكامل لقراءة البيانات ديناميكياً من جدول Supabase. يمكنك تعديله لربطه بـ `api.ts` والتحقق من التوثيق تلقائياً.
          </p>

          <div className="pt-6 border-t border-white/5 flex flex-wrap gap-4 items-center justify-between">
            <div className="text-xl font-extrabold text-[#1AAE8A]">3.500 د.ج</div>
            <button className="px-6 py-3 rounded-2xl bg-[#1AAE8A] hover:bg-emerald-600 text-white font-bold text-sm transition-colors">
              الاتصال بالبائع أو صاحب الخدمة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
