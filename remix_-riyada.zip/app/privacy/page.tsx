// /app/privacy/page.tsx - Privacy center fallback
import React from 'react';

export default function NextPrivacyFallback() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-extrabold text-white">سياسة الخصوصية وحق التعتيم والتطهير</h1>
        <p className="text-sm text-white/70 leading-relaxed">
          ريادة v23 تضمن بقاء كشوفات الـ CCP وصورة بريدي موب سرية ومحجوبة لأمان المستهلك والتجار.
        </p>
      </div>
    </div>
  );
}
