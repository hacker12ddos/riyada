// /app/seller-dashboard/page.tsx - Next.js Seller Dashboard Page
import React from 'react';

export default function NextSellerDashboard() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 font-sans text-right" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-3xl font-extrabold">لوحة تحكم المتجر (Seller Hub)</h1>
        <p className="text-sm text-white/50">راقب مبيعاتك، مشاهدات السلع لمتجرك الموثق بنقرة واحدة.</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <h3 className="text-xs text-white/55">مشاهدات السلع النشطة</h3>
            <div className="text-2xl font-extrabold text-white">1,492</div>
          </div>
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <h3 className="text-xs text-white/55">الطلبات المقبولة اليوم</h3>
            <div className="text-2xl font-extrabold text-brand-400">12 صفقة</div>
          </div>
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <h3 className="text-xs text-white/55">رصيد الشحن والترقيات</h3>
            <div className="text-2xl font-extrabold text-[#1AAE8A]">7,500 د.ج</div>
          </div>
        </div>
      </div>
    </div>
  );
}
