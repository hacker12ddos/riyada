// /app/seller/page.tsx - Merchant shop setup and inventory dashboard
import React from 'react';

export default function NextSellerPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8">
      <div className="max-w-7xl mx-auto space-y-4">
        <h1 className="text-3xl font-bold">لوحة أداء التاجر والسلع</h1>
        <p className="text-sm text-white/50">تحكم بالمخزون، أسعار الخدمات، والترقيات التنافسية لمتجرك.</p>
      </div>
    </div>
  );
}
