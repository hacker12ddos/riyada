// /app/about/page.tsx - About page
import React from 'react';

export default function NextAboutPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-extrabold text-white">من نحن لـ ريادة؟</h1>
        <p className="text-sm text-white/70 leading-relaxed">
          ريادة هي مبادرة مستقلة مفتوحة المصدر لتمكين الشباب الجزائري من عرض سلعهم، الترويج لخدماتهم وإيجاد فرص عمل وتوظيف دون قيود أو رسوم احتكارية.
        </p>
      </div>
    </div>
  );
}
