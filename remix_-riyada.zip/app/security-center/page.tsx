// /app/security-center/page.tsx - Anti-fraud, game theory score validator
import React from 'react';

export default function NextSecurityPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8">
      <div className="max-w-7xl mx-auto space-y-4 font-sans">
        <h1 className="text-3xl font-bold text-red-400">مركز مكافحة الاحتيال ونزاهة الحسابات</h1>
        <p className="text-sm text-white/50">تحليل جودة العروض ومعدلات الثقة للمتاجر لحجب السلوكيات المريبة.</p>
      </div>
    </div>
  );
}
