// /app/terms/page.tsx - Terms of service
import React from 'react';

export default function NextTermsPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-extrabold text-white">شروط الاستخدام والأمان الرقمي</h1>
        <p className="text-sm text-white/70 leading-relaxed">
          بلتزم كافة الأطراف والتجار بتقديم سلع حقيقية ومصورة، ويرفض النظام بشكل قاطع محاولات تبييض الحسابات أو سرقة تحويلات بريدي موب.
        </p>
      </div>
    </div>
  );
}
