// /app/stores/page.tsx - Next.js Stores Showcase Registry
import React from 'react';

export default function NextStoresPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="border-b border-white/10 pb-6">
          <h1 className="text-3xl font-extrabold text-white">دليل المتاجر والورش الجزائرية المعتمدة</h1>
          <p className="text-sm text-white/50 mt-1">تصفح متاجر الحرفيين، النقاط الإنتاجية، ومحلات التجزئة الموثقة في 58 ولاية.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((store) => (
            <div key={store} className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-4 hover:border-brand-500/30 transition-all">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-brand-500/10 text-brand-400 border border-brand-500/20 px-2.5 py-0.5 rounded-full font-bold">
                  متجر موثق ✓
                </span>
                <span className="text-[10px] text-white/40">الجزائر العاصمة</span>
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">ورشة التميز للإلكترونيات والأجهزة</h3>
                <p className="text-xs text-white/60 leading-relaxed mt-1">متخصصون في تصليح الأجهزة الكهرومنزلية وتقديم قطع الغيار الأصلية بضمان مالي.</p>
              </div>
              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs text-white/55">
                <span>التقييم: <strong className="text-amber-400">4.9 ★</strong></span>
                <span className="text-[#1AAE8A]">34 صفقة منجزة</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
