// /app/create/page.tsx - Listing creation page skeleton
import React from 'react';

export default function NextCreateListing() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-3xl font-extrabold text-white">إضافة عرض جديد (سلعة / وظيفة / خدمة)</h1>
        <p className="text-sm text-white/50">املأ الاستمارة التالية لنشر عرضك فوراُ على متجر ريادة أو سوبابيس السحابي.</p>

        <div className="p-8 rounded-3xl border border-white/10 bg-[#0a0f18] space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-white/70 block">عنوان العرض أو السلعة</label>
            <input type="text" placeholder="مثال: آلة تصليح قنوات الغاز والتدفئة" className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-white/70 block">السعر المقترح (د.ج)</label>
            <input type="number" placeholder="مثال: 4500" className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs text-right focus:outline-none focus:border-brand-500" />
          </div>

          <button className="w-full py-3.5 rounded-2xl bg-[#1AAE8A] hover:bg-emerald-600 text-white text-xs font-bold transition-colors cursor-pointer matches-id-submit">
            نشر وتأكيد العرض مجاناً
          </button>
        </div>
      </div>
    </div>
  );
}
