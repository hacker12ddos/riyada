// /app/analytics/page.tsx - Next.js Seller Analytics template
import React from 'react';

export default function NextAnalyticsPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="border-b border-white/10 pb-6">
          <h1 className="text-3xl font-extrabold text-white">تحليلات الأداء والمبيعات الذكية</h1>
          <p className="text-sm text-white/50 mt-1">تتبع سلوك المستهلكين ونقرات الاتصال والتفاعل اليومي مع معروضات متجرك.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <span className="text-[10px] text-white/40 block">الوصول العام للسلع</span>
            <div className="text-2xl font-extrabold text-[#1AAE8A]">18.4K +</div>
            <span className="text-[9px] text-emerald-400 font-bold">بمعدل نمو 12% هذا الأسبوع</span>
          </div>
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <span className="text-[10px] text-white/40 block">اتصالات الواتساب والهاتف</span>
            <div className="text-2xl font-extrabold text-white">412 نقرة</div>
            <span className="text-[9px] text-white/50">زبائن مهتمين بالشراء المباشر</span>
          </div>
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <span className="text-[10px] text-white/40 block">معدل التقييم المعنوي</span>
            <div className="text-2xl font-extrabold text-brand-400">98.2%</div>
            <span className="text-[9px] text-brand-400 font-bold">مستوى أمان استثنائي</span>
          </div>
          <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-1">
            <span className="text-[10px] text-white/40 block">المبيعات المقدرة</span>
            <div className="text-2xl font-extrabold text-indigo-400">125K د.ج</div>
            <span className="text-[9px] text-indigo-400 font-bold">عبر السداد والتنسيق اليدوي</span>
          </div>
        </div>
      </div>
    </div>
  );
}
