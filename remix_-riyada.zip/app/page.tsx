// /app/page.tsx - RIYADA Next.js Homepage Template
import React from 'react';
import Hero from '@/components/Hero';
import CategoryBar from '@/components/CategoryBar';
import ListingGrid from '@/components/ListingGrid';

export default function Homepage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white">
      <Hero />
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-12">
        <CategoryBar />
        
        <div className="space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <h2 className="text-2xl font-bold">العروض المتميزة لليوم ✨</h2>
            <span className="text-xs text-[#1AAE8A] font-medium bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full">
              ترقية البث الفوري نشطة
            </span>
          </div>
          <ListingGrid category="featured" />
        </div>
      </div>
    </div>
  );
}
