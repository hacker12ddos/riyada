// /app/services/page.tsx - Local craftsman & microservice index
import React from 'react';

export default function NextServicesPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8">
      <div className="max-w-7xl mx-auto space-y-4">
        <h1 className="text-3xl font-bold">دليل الخدمات والمهن الحرة</h1>
        <p className="text-sm text-white/50">أفضل الحرفيين، المبرمجين والمصلحين الموثقين بضمان ريادة.</p>
      </div>
    </div>
  );
}
