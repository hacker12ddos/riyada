// /app/setup-wizard/page.tsx - In-app deployment assistant
import React from 'react';

export default function NextSetupWizardPage() {
  return (
    <div className="min-h-screen bg-[#05070a] text-white p-8 text-right font-sans">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-4xl font-extrabold text-brand-400">مساعد التهيئة ونشر المتجر على فيرسيل وسوبابيس</h1>
        <p className="text-sm text-white/50 leading-relaxed">
          استخدم واجهة ريادة التفاعلية ومولدات الأكواد لتشغيل ورفع منصتك مجاناً في 5 دقائق مع استيراد وتجربة القوالب الجاهزة.
        </p>
      </div>
    </div>
  );
}
