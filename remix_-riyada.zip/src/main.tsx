import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';
import { initSentry } from './lib/sentry';
import { startRecoveryScheduler } from './jobs/paymentRecoveryJob';

// Initialize Sentry error reporting
initSentry();

// Launch background payment recovery scheduler
startRecoveryScheduler();

// Register service worker
if ('serviceWorker' in navigator) {
  registerSW({ immediate: true });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
