import React, { createContext, useContext, useState, useEffect } from 'react';
import { getWorkspaces, getWorkspace, Workspace, createWorkspace } from '../lib/db';

interface WorkspaceContextType {
  activeWorkspace: Workspace | null;
  workspaces: Workspace[];
  setActiveWorkspaceId: (id: string) => void;
  createNewWorkspace: (data: Omit<Workspace, 'id' | 'createdAt'>) => Promise<Workspace>;
  isLoading: boolean;
}

const WorkspaceContext = createContext<WorkspaceContextType | undefined>(undefined);

export const WorkspaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeWorkspace, setActiveWorkspace] = useState<Workspace | null>(null);
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadWorkspaces();
  }, []);

  const loadWorkspaces = async () => {
    try {
      const all = await getWorkspaces();
      setWorkspaces(all);
      
      const savedId = localStorage.getItem('riyada_active_workspace');
      if (savedId && all.find(w => w.id === savedId)) {
        const active = await getWorkspace(savedId);
        setActiveWorkspace(active || null);
      } else if (all.length > 0) {
        setActiveWorkspace(all[0]);
        localStorage.setItem('riyada_active_workspace', all[0].id);
      }
    } catch (error) {
      console.error("Failed to load workspaces", error);
    } finally {
      setIsLoading(false);
    }
  };

  const setActiveWorkspaceId = async (id: string) => {
    const workspace = await getWorkspace(id);
    if (workspace) {
      setActiveWorkspace(workspace);
      localStorage.setItem('riyada_active_workspace', id);
    }
  };

  const createNewWorkspace = async (data: Omit<Workspace, 'id' | 'createdAt'>) => {
    const id = crypto.randomUUID();
    const newWs = await createWorkspace({ ...data, id });
    await loadWorkspaces();
    await setActiveWorkspaceId(id);
    return newWs;
  };

  return (
    <WorkspaceContext.Provider value={{ activeWorkspace, workspaces, setActiveWorkspaceId, createNewWorkspace, isLoading }}>
      {children}
    </WorkspaceContext.Provider>
  );
};

export const useWorkspace = () => {
  const context = useContext(WorkspaceContext);
  if (context === undefined) {
    throw new Error('useWorkspace must be used within a WorkspaceProvider');
  }
  return context;
};
