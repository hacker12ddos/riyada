/**
 * RIYADA SECURITY RUNTIME MIDDLEWARE
 * Provides robust, framework-agnostic filtering, request interception, and rate-limiting.
 * Can be run in server-side Edge handlers, Next.js Middleware, or standard Express routes.
 */

import { countAndCheckRateLimit } from './lib/security/rateLimit';
import { sanitizeString } from './lib/security/sanitize';

export interface MiddlewareRequest {
  ip: string;
  url: string;
  method: string;
  headers: Record<string, string>;
  body?: any;
}

export interface MiddlewareResponse {
  status: number;
  headers: Record<string, string>;
  body?: any;
}

/**
 * Executes a full security pass against the request.
 * Filters SQL inject patterns, handles rate thresholds, enforces secure frame options.
 */
export async function runSecurityMiddleware(
  req: MiddlewareRequest
): Promise<MiddlewareResponse | null> {
  const ip = req.ip || '127.0.0.1';
  const path = req.url;

  // 1. Strict SQL Injection Pattern Filtering on all incoming URLs and Strings
  const isPostgresSqlInject = /UNION SELECT|SELECT.*FROM|INSERT INTO|DROP TABLE|UPDATE.*SET|--/i.test(path);
  if (isPostgresSqlInject) {
    return {
      status: 403,
      headers: { 'Content-Type': 'application/json' },
      body: { error: 'تم تسجيل ومحاصرة محاولة اختراق البنية التحتية لريادة.', status: 'blocked' }
    };
  }

  // 2. Global IP-based rate limiting on sensitive transaction paths
  if (path.includes('/api/orders/create') || path.includes('/api/products/create')) {
    const rateCheck = countAndCheckRateLimit(`global_limiter_${ip}_${path}`, 10, 60000);
    if (!rateCheck.allowed) {
      return {
        status: 429,
        headers: {
          'Content-Type': 'application/json',
          'Retry-After': String(rateCheck.timeLeftSeconds || 60)
        },
        body: {
          error: 'تجاوزت حد الطلبات المسموح به للموقع الإكلينيكي.',
          retryAfter: rateCheck.timeLeftSeconds
        }
      };
    }
  }

  // 3. Prevent Client Spoofing by enforcing secure modern headers
  const securityHeaders = {
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://66877cd2b18f670e290e6657496455c7@o4511451247345664.ingest.de.sentry.io; connect-src 'self' https://api.chargily.co https://api.ably.com https://ingest.de.sentry.io;"
  };

  // Return null to specify request has cleared the active checkpoint successfully
  return null;
}
