/**
 * RIYADA v23 Professional Monetization & Growth Packages
 * Includes Starter, Growth, Pro, Boost, and Verification Packs with Pricing in DZD (دج).
 */

export interface MonetizationPack {
  id: string;
  name: string;
  badge: string;
  priceDzd: number;
  badgeColor: string;
  durationDays: number;
  benefits: string[];
  salesPitch: string;
  nextSteps: string;
}

export const MONETIZATION_PACKS: MonetizationPack[] = [
  {
    id: 'pack-starter',
    name: 'باقة الانطلاق الأساسية (Starter Pack)',
    badge: 'المرشح الجديد',
    priceDzd: 1500,
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
    durationDays: 30,
    benefits: [
      'توثيق المتجر الأولي بمستوى حماية (Verified-1)',
      'وضع الشارة المميزة على أول 3 سلع أو خدمات معروضة',
      'إظهار رقم الواتساب والهاتف بشكل فوري للمشترين والباحثين عن خدماتكم',
      'صناعة بوستر تسويقي (JPEG) تلقائي لعلامتك مصمم بألوان ومقاسات شبكات التواصل'
    ],
    salesPitch: 'الباقة الاقتصادية المثالية للبدء في ترويج منتجاتك وتلقي أولى طلبياتك الموثقة والاتصالات من الزبائن داخل ولايتك بأقل تكلفة ممكنة.',
    nextSteps: 'اضغط على تفعيل الباقة ودفع 1500 دج عن طريق تطبيق BaridiMob لإصدار الكود ومصادقة المتجر فوراً.'
  },
  {
    id: 'pack-growth',
    name: 'باقة النمو المالي (Growth Pack)',
    badge: 'النمو والانتشار الخاطف',
    priceDzd: 3800,
    badgeColor: 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20',
    durationDays: 45,
    benefits: [
      'جميع ميزات باقة الانطلاق الأساسية',
      'تحديث تلقائي وترشيح عروضك في صدارة محركات بحث ريادة مرتين أسبوعياً',
      'بناء وتوليد 5 بوسترات تسويقية مخصصة لعروضك تلقائياً وبألوان الهوية',
      'دعم ترقية عرض المنتجات لخدمات التوصيل البري والمنزلي (Yalidine) لتأكيد أمان الزبائن',
      'الربط بالبيانات التحليلية لـ 15 زبون تواصلوا معك للوصول لسرعة إبرام الصفقات'
    ],
    salesPitch: 'مخصصة للمحلات والورش النشطة الراغبة بالانتقال من مجرد تواجد خجول إلى مضاعفة المبيعات اليومية واجتذاب زبائن من ولايات أخرى.',
    nextSteps: 'إتمام دفع 3800 دج CCP أو بريدي موب ورفع صورة الإثبات للحصول على البوسترات والمزايا تلقائياً.'
  },
  {
    id: 'pack-pro',
    name: 'باقة المحترفين الإخبارية (Pro Pack)',
    badge: 'المحترف النخبة',
    priceDzd: 7900,
    badgeColor: 'bg-brand-500/15 text-brand-400 border border-brand-500/25',
    durationDays: 60,
    benefits: [
      'جميع ميزات الباقات السابقة',
      'توثيق المتجر الشامل (بدون حدود لعرض المنتجات مع توفير الشارة الموثقة)',
      'بوابة متجر ريادة فرعي مخصص (ريادة.تك/متجرك) لنشر المنتجات خارج التطبيق',
      'لوحة تحليلية متكاملة (Platinum Analytics) لمراقبة وتحليل سلوك الزبائن والمشاهدات اليومية وعدد نقرات التواصل',
      'معالجة سريعة وأولوية للتحقق والموافقة على السلع في أقل من ساعتين'
    ],
    salesPitch: 'الحل الشامل من فئة النخبة للشركات والمصانع الجزائرية الناشئة ومقدمي الخدمات الذين يعتبرون المنصة مركز تشغيلهم الأساسي للتوظيف والبيع.',
    nextSteps: 'إتمام دفع 7900 دج CCP وتفعيل المتجر والموقع الفرعي بنجاح تام.'
  },
  {
    id: 'pack-boost',
    name: 'باقة التميز الفوري للمقالات والوظائف (Boost Pack)',
    badge: 'ترقية السلعة والوظائف',
    priceDzd: 1200,
    badgeColor: 'bg-amber-500/10 text-amber-400 border border-amber-500/20',
    durationDays: 14,
    benefits: [
      'تثبيت العرض أو الوظيفة المطلوبة في أعلى نتائج البحث لفئة الجزائر وتيزي وزو والبليدة',
      'إرسال إشعار دفع فوري (Push Alert) اختياري للمستقلين أو العمال المسجلين لمراجعة عرضك',
      'إطار ملون مضيء حول بطاقة التوظيف أو السلعة في خلاصة المنصة لجذب انتباه العابرين',
      'نسبة نقرات وصول محتملة تصل إلى 300% مقارنة بالعروض المجانية العادية'
    ],
    salesPitch: 'إذا كنت تبحث عن مبرمج عاجل، عامل شحن في مدينتك، أو لديك مخزون سلع ترغب بتصفيته سريعاً ففي خلال 48 ساعة ستحصل على اتصالك الأول بضمان ريادة.',
    nextSteps: 'دفع 1200 دج CCP وإضافة معرف السلعة أو عرض التوظيف ليترشح للصدارة تلقائياً.'
  },
  {
    id: 'pack-verification',
    name: 'باقة الأمان والموثوقية المطلقة (Verification Pack)',
    badge: 'موثّق رسمي',
    priceDzd: 2500,
    badgeColor: 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20',
    durationDays: 365,
    benefits: [
      'مراجعة وتدقيق بطاقة الحرفي، الهوية الوطنية وسجل الحرف والمهن للتاجر أو العامل',
      'اعتماد الشارة الفضية الدائرية (Verified ✓) للثقة الكاملة للزبائن',
      'أولوية حماية ووقاية حسابك من التقارير الوهمية أو كيد المنافسين',
      'تأكيد ربط الحساب البنكي وبريدي موب للتحويل اليدوي الموثوق دون تجميد أو تعليق'
    ],
    salesPitch: 'الثقة هي أغلى رأس مال في التجارة الإلكترونية بالجزائر. الزبائن تفضل الشراء من المتاجر التي قامت برفع وثائق واثبات الهوية الشخصية.',
    nextSteps: 'شحن صور الوثائق ودفع 2500 دج سنوياً للمراجعة والتقييم اليدوي الفوري.'
  }
];

export function getActiveUpgrades() {
  const isGold = localStorage.getItem('riyada_gold_verified_global') === 'true';
  const isPlat = localStorage.getItem('riyada_platinum_analytics_global') === 'true';
  return {
    isGold,
    isPlat,
    activeLevel: isPlat ? 'platinum' : isGold ? 'gold' : 'free'
  };
}
