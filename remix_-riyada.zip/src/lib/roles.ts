/**
 * Lightweight role system for RIYADA Algerian Marketplace:
 * - buyer (المشتري)
 * - seller (البائع)
 * - admin (المسؤول)
 */

export type UserRole = 'buyer' | 'seller' | 'admin';

export interface UserSession {
  role: UserRole;
  phone?: string;
  name?: string;
  workspaceId?: string;
}

const SESSION_KEY = 'riyada_auth_session_v4';

// Retrieve active session Role
export function getActiveSession(): UserSession {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to parse user session', e);
  }
  // Default fallback is buyer
  return { role: 'buyer' };
}

// Persist user role session
export function saveActiveSession(session: UserSession) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

// Fast check to see if role has clearance for a route
export function isAuthorized(requiredRoles: UserRole[]): boolean {
  const session = getActiveSession();
  return requiredRoles.includes(session.role);
}

// Terminate session
export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}
