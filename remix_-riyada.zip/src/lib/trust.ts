/**
 * RIYADA v23 Trust, Verification, and Anti-Fraud Engine
 * Generates scores for merchants, calculates reputation indexes, and lists reports.
 */

import { getDB } from './db';

export interface UserTrustProfile {
  id: string;
  score: number; // 0 to 100
  badgeType: 'none' | 'verified_merchant' | 'platinum_elite' | 'trusted_worker';
  totalSuccessfulCoordinations: number;
  unresolvedDisputes: number;
  createdProductsCount: number;
  algerianWilaya: string;
}

/**
 * Calculates a dynamic trust score for a workspace/user and determines badges.
 */
export async function calculateWorkspaceTrust(workspaceId: string): Promise<UserTrustProfile> {
  const db = await getDB();
  const allOrders = await db.getAll('orders') || [];
  const workspaceOrders = allOrders.filter((o: any) => o.workspaceId === workspaceId);

  // Math components
  let score = 70; // Starting baseline
  
  const successfulOrderCount = workspaceOrders.filter((o: any) => o.status === 'completed' || o.paymentStatus === 'accepted').length;
  const canceledOrderCount = workspaceOrders.filter((o: any) => o.status === 'canceled').length;
  
  // Successful transaction bonus
  score += successfulOrderCount * 5;
  
  // Cancellation penalty
  score -= canceledOrderCount * 8;

  // Let's check verification state in localStorage
  const isGold = localStorage.getItem(`riyada_gold_verified_${workspaceId}`) === 'true';
  const isPlat = localStorage.getItem(`riyada_platinum_analytics_${workspaceId}`) === 'true';

  if (isGold) score += 15;
  if (isPlat) score += 20;

  // Clamping to sane range
  const finalScore = Math.min(100, Math.max(10, score));

  let badgeType: UserTrustProfile['badgeType'] = 'none';
  if (isPlat && finalScore >= 85) {
    badgeType = 'platinum_elite';
  } else if (isGold || finalScore >= 80) {
    badgeType = 'verified_merchant';
  }

  return {
    id: workspaceId,
    score: finalScore,
    badgeType,
    totalSuccessfulCoordinations: successfulOrderCount,
    unresolvedDisputes: workspaceOrders.filter((o: any) => o.paymentStatus === 'disputed').length,
    createdProductsCount: (await db.getAll('products') || []).filter((p: any) => p.workspaceId === workspaceId).length,
    algerianWilaya: 'الجزائر',
  };
}

/**
 * Submits a fraud or scam report against a listing/user.
 * Stores in local DB as fallback.
 */
export async function submitFraudReport(report: {
  targetId: string;
  targetType: 'listing' | 'worker' | 'job';
  reporterDetails: string;
  reason: string;
  details: string;
}) {
  const reportData = {
    ...report,
    id: `REP-${Math.floor(Math.random() * 90000) + 10000}`,
    reportedAt: new Date().toISOString(),
    status: 'pending_review',
  };

  // Local fallback
  const db = await getDB();
  const existingReportsStr = localStorage.getItem('riyada_saved_reports_v23') || '[]';
  const list = JSON.parse(existingReportsStr);
  list.push(reportData);
  localStorage.setItem('riyada_saved_reports_v23', JSON.stringify(list));

  return reportData;
}

