/**
 * RIYADA PAYMENT STATE MACHINE
 * Enforces strict transitions between payment states for Order entries.
 */

export type PaymentState =
  | 'PENDING_PAYMENT'
  | 'PAYMENT_INITIATED'
  | 'WAITING_WEBHOOK'
  | 'PAID'
  | 'FAILED'
  | 'EXPIRED';

// Valid transitions dictionary
const VALID_TRANSITIONS: Record<PaymentState, PaymentState[]> = {
  PENDING_PAYMENT: ['PAYMENT_INITIATED', 'FAILED', 'EXPIRED'],
  PAYMENT_INITIATED: ['WAITING_WEBHOOK', 'PAID', 'FAILED', 'EXPIRED'],
  WAITING_WEBHOOK: ['PAID', 'FAILED', 'EXPIRED'],
  PAID: [], // Terminal successful state
  FAILED: ['PENDING_PAYMENT', 'PAYMENT_INITIATED'], // Can retry or re-initiate
  EXPIRED: ['PENDING_PAYMENT', 'PAYMENT_INITIATED'],
};

/**
 * Checks whether a state transition is valid under the state machine rule set.
 */
export function isValidTransition(from: PaymentState, to: PaymentState): boolean {
  const allowed = VALID_TRANSITIONS[from];
  return allowed ? allowed.includes(to) : false;
}

/**
 * Gets a human-friendly Arabic label for each payment state.
 */
export function getPaymentStateLabel(state: PaymentState): string {
  switch (state) {
    case 'PENDING_PAYMENT':
      return 'في انتظار بدء الدفع';
    case 'PAYMENT_INITIATED':
      return 'تم بدء عملية الدفع';
    case 'WAITING_WEBHOOK':
      return 'في انتظار تأكيد الشبكة المعالجة';
    case 'PAID':
      return 'مكتمل ومؤكد عبر المعالج';
    case 'FAILED':
      return 'فشلت عملية الدفع';
    case 'EXPIRED':
      return 'منتهي الصلاحية';
    default:
      return 'حالة غير معروفة';
  }
}
