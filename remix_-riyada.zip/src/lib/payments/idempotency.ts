/**
 * PAYMENT IDEMPOTENCY LOCK
 * Prevents double-processing of identical webhook transaction keys or order reference tokens.
 */

import { logTelemetry } from '../infrastructure';

const processedTransKeys = new Set<string>();

/**
 * Checks if a transaction has already been successfully processed.
 */
export function isProcessed(transactionId: string): boolean {
  return processedTransKeys.has(transactionId);
}

/**
 * Marks a transaction as successfully processed.
 */
export function markAsProcessed(transactionId: string): void {
  processedTransKeys.add(transactionId);
  logTelemetry({
    source: 'SYSTEM',
    type: 'success',
    message: `[IDEMPOTENCY_LOCK] Registered transaction "${transactionId}". Replay blocks are now armed.`
  });
}

/**
 * Releases a locked transaction if processing aborted midway.
 */
export function releaseLock(transactionId: string): void {
  processedTransKeys.delete(transactionId);
}
