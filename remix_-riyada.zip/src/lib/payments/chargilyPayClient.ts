/**
 * RIYADA PAYMENT GATEWAY - CHARGILY PAY V2 SDK CLIENT
 * Initializes the official @chargily/chargily-pay client.
 * Strictly isolates keys and configurations server-side (or in mock/secure contexts).
 */

import { ChargilyClient } from '@chargily/chargily-pay';
import { logTelemetry } from '../infrastructure';
import { sentryServer } from '../sentryServer';

const CHARGILY_SECRET_KEY = 
  (import.meta as any).env.CHARGILY_SECRET_KEY || 
  process.env.CHARGILY_SECRET_KEY || 
  '';

let clientInstance: ChargilyClient | null = null;

/**
 * Returns the instantiated Chargily Pay V2 Client if the secret is set.
 */
export function getChargilyClient(): ChargilyClient | null {
  if (!CHARGILY_SECRET_KEY) {
    return null;
  }
  if (!clientInstance) {
    const isLive = CHARGILY_SECRET_KEY.startsWith('api_li_');
    clientInstance = new ChargilyClient({
      api_key: CHARGILY_SECRET_KEY,
      mode: isLive ? 'live' : 'test',
    });
  }
  return clientInstance;
}

export interface ChargilyPayV2CheckoutResult {
  id: string;
  checkout_url: string;
  status: string;
  amount: number;
}

/**
 * Generates an checkout session via modern Chargily Pay V2 SDK.
 */
export async function createCheckoutSession(
  orderId: string,
  amount: number,
  customerEmail?: string
): Promise<ChargilyPayV2CheckoutResult> {
  const client = getChargilyClient();
  const APP_URL = window.location.origin;

  if (!client) {
    // Elegant sandbox fallback path using the merchant sandboxed link
    const sandboxUrl = `https://chargi.ly/wadoud?orderId=${orderId}&amount=${amount}&ref=riyada`;
    
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[CHARGILY_V2_CLIENT] Offline standby bypass active. Re-routing checkout to: "${sandboxUrl}"`
    });

    return {
      id: `ch_v2_sb_${crypto.randomUUID().slice(0, 8)}`,
      checkout_url: sandboxUrl,
      status: 'pending',
      amount,
    };
  }

  try {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[CHARGILY_V2_CLIENT] Building secure SDK checkout session for Order: "${orderId}"`
    });

    const checkout = await client.createCheckout({
      amount: amount,
      currency: 'dzd',
      success_url: `${APP_URL}/dashboard/orders?payment_status=success&orderId=${orderId}`,
      failure_url: `${APP_URL}/dashboard/orders?payment_status=failed&orderId=${orderId}`,
      webhook_endpoint: `${APP_URL}/api/webhooks/chargily`,
      metadata: {
        orderId: orderId,
      },
      description: `طلب شراء ريادة #${orderId}`,
      locale: 'ar',
    });

    return {
      id: checkout.id,
      checkout_url: checkout.checkout_url,
      status: checkout.status,
      amount: checkout.amount,
    };
  } catch (error: any) {
    sentryServer.captureApiError('/api/payments/createCheckout', error, { orderId, amount });
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[CHARGILY_V2_CLIENT] SDK Session Generation failed: ${error.message}`
    });
    throw error;
  }
}
