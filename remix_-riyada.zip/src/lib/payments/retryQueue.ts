/**
 * RIYADA PAYMENT RETRY ENGINE
 * Automates retry logic for payment actions and queue management if DB locks occur.
 */

import { sentryServer } from '../sentryServer';
import { logTelemetry } from '../infrastructure';

export interface RetryTask {
  id: string;
  orderId: string;
  action: () => Promise<boolean>;
  attempts: number;
  maxAttempts: number;
  createdAt: number;
}

const retryQueue: RetryTask[] = [];

/**
 * Pushes a sensitive database state update task to the retry pipeline.
 */
export async function enqueueRetry(
  orderId: string,
  action: () => Promise<boolean>,
  maxAttempts = 3
): Promise<boolean> {
  logTelemetry({
    source: 'SYSTEM',
    type: 'warning',
    message: `[RETRY_QUEUE] Enqueuing state transition task for Order: "${orderId}". Scheduling immediate execution.`
  });

  const task: RetryTask = {
    id: crypto.randomUUID(),
    orderId,
    action,
    attempts: 0,
    maxAttempts,
    createdAt: Date.now(),
  };

  retryQueue.push(task);
  return runTask(task);
}

/**
 * Executes a specific task from the queue with backoff and error logging.
 */
async function runTask(task: RetryTask): Promise<boolean> {
  task.attempts++;
  try {
    const success = await task.action();
    if (success) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'success',
        message: `[RETRY_SUCCESS] Order status successfully applied for "${task.orderId}" on attempt ${task.attempts}.`
      });
      // Remove from queue
      const idx = retryQueue.findIndex(t => t.id === task.id);
      if (idx !== -1) retryQueue.splice(idx, 1);
      return true;
    }
    
    throw new Error('Action returned false during execution.');
  } catch (error: any) {
    sentryServer.captureDatabaseError(`RETRY_ATTEMPT_${task.attempts}`, error, [task.orderId]);
    
    if (task.attempts >= task.maxAttempts) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'error',
        message: `[RETRY_FAILED_FATAL] Maximum retry attempts (${task.maxAttempts}) exhausted for Order: "${task.orderId}".`
      });
      return false;
    }

    // Exponential backoff simulation
    const delay = Math.pow(2, task.attempts) * 1000;
    logTelemetry({
      source: 'SYSTEM',
      type: 'info',
      message: `[RETRY_BACKOFF] Retrying Order "${task.orderId}" in ${delay / 1000}s... (Attempt ${task.attempts + 1}/${task.maxAttempts})`
    });

    return new Promise((resolve) => {
      setTimeout(async () => {
        resolve(await runTask(task));
      }, delay);
    });
  }
}

/**
 * Returns list of current active retry queue tasks.
 */
export function getRetryQueue(): RetryTask[] {
  return [...retryQueue];
}
