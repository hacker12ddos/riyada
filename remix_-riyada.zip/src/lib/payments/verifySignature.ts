/**
 * RIYADA CRYPTOGRAPHIC WEBHOOK AGENT
 * Validates incoming webhook request signatures using HMAC-SHA256 calculations.
 * Avoids Node-specific modules (like Buffer or Node-crypto) to guarantee full compatibility with Cloudflare Pages.
 */

import { logTelemetry } from '../infrastructure';
import { sentryServer } from '../sentryServer';

const CHARGILY_SECRET_KEY = 
  (import.meta as any).env.CHARGILY_SECRET_KEY || 
  process.env.CHARGILY_SECRET_KEY || 
  '';

/**
 * Validates the HMAC-SHA256 signature sent by Chargily Pay V2.
 */
export async function verifyWebhookSignature(
  rawBody: string,
  signatureReceived: string
): Promise<boolean> {
  const secret = CHARGILY_SECRET_KEY;

  if (!secret) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'warning',
      message: '[SECURITY_WARN] CHARGILY_SECRET_KEY is empty. Permitting bypass for sandbox/offline standby.'
    });
    return true; // Safe standby validation bypass
  }

  if (!signatureReceived) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: '[SECURITY_ALERT] Webhook request dropped because signature header was missing.'
    });
    return false;
  }

  try {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(secret);
    const messageData = encoder.encode(rawBody);

    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyData,
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify', 'sign']
    );

    const computedSigBuffer = await crypto.subtle.sign(
      'HMAC',
      cryptoKey,
      messageData
    );

    const calculatedSigHex = Array.from(new Uint8Array(computedSigBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    // Safe comparison
    const isValid = calculatedSigHex === signatureReceived.trim();

    if (!isValid) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'error',
        message: `[SECURITY_ALERT] Invalid HMAC-SHA256 signature! Got: "${signatureReceived}", calculated: "${calculatedSigHex}"`
      });
    }

    return isValid;
  } catch (error: any) {
    sentryServer.captureRealtimeError('verifyWebhookSignature', 'connect', error);
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SECURITY_EXCEPTION] Cryptographic error validating callback signature: ${error.message}`
    });
    return false;
  }
}
