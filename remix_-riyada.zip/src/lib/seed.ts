export const SEED_DATA = {
  products: [],
  orders: []
};

