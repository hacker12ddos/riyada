/**
 * Users and Store Workspaces service layer
 */
import { Workspace, getDB } from '../db';
import { createUser as infraCreateUser, getUser as infraGetUser } from '../infrastructure';
import { logTelemetry } from '../infrastructure';

/**
 * Creates/Registers a new seller store workspace safely or loads locally
 */
export async function createUser(workspace: Omit<Workspace, 'createdAt'>): Promise<Workspace> {
  try {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[SERVICE] Iniciating registration flow for store workspace: "${workspace.name}"`
    });
    return await infraCreateUser(workspace);
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Failed to initialize store profile: ${error.message}`
    });
    throw error;
  }
}

/**
 * Retrieves a store workspace profile info
 */
export async function getUser(id: string): Promise<Workspace | null> {
  try {
    const ws = await infraGetUser(id);
    
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'success',
      message: `[SERVICE_GET_USER] Workspace ID "${id}" ${ws ? 'found and synchronized' : 'not found'}.`
    });

    return ws;
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Failed to select user profile: ${error.message}`
    });
    return null;
  }
}
