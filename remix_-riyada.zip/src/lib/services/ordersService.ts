/**
 * Orders service layer ensuring frontend components never directly access storage/infra
 */
import { Order, getDB } from '../db';
import { createOrder as infraCreateOrder, updateOrderStatus as infraUpdateOrderStatus } from '../infrastructure';
import { logTelemetry } from '../infrastructure';

/**
 * Submits a new customer orders securely
 */
export async function createOrder(order: Omit<Order, 'id' | 'createdAt'>): Promise<Order> {
  try {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[SERVICE] Preparing checkout sequence for customer to workspace: "${order.workspaceId}"`
    });
    return await infraCreateOrder(order);
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Checkout sequence failed to persist: ${error.message}`
    });
    throw error;
  }
}

/**
 * Fetches listings of workspace/seller orders
 */
export async function getOrders(workspaceId?: string): Promise<Order[]> {
  try {
    const db = await getDB();
    const allOrders = await db.getAll('orders');
    const filtered = workspaceId ? allOrders.filter(o => o.workspaceId === workspaceId) : allOrders;

    // Simulate PostgreSQL query log
    const sql = workspaceId 
      ? `SELECT * FROM orders WHERE workspace_id = $1 ORDER BY created_at DESC`
      : `SELECT * FROM orders ORDER BY created_at DESC`;
    
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'success',
      sql,
      payload: workspaceId ? [workspaceId] : [],
      message: `[SERVICE_SELECT_ORDERS] Fetched ${filtered.length} orders successfully.`
    });

    return filtered;
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Failed to retrieve orders list: ${error.message}`
    });
    return [];
  }
}

/**
 * Updates an order status with automated live updates broadcast
 */
export async function updateOrderStatus(id: string, status: Order['status']): Promise<boolean> {
  try {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[SERVICE] Requested status transition to: "${status}" for Order: "${id}"`
    });
    return await infraUpdateOrderStatus(id, status);
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Status transition failed: ${error.message}`
    });
    return false;
  }
}
