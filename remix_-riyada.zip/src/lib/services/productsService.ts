/**
 * Products service layer ensuring frontend components never directly access storage/infra
 */
import { Product, getDB } from '../db';
import { createProduct as infraCreateProduct, updateProduct as infraUpdateProduct } from '../infrastructure';
import { logTelemetry } from '../infrastructure';

export interface ProductFilters {
  query?: string;
  category?: string;
  wilaya?: string;
  minPrice?: number;
  maxPrice?: number;
  vendorId?: string;
  workspaceId?: string;
}

export interface PagedProductsResult {
  products: Product[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}

/**
 * Creates a product with proper service isolation
 */
export async function createProduct(product: Omit<Product, 'id' | 'createdAt'>): Promise<Product> {
  try {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[SERVICE] Iniciating transaction for createProduct for: "${product.name}"`
    });
    return await infraCreateProduct(product);
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Failed to create product: ${error.message}`
    });
    throw error;
  }
}

/**
 * Updates a product securely
 */
export async function updateProduct(id: string, updates: Partial<Product>): Promise<boolean> {
  try {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'info',
      message: `[SERVICE] Executing updateProduct transaction on Product ID: "${id}"`
    });
    return await infraUpdateProduct(id, updates);
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Failed to update product: ${error.message}`
    });
    throw error;
  }
}

/**
 * Retrieves list of products with high performance search, filtration and scalable pagination.
 * Done through indexedDB locally and maps queries to simulated Aiven SELECT.
 */
export async function getProductsPaged(
  filters: ProductFilters = {},
  page: number = 1,
  limit: number = 12
): Promise<PagedProductsResult> {
  try {
    const db = await getDB();
    let allProducts = await db.getAll('products');

    // Chronological order descending by default
    allProducts.sort((a, b) => b.createdAt - a.createdAt);

    // Apply strict filters
    let filtered = allProducts;

    if (filters.workspaceId) {
      filtered = filtered.filter(p => p.workspaceId === filters.workspaceId);
    }
    if (filters.vendorId) {
      filtered = filtered.filter(p => p.vendorId === filters.vendorId);
    }
    if (filters.category) {
      filtered = filtered.filter(p => p.category === filters.category);
    }
    if (filters.wilaya) {
      filtered = filtered.filter(p => p.wilaya === filters.wilaya);
    }
    if (filters.minPrice !== undefined) {
      filtered = filtered.filter(p => p.price >= (filters.minPrice ?? 0));
    }
    if (filters.maxPrice !== undefined) {
      filtered = filtered.filter(p => p.price <= (filters.maxPrice ?? Infinity));
    }
    if (filters.query) {
      const q = filters.query.toLowerCase().trim();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(q) || 
        (p.description && p.description.toLowerCase().includes(q))
      );
    }

    // Paginate safely
    const total = filtered.length;
    const startIndex = (page - 1) * limit;
    const paginatedProducts = filtered.slice(startIndex, startIndex + limit);

    // Simulate PostgreSQL execution log
    const sqlFilters: string[] = [];
    if (filters.workspaceId) sqlFilters.push(`workspace_id = '${filters.workspaceId}'`);
    if (filters.category) sqlFilters.push(`category = '${filters.category}'`);
    if (filters.wilaya) sqlFilters.push(`wilaya = '${filters.wilaya}'`);

    const sqlCondition = sqlFilters.length > 0 ? `WHERE ${sqlFilters.join(' AND ')}` : '';
    const mockSql = `SELECT * FROM products ${sqlCondition} ORDER BY created_at DESC LIMIT ${limit} OFFSET ${startIndex}`;
    
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'success',
      sql: mockSql,
      message: `[SERVICE_SELECT_PAGED] Fetched page ${page} containing ${paginatedProducts.length}/${total} products.`
    });

    return {
      products: paginatedProducts,
      total,
      page,
      limit,
      hasMore: startIndex + limit < total
    };
  } catch (error: any) {
    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'error',
      message: `[SERVICE] Failed to retrieve products: ${error.message}`
    });
    return {
      products: [],
      total: 0,
      page,
      limit,
      hasMore: false
    };
  }
}
