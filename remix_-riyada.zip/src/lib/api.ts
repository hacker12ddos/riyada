/**
 * Centralized API Client for RIYADA production workflows
 * Handles all outgoing requests, validation checks, maintaining safe maintainability
 * and beautiful fail-safes.
 */
import { PagedProductsResult, ProductFilters, getProductsPaged, createProduct, updateProduct } from './services/productsService';
import { createOrder, getOrders, updateOrderStatus } from './services/ordersService';
import { createUser, getUser } from './services/usersService';
import { createSnapshot, restoreSnapshot, connect } from './infrastructure';
import { FEATURE_FLAGS, SITE_MAINTENANCE } from './constants';
import { logTelemetry } from './infrastructure';
import { sentryServer } from './sentryServer';
import { sanitizePayload } from './security/sanitize';
import { countAndCheckRateLimit } from './security/rateLimit';
import { validateProductPayload, validateOrderPayload } from './security/validate';

// Type definitions for our Centralized System Health Checks
export interface HealthStatus {
  database: 'online' | 'degraded' | 'offline';
  realtime: 'online' | 'simulation' | 'offline';
  backup: 'active' | 'simulation' | 'incomplete';
  version: string;
  maintenanceMode: boolean;
  featureFlags: typeof FEATURE_FLAGS;
}

export const API = {
  // ==========================================================
  // ENVIRONMENT VALIDATION ENGINE
  // ==========================================================
  validateEnvironment: (): { isValid: boolean; errors: string[] } => {
    const errors: string[] = [];
    
    // Configured variables in our system
    const ablyApiKey = (import.meta as any).env.VITE_ABLY_API_KEY || '';
    const npointId = (import.meta as any).env.VITE_NPOINT_ID || '';

    if (!ablyApiKey) {
      errors.push('VITE_ABLY_API_KEY (سائل الأنبوب المباشر Ably) غير متوفر، تم تفعيل محاكي البث.');
    }
    if (!npointId) {
      errors.push('VITE_NPOINT_ID (النسخ الاحتياطي السحابي npoint.io) غير متوفر، تم تفعيل الحفظ المحلي.');
    }

    // Always valid because Ably and Npoint are gracefully simulated/fallback
    return {
      isValid: true,
      errors
    };
  },

  // ==========================================================
  // 10. HEALTH CHECK ENDPOINT SIMULATION & DEPLOYMENT DIAGS
  // ==========================================================
  getHealth: async (): Promise<HealthStatus> => {
    try {
      const res = await fetch('/api/health');
      if (!res.ok) {
        throw new Error(`Health status check failed with HTTP ${res.status}`);
      }
      const data = await res.json();
      return {
        database: data.database,
        realtime: (import.meta as any).env.VITE_ABLY_API_KEY ? 'online' : 'simulation',
        backup: (import.meta as any).env.VITE_NPOINT_ID ? 'active' : 'simulation',
        version: 'v23.5.0-production-stabilized',
        maintenanceMode: SITE_MAINTENANCE,
        featureFlags: FEATURE_FLAGS
      };
    } catch (err) {
      return {
        database: 'offline',
        realtime: 'simulation',
        backup: 'simulation',
        version: 'v23.5.0-production-stabilized',
        maintenanceMode: SITE_MAINTENANCE,
        featureFlags: FEATURE_FLAGS
      };
    }
  },

  // ==========================================================
  // 12. ASYNC BACKUP SYSTEM ENDPOINT
  // ==========================================================
  triggerBackup: async (): Promise<{ success: boolean; message: string }> => {
    if (SITE_MAINTENANCE) {
      return { success: false, message: 'النظام حالياً في وضع الصيانة العازلة. تم تعليق عمليات المزامنة.' };
    }
    return await createSnapshot();
  },

  restoreBackup: async (): Promise<{ success: boolean; message: string }> => {
    if (SITE_MAINTENANCE) {
      return { success: false, message: 'النظام حالياً في وضع الصيانة العازلة.' };
    }
    return await restoreSnapshot();
  },

  // ==========================================================
  // DATA SERVICES EXPOSED CENTRALLY (DO NOT FETCH SCATTERED)
  // ==========================================================
  // ==========================================================
  products: {
    getProductsPaged: async (filters: ProductFilters = {}, page: number = 1, limit: number = 12): Promise<PagedProductsResult> => {
      if (SITE_MAINTENANCE) {
        return { products: [], total: 0, page, limit, hasMore: false };
      }
      try {
        // Sanitize filters query to block script injections in search box
        if (filters.query) {
          filters.query = filters.query.replace(/<[^>]*>/g, '').trim();
        }
        return await getProductsPaged(filters, page, limit);
      } catch (error: any) {
        sentryServer.captureApiError('/api/products/paged', error, filters);
        throw error;
      }
    },
    create: async (payload: any) => {
      if (SITE_MAINTENANCE) throw new Error('لا يمكن إضافة معروضات جديدة تحت الصيانة الطارئة.');
      
      // 1. IP/Workspace Rate Limiting Check
      const targetWorkspace = payload?.workspaceId || 'system';
      const rlimit = countAndCheckRateLimit(`product_create_${targetWorkspace}`, 5, 60000);
      if (!rlimit.allowed) {
        throw new Error(rlimit.message || 'تم تجاوز معدل إضافة المنتجات المسموح به.');
      }

      // 2. Schema Structure & Key Verification
      const validation = validateProductPayload(payload);
      if (!validation.isValid) {
        throw new Error(validation.errors.join(' | '));
      }

      // 3. XSS Sanitization & Mass-assignment key defense
      const sanitized = sanitizePayload(validation.sanitized);

      try {
        return await createProduct(sanitized);
      } catch (error: any) {
        sentryServer.captureApiError('/api/products/create', error, payload);
        throw error;
      }
    },
    update: async (id: string, updates: any) => {
      if (SITE_MAINTENANCE) throw new Error('التعديل غير مسموح خلال فترة الصيانة.');
      
      // Standard dynamic keys sanitization
      const cleanUpdates = sanitizePayload(updates);

      try {
        return await updateProduct(id, cleanUpdates);
      } catch (error: any) {
        sentryServer.captureApiError(`/api/products/update/${id}`, error, updates);
        throw error;
      }
    }
  },

  orders: {
    list: async (workspaceId?: string) => {
      try {
        return await getOrders(workspaceId);
      } catch (error: any) {
        sentryServer.captureApiError('/api/orders/list', error, { workspaceId });
        throw error;
      }
    },
    create: async (payload: any) => {
      if (SITE_MAINTENANCE || !FEATURE_FLAGS.ENABLE_PAYMENTS) {
        throw new Error('عمليات الدفع والطلبيات المباشرة معطلة حالياً.');
      }

      // 1. Rate Limiting Check on Checkout
      const clientIdentifier = payload?.customerPhone || 'guest';
      const rlimit = countAndCheckRateLimit(`order_create_${clientIdentifier}`, 3, 60000);
      if (!rlimit.allowed) {
        throw new Error(rlimit.message || 'تم حجب عملية الدفع مؤقتاً لتفادي الشراء المكرر.');
      }

      // 2. Strict Schema validation
      const validation = validateOrderPayload(payload);
      if (!validation.isValid) {
        throw new Error(validation.errors.join(' | '));
      }

      // 3. Complete Field Sanitization
      const sanitized = sanitizePayload(validation.sanitized);

      try {
        return await createOrder(sanitized);
      } catch (error: any) {
        sentryServer.captureApiError('/api/orders/create', error, payload);
        throw error;
      }
    },
    updateStatus: async (id: string, status: any) => {
      try {
        return await updateOrderStatus(id, status);
      } catch (error: any) {
        sentryServer.captureApiError(`/api/orders/updateStatus/${id}`, error, { status });
        throw error;
      }
    }
  },

  payments: {
    createCheckout: async (orderId: string, amount: number, email?: string) => {
      try {
        const response = await fetch('/api/payments/createCheckout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ orderId, amount, email })
        });
        const result = await response.json();
        if (!response.ok || !result.success) {
          throw new Error(result.error || 'فشلت معالجة بدء دفع الطلبية.');
        }
        return result.data;
      } catch (error: any) {
        sentryServer.captureApiError('/api/payments/createCheckout', error, { orderId, amount });
        throw error;
      }
    }
  },

  users: {
    createWorkspace: async (payload: any) => {
      // Basic rate limitation & safety filters
      const name = payload?.name || 'unnamed';
      const rlimit = countAndCheckRateLimit(`workspace_register_${name}`, 2, 60000);
      if (!rlimit.allowed) {
        throw new Error(rlimit.message);
      }

      const sanitized = sanitizePayload(payload);

      try {
        return await createUser(sanitized);
      } catch (error: any) {
        sentryServer.captureApiError('/api/users/createWorkspace', error, payload);
        throw error;
      }
    },
    getWorkspace: async (id: string) => {
      try {
        return await getUser(id);
      } catch (error: any) {
        sentryServer.captureApiError(`/api/users/getWorkspace/${id}`, error);
        throw error;
      }
    }
  }
};
