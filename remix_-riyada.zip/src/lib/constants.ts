/**
 * RIYADA Realtime Events Engine and Environment Constant Registry
 */

// Central Realtime Event Constants
export const PRODUCT_CREATED = 'product_created';
export const PRODUCT_UPDATED = 'product_updated';
export const ORDER_CREATED = 'order_created';
export const ORDER_UPDATED = 'order_status_updated';
export const SELLER_NOTIFICATION = 'seller_notification';

// Central Feature Toggles & System Settings
// Reads directly from Vite import.meta.env with safe offline fallbacks
export const FEATURE_FLAGS = {
  ENABLE_AI: (import.meta as any).env.VITE_ENABLE_AI !== 'false', // Default true
  ENABLE_PAYMENTS: (import.meta as any).env.VITE_ENABLE_PAYMENTS !== 'false', // Default true
  ENABLE_REALTIME: (import.meta as any).env.VITE_ENABLE_REALTIME !== 'false', // Default true
  ENABLE_CHAT: (import.meta as any).env.VITE_ENABLE_CHAT === 'true', // Default false
};

// Site Maintenance Control
export const SITE_MAINTENANCE = (import.meta as any).env.VITE_SITE_MAINTENANCE === 'true';
