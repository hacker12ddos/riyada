/**
 * RIYADA SECURITY LAYER - RATE LIMITING
 * Monitors client trigger rates per action (e.g., product creation, order submission, authentication attempts).
 */

interface RateTracker {
  timestamps: number[];
}

const rateLimitRegistry: Record<string, RateTracker> = {};

export interface RateLimitResult {
  allowed: boolean;
  timeLeftSeconds?: number;
  statusCode: number;
  message?: string;
}

/**
 * Validates whether the call is within threshold.
 * Block action if frequency is too high.
 */
export function countAndCheckRateLimit(
  actionKey: string, 
  limit: number, 
  windowMs: number
): RateLimitResult {
  const now = Date.now();
  
  if (!rateLimitRegistry[actionKey]) {
    rateLimitRegistry[actionKey] = { timestamps: [] };
  }

  const tracker = rateLimitRegistry[actionKey];
  
  // Clean timestamps outside of current window limit
  tracker.timestamps = tracker.timestamps.filter(ts => now - ts < windowMs);

  if (tracker.timestamps.length >= limit) {
    const earliestAllowed = tracker.timestamps[0] + windowMs;
    const timeLeft = Math.ceil((earliestAllowed - now) / 1000);
    
    return {
      allowed: false,
      timeLeftSeconds: timeLeft > 0 ? timeLeft : 1,
      statusCode: 429,
      message: `تم حجب الطلب مؤقتاً لتجاوز معدل الاستخدام المسموح. يرجى الانتظار ${timeLeft} ثانية والاتصال بالدعم إذا كنت بحاجة لترقية حصتك.`
    };
  }

  // Push latest timestamp
  tracker.timestamps.push(now);
  return {
    allowed: true,
    statusCode: 200
  };
}

/**
 * Resets tracker for an action (e.g., on successful complete under special circumstances)
 */
export function clearRateLimit(actionKey: string) {
  if (rateLimitRegistry[actionKey]) {
    delete rateLimitRegistry[actionKey];
  }
}
