/**
 * RIYADA SECURITY LAYER - SCHEMA VALIDATION
 * Enforces strict type verification, schema validation, prevents mass assignment, 
 * and handles UUID / Algerian contact details verification.
 */

import { stripHtmlTags } from './sanitize';

// UUID Format verification
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function isValidUUID(id: string): boolean {
  return UUID_REGEX.test(id);
}

// Algerian phone number structure validation
export function isValidAlgerianPhone(phone: string): boolean {
  const clean = phone.replace(/[\s.-]/g, '');
  return /^(05|06|07|213|02)\d{8,9}$/.test(clean);
}

/**
 * Validates a new Product creation payload
 */
export function validateProductPayload(data: any): { isValid: boolean; errors: string[]; sanitized: any } {
  const errors: string[] = [];
  
  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['ترتيب البيانات غير صالح.'], sanitized: null };
  }

  // White-listed fields to prevent mass assignment
  const allowedKeys = ['name', 'price', 'category', 'description', 'image', 'wilaya', 'vendorId', 'workspaceId', 'stock'];
  const extraKeys = Object.keys(data).filter(k => !allowedKeys.includes(k));
  
  if (extraKeys.length > 0) {
    errors.push(`بيانات مشبوهة أو حقول غير مصرح بها: ${extraKeys.join(', ')}`);
  }

  const name = typeof data.name === 'string' ? stripHtmlTags(data.name).trim() : '';
  const price = Number(data.price);
  const category = typeof data.category === 'string' ? stripHtmlTags(data.category).trim() : 'عام';
  const description = typeof data.description === 'string' ? stripHtmlTags(data.description).trim() : '';
  const image = typeof data.image === 'string' ? data.image.trim() : null;
  const wilaya = typeof data.wilaya === 'string' ? stripHtmlTags(data.wilaya).trim() : 'الجزائر';
  const workspaceId = typeof data.workspaceId === 'string' ? stripHtmlTags(data.workspaceId).trim() : '';
  const stock = data.stock !== undefined ? parseInt(data.stock, 10) : 10;

  if (name.length < 3 || name.length > 100) {
    errors.push('اسم المنتج يجب أن يتراوح بين 3 و 100 حرف.');
  }
  if (isNaN(price) || price < 0 || price > 10000000) {
    errors.push('سعر المنتج يجب أن يكون مبلغ منطقي وموجب (أقل من 100 مليون سنتيم).');
  }
  if (isNaN(stock) || stock < 0) {
    errors.push('الكمية المتوفرة بالسوق غير صالحة.');
  }
  if (!workspaceId) {
    errors.push('معرّف مساحة العمل (Workspace ID) مطلوب للتوثيق.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: errors.length === 0 ? {
      name,
      price,
      category,
      description,
      image,
      wilaya,
      workspaceId,
      stock,
      updatedAt: Date.now()
    } : null
  };
}

/**
 * Validates a new Order checked-out by a client
 */
export function validateOrderPayload(data: any): { isValid: boolean; errors: string[]; sanitized: any } {
  const errors: string[] = [];

  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['ترتيب البيانات غير صالح.'], sanitized: null };
  }

  // White-listed keys
  const allowedKeys = ['workspaceId', 'customerName', 'customerPhone', 'wilaya', 'address', 'items', 'total', 'notes', 'paymentMethod'];
  const extraKeys = Object.keys(data).filter(k => !allowedKeys.includes(k));
  
  if (extraKeys.length > 0) {
    errors.push(`بيانات مشبوهة أو حقول غير مصرح بها: ${extraKeys.join(', ')}`);
  }

  const workspaceId = typeof data.workspaceId === 'string' ? stripHtmlTags(data.workspaceId).trim() : '';
  const customerName = typeof data.customerName === 'string' ? stripHtmlTags(data.customerName).trim() : '';
  const customerPhone = typeof data.customerPhone === 'string' ? stripHtmlTags(data.customerPhone).trim() : '';
  const wilaya = typeof data.wilaya === 'string' ? stripHtmlTags(data.wilaya).trim() : '';
  const address = typeof data.address === 'string' ? stripHtmlTags(data.address).trim() : '';
  const notes = typeof data.notes === 'string' ? stripHtmlTags(data.notes).trim() : '';
  const paymentMethod = typeof data.paymentMethod === 'string' ? stripHtmlTags(data.paymentMethod).trim() : 'BaridiMob';
  const total = Number(data.total);

  if (!workspaceId) errors.push('معرّف المتجر غير صالح.');
  if (customerName.length < 3) errors.push('اسم المشكل المسجل يجب أن يتجاوز 3 أحرف لسلامة الاتصال.');
  if (!isValidAlgerianPhone(customerPhone)) errors.push('رقم الهاتف غير متوافق مع الاتصالات الجزائرية.');
  if (!wilaya) errors.push('يرجى تحديد ولاية التوصيل.');
  if (isNaN(total) || total <= 0) errors.push('قيمة الطلبية الاجمالية غير صحيحة.');
  
  // Safe validation of items array
  let safeItems = [];
  if (Array.isArray(data.items)) {
    for (const item of data.items) {
      if (item && typeof item === 'object') {
        const pId = typeof item.productId === 'string' ? item.productId : '';
        const qty = parseInt(item.quantity, 10);
        const name = typeof item.name === 'string' ? stripHtmlTags(item.name) : 'سلعة';
        const price = Number(item.price);
        
        if (qty > 0 && price >= 0) {
          safeItems.push({ productId: pId, quantity: qty, name, price });
        }
      }
    }
  }

  if (safeItems.length === 0) {
    errors.push('الطلبية فارغة من المعروضات.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitized: errors.length === 0 ? {
      workspaceId,
      customerName,
      customerPhone,
      wilaya,
      address,
      items: safeItems,
      total,
      notes,
      paymentMethod,
      paymentStatus: 'unpaid',
      status: 'pending'
    } : null
  };
}
