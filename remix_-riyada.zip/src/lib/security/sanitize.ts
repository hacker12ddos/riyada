/**
 * RIYADA SECURITY LAYER - INPUT SANITIZATION
 * Implements strict browser-safe sanitization to prevent Cross-Site Scripting (XSS),
 * HTML/JS injections, and other malicious vector injections.
 */

/**
 * Sanitizes a string to prevent XSS and HTML code execution.
 * Replaces critical characters with safe HTML entities.
 */
export function sanitizeString(val: string): string {
  if (typeof val !== 'string') return '';
  return val
    .trim()
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .replace(/javascript:/gi, '[REDACTED_JS_PROTOCOL]');
}

/**
 * Strips all HTML tags entirely for completely flat string parameters like titles, phones, usernames.
 */
export function stripHtmlTags(val: string): string {
  if (typeof val !== 'string') return '';
  const clean = val.replace(/<[^>]*>/g, '');
  return sanitizeString(clean);
}

/**
 * Object deep-cleaner to protect API payload ingestion from dirty/untrusted user keys.
 */
export function sanitizePayload<T extends Record<string, any>>(payload: T): T {
  const result = {} as Record<string, any>;
  for (const key in payload) {
    if (Object.prototype.hasOwnProperty.call(payload, key)) {
      const value = payload[key];
      if (typeof value === 'string') {
        result[key] = sanitizeString(value);
      } else if (value && typeof value === 'object' && !Array.isArray(value)) {
        result[key] = sanitizePayload(value);
      } else if (Array.isArray(value)) {
        result[key] = value.map(item => {
          if (typeof item === 'string') return sanitizeString(item);
          if (item && typeof item === 'object') return sanitizePayload(item);
          return item;
        });
      } else {
        result[key] = value;
      }
    }
  }
  return result as T;
}
