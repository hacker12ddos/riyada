/**
 * RIYADA - SENTRY CENTRAL MONITORING INITIALIZATION
 * Connects the marketplace error telemetry pipeline seamlessly to Sentry
 */
import * as Sentry from '@sentry/react';

const SENTRY_DSN = (import.meta as any).env.VITE_SENTRY_DSN || 'https://66877cd2b18f670e290e6657496455c7@o4511451247345664.ingest.de.sentry.io/4511451275133008';
const SENTRY_ENV = (import.meta as any).env.VITE_SENTRY_ENV || 'development';

export function initSentry() {
  if (!SENTRY_DSN) {
    console.warn('[SENTRY] DSN is missing from environment. Sentry operates in Offline Passive Simulation mode.');
    return;
  }

  try {
    Sentry.init({
      dsn: SENTRY_DSN,
      environment: SENTRY_ENV,
      // Lightweight performance tracking under production load
      tracesSampleRate: SENTRY_ENV === 'production' ? 0.1 : 1.0,
      
      // Strict privacy boundaries: Filter out Algerian payment secrets, passwords & user tokens
      beforeSend(event) {
        if (event.request && event.request.headers) {
          delete event.request.headers['Authorization'];
          delete event.request.headers['cookie'];
        }
        
        // Remove potentially sensitive payload fields from event details
        if (event.extra) {
          const sensitiveKeys = [
            'password', 'token', 'payment_tx_id', 'receiptImage', 
            'receipt_image', 'payment_proof_file', 'paymentProofFile', 
            'ccp_reference', 'transaction_reference'
          ];
          
          sensitiveKeys.forEach(key => {
            if (key in event.extra) {
              event.extra[key] = '[FILTERED_FOR_ALGERIAN_CONSUMER_PRIVACY]';
            }
          });
        }
        
        return event;
      },
    });

    console.log(`[SENTRY] Successfully initialized on environment: "${SENTRY_ENV}"`);
  } catch (error) {
    console.error('[SENTRY] Failed to initialize Sentry SDK:', error);
  }
}
