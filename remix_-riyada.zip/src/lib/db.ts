import { openDB, DBSchema, IDBPDatabase } from 'idb';

export interface Workspace {
  id: string;
  name: string;
  type: string;
  phone: string;
  createdAt: number;
  settings: {
    wilaya: string;
    deliveryFees: Record<string, number>;
  }
}

export interface Product {
  id: string;
  workspaceId: string;
  vendorId?: string;
  vendorName?: string;
  wilaya?: string;
  name: string;
  price: number;
  stock: number;
  category: string;
  image?: string | null;
  description?: string;
  verified?: boolean;
  sponsored?: boolean;
  dynamicData?: Record<string, any>;
  createdAt: number;
}

export interface Order {
  id: string;
  workspaceId: string;
  customerId: string;
  items: Array<{ productId: string; name: string; quantity: number; price: number }>;
  total: number;
  deliveryFee: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled' | 'initiated' | 'awaiting_seller_confirmation' | 'seller_confirmed' | 'payment_pending' | 'paid' | 'expired' | 'refused';
  wilaya: string;
  address: string;
  notes: string;
  createdAt: number;
  riskScore?: number;
  paymentMethod?: string;
  paymentStatus?: string;
  receiptImage?: string;
  transactionReference?: string;
  paymentTxId?: string;
  paymentProofFile?: string;
  verifiedBySeller?: boolean;
}

export interface Customer {
  id: string;
  workspaceId: string;
  name: string;
  phone: string;
  blacklisted: boolean;
  ordersCount: number;
  totalSpent: number;
  createdAt: number;
}

export interface Interaction {
  id: string;
  productId: string;
  type: 'view' | 'whatsapp' | 'favorite' | 'report';
  timestamp: number;
  userId?: string;
  vendorId?: string;
}

export interface Favorite {
  id: string; // productId
  timestamp: number;
}

interface RiyadaDB extends DBSchema {
  workspaces: {
    key: string;
    value: Workspace;
  };
  products: {
    key: string;
    value: Product;
    indexes: { 'by-workspace': string };
  };
  orders: {
    key: string;
    value: Order;
    indexes: { 'by-workspace': string; 'by-customer': string };
  };
  customers: {
    key: string;
    value: Customer;
    indexes: { 'by-workspace': string; 'by-phone': string };
  };
  interactions: {
    key: string;
    value: Interaction;
    indexes: { 'by-product': string; 'by-type': string; 'by-vendor': string };
  };
  favorites: {
    key: string;
    value: Favorite;
  };
}

let dbPromise: Promise<IDBPDatabase<RiyadaDB>> | null = null;

export const getDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<RiyadaDB>('riyada_os', 2, {
      upgrade(db, oldVersion, newVersion, transaction) {
        if (!db.objectStoreNames.contains('workspaces')) {
          db.createObjectStore('workspaces', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('products')) {
          const productStore = db.createObjectStore('products', { keyPath: 'id' });
          productStore.createIndex('by-workspace', 'workspaceId');
        }
        if (!db.objectStoreNames.contains('orders')) {
          const orderStore = db.createObjectStore('orders', { keyPath: 'id' });
          orderStore.createIndex('by-workspace', 'workspaceId');
          orderStore.createIndex('by-customer', 'customerId');
        }
        if (!db.objectStoreNames.contains('customers')) {
          const customerStore = db.createObjectStore('customers', { keyPath: 'id' });
          customerStore.createIndex('by-workspace', 'workspaceId');
          customerStore.createIndex('by-phone', 'phone');
        }
        if (!db.objectStoreNames.contains('interactions')) {
          const interactionStore = db.createObjectStore('interactions', { keyPath: 'id' });
          interactionStore.createIndex('by-product', 'productId');
          interactionStore.createIndex('by-type', 'type');
          interactionStore.createIndex('by-vendor', 'vendorId');
        }
        if (!db.objectStoreNames.contains('favorites')) {
          db.createObjectStore('favorites', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
};

// Workspace Operations
export const createWorkspace = async (workspace: Omit<Workspace, 'createdAt'>) => {
  const db = await getDB();
  const newWorkspace = { ...workspace, createdAt: Date.now() };
  await db.put('workspaces', newWorkspace);

  // Synchronize to Aiven & Ably
  try {
    const { createUser } = await import('./infrastructure');
    await createUser(workspace);
  } catch (e) {
    console.warn('Postgres/Ably sync bypassed for workspace:', e);
  }

  return newWorkspace;
};

export const getWorkspaces = async () => {
  const db = await getDB();
  return db.getAll('workspaces');
};

export const getWorkspace = async (id: string) => {
  const db = await getDB();
  return db.get('workspaces', id);
};

// Generic CRUD operations scoped by workspace
export const getItemsByWorkspace = async <T extends 'products' | 'orders' | 'customers'>(
  storeName: T,
  workspaceId: string
) => {
  const db = await getDB();
  return db.getAllFromIndex(storeName as any, 'by-workspace', workspaceId) as Promise<RiyadaDB[T]['value'][]>;
};

export const getAllItems = async <T extends 'workspaces' | 'products' | 'orders' | 'customers' | 'interactions' | 'favorites'>(
  storeName: T
) => {
  const db = await getDB();
  return db.getAll(storeName);
};

export const addItem = async <T extends 'products' | 'orders' | 'customers'>(
  storeName: T,
  item: any
) => {
  const db = await getDB();
  const payload = { ...item, createdAt: Date.now() };
  await db.put(storeName, payload);

  // Primary Source of Truth: Sync relational write to Aiven PostgreSQL & Ably Realtime Network
  try {
    const infra = await import('./infrastructure');
    if (storeName === 'products') {
      await infra.createProduct(item);
    } else if (storeName === 'orders') {
      await infra.createOrder(item);
    } else if (storeName === 'customers') {
      const sql = `INSERT INTO customers (id, workspace_id, name, phone, blacklisted, orders_count, total_spent, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) ON CONFLICT(workspace_id, phone) DO UPDATE SET orders_count = customers.orders_count + 1`;
      await infra.query(sql, [
        item.id, item.workspaceId, item.name, item.phone, 
        item.blacklisted ? 1 : 0, item.ordersCount || 0, 
        item.totalSpent || 0, payload.createdAt
      ]);
    }
  } catch (e) {
    console.warn('Aiven/Ably telemetry sync bypassed:', e);
  }
};

// Expose required production infrastructure modules directly from db.ts for full compliance
export { 
  connect, query, 
  createProduct, getProducts, updateProduct, 
  createOrder, getOrders, updateOrderStatus, 
  createUser, getUser, 
  publish, subscribe, 
  createSnapshot, restoreSnapshot 
} from './infrastructure';

export const clearItems = async (
  storeName: 'products' | 'orders' | 'customers' | 'interactions' | 'favorites'
) => {
  const db = await getDB();
  await db.clear(storeName);
};


// Tracking and Favorites
export const trackInteraction = async (productId: string, type: 'view' | 'whatsapp' | 'favorite' | 'report', vendorId?: string) => {
  const db = await getDB();
  const interaction: Interaction = {
    id: crypto.randomUUID(),
    productId,
    type,
    timestamp: Date.now(),
    vendorId,
  };
  await db.put('interactions', interaction);
};

export const toggleFavorite = async (productId: string) => {
  const db = await getDB();
  const existing = await db.get('favorites', productId);
  if (existing) {
    await db.delete('favorites', productId);
    return false; // not favorited anymore
  } else {
    await db.put('favorites', { id: productId, timestamp: Date.now() });
    await trackInteraction(productId, 'favorite');
    return true; // favorited
  }
};

export const getFavorites = async () => {
  const db = await getDB();
  return db.getAll('favorites');
};

export const isFavorite = async (productId: string) => {
  const db = await getDB();
  const fav = await db.get('favorites', productId);
  return !!fav;
};

export const getInteractionsByVendor = async (vendorId: string) => {
  const db = await getDB();
  // We added index 'by-vendor' in upgrade but IDB might need version bump if it was already created at version 2.
  // Assuming it's clean for now or we fallback to querying all and filtering.
  try {
    return await db.getAllFromIndex('interactions', 'by-vendor', vendorId);
  } catch (e) {
    const all = await db.getAll('interactions');
    return all.filter(i => i.vendorId === vendorId);
  }
};

// Wilayas utility for Algeria
export const ALGERIAN_WILAYAS = [
  "أدرار", "الشلف", "الأغواط", "أم البواقي", "باتنة", "بجاية", "بسكرة", "بشار",
  "البليدة", "البويرة", "تمنراست", "تبسة", "تلمسان", "تيارت", "تيزي وزو", "الجزائر",
  "الجلفة", "جيجل", "سطيف", "سعيدة", "سكيكدة", "سيدي بلعباس", "عنابة", "قالمة",
  "قسنطينة", "المدية", "مستغانم", "المسيلة", "معسكر", "ورقلة", "وهران", "البيض",
  "إيليزي", "برج بوعريريج", "بومرداس", "الطارف", "تندوف", "تيسمسيلت", "الوادي",
  "خنشلة", "سوق أهراس", "تيبازة", "ميلة", "عين الدفلى", "النعامة", "عين تموشنت",
  "غرداية", "غليزان", "تيميمون", "برج باجي مختار", "أولاد جلال", "بني عباس",
  "إن صالح", "إن قزام", "تقرت", "جانت", "المغير", "المنيعة"
].map((name, index) => ({ id: (index + 1).toString().padStart(2, '0'), name }));
