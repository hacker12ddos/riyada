/**
 * RIYADA v23 Command Helper Library
 * One-click copyable deploy commands for terminal. Zero jargon.
 */

export interface TerminalCommand {
  id: string;
  label: string;
  command: string;
  description: string;
  category: 'vercel' | 'local';
}

export const DEPLOYMENT_COMMANDS: TerminalCommand[] = [
  {
    id: 'ver-login',
    label: 'تسجيل الدخول إلى فيرسيل',
    command: 'vercel login',
    description: 'يقوم بربط موجه الأوامر بحسابك على Vercel لتمكين الرفع والتحكم بمشاريعك مجاناً.',
    category: 'vercel'
  },
  {
    id: 'ver-link',
    label: 'ربط المشروع الحالي بفيرسيل',
    command: 'vercel link',
    description: 'يربط الكود البرمجي الحالي بمشروع فيرسيل السحابي مباشرةً عبر خطوتين تفاعليتين.',
    category: 'vercel'
  },
  {
    id: 'ver-deploy',
    label: 'النشر المباشر (بيئة التجريب)',
    command: 'vercel deploy',
    description: 'يرفع الكود الحالي ويمنحك رابط تجريبي فوري لمشاركته مع زملائك.',
    category: 'vercel'
  },
  {
    id: 'ver-prod',
    label: 'النشر الإنتاجي النهائي الحسابي',
    command: 'vercel deploy --prod',
    description: 'ينشر النسخة المعتمدة النهائية الرسمية للمتجر على خوادم الويب المجانية.',
    category: 'vercel'
  }
];
