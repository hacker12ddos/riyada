import { getAllItems, getDB, Product, Order, Customer, Workspace } from './db';
import { getWorkers, getJobs, getApplications, saveWorkers, saveJobs, saveApplications, WorkerProfile, JobPost, JobApplication } from './economy';

export interface AuditIssue {
  id: string;
  system: 'marketplace' | 'services' | 'jobs' | 'workers' | 'trust' | 'payments' | 'integrity';
  severity: 'warning' | 'error' | 'critical';
  title: string;
  description: string;
  affectedId: string;
  details?: string;
  repairable: boolean;
  repairType: string;
}

export interface SystemHealthState {
  marketplaceScore: number; // 0 - 100
  trustScore: number; // 0 - 100
  paymentsScore: number; // 0 - 100
  fraudIndex: number; // 0 - 100 (hostile activity indicator)
  corruptionIndex: number; // 0 - 100 (structural errors)
  issues: AuditIssue[];
}

// Generates a quick hash or similar simulation for duplicate proof image detection
function simulateImageHash(base64Str?: string | null): string {
  if (!base64Str) return '';
  return `LEN_${base64Str.length}_PRE_${base64Str.substring(0, 30)}`;
}

// 1. FULL PLATFORM SCAN ENGINE
export async function SCAN_ALL_SYSTEMS(workspaceId?: string): Promise<{
  marketplace: { clean: Product[]; flagged: Product[]; corrupted: Product[]; issues: AuditIssue[] };
  services: { clean: Product[]; flagged: Product[]; issues: AuditIssue[] };
  jobs: { clean: JobPost[]; flagged: JobPost[]; issues: AuditIssue[] };
  workers: { clean: WorkerProfile[]; flagged: WorkerProfile[]; issues: AuditIssue[] };
}> {
  const allProducts = await getAllItems('products');
  const allWorkspaces = await getAllItems('workspaces');
  const jobs = getJobs();
  const workers = getWorkers();
  const indexInteractions = await getAllItems('interactions');

  const wsProducts = workspaceId ? allProducts.filter(p => p.workspaceId === workspaceId) : allProducts;

  const marketplace = { clean: [] as Product[], flagged: [] as Product[], corrupted: [] as Product[], issues: [] as AuditIssue[] };
  const services = { clean: [] as Product[], flagged: [] as Product[], issues: [] as AuditIssue[] };
  const jobsResult = { clean: [] as JobPost[], flagged: [] as JobPost[], issues: [] as AuditIssue[] };
  const workersResult = { clean: [] as WorkerProfile[], flagged: [] as WorkerProfile[], issues: [] as AuditIssue[] };

  // A. MARKETPLACE SCAN
  // Separating non-service products
  const marketplaceProducts = wsProducts.filter(p => p.category !== 'خدمات');
  const seenMarketplaceKeys = new Set<string>();

  marketplaceProducts.forEach(p => {
    const issues: AuditIssue[] = [];

    // Duplicate listing check in this workspace
    const dupKey = `${p.workspaceId || 'global'}_${(p.name || '').trim().toLowerCase()}_${p.price}`;
    if (seenMarketplaceKeys.has(dupKey)) {
      issues.push({
        id: `MKR-DUP-${p.id}`,
        system: 'marketplace',
        severity: 'warning',
        title: 'منتج مكرر',
        description: `المنتج "${p.name}" مكرر ومطابق لسلعة أخرى بنفس الاسم والسعر بالمتجر.`,
        affectedId: p.id,
        repairable: true,
        repairType: 'remove_duplicate'
      });
    } else {
      seenMarketplaceKeys.add(dupKey);
    }

    // Missing required fields
    if (!p.name || p.name.trim().length === 0) {
      issues.push({
        id: `MKR-MISS-NAME-${p.id}`,
        system: 'marketplace',
        severity: 'critical',
        title: 'تالف: اسم مفقود',
        description: 'الملف التعريفي للسلعة تالف لعدم وجود اسم مسجل لها.',
        affectedId: p.id,
        repairable: true,
        repairType: 'reset_corrupted_field'
      });
    }

    // Invalid price formats
    if (p.price === undefined || p.price === null || isNaN(p.price) || p.price < 0) {
      issues.push({
        id: `MKR-BAD-PRICE-${p.id}`,
        system: 'marketplace',
        severity: 'error',
        title: 'صيغة سعر غير مسموحة',
        description: `المنتج "${p.name}" يحمل سعراً تالفاً أو أقل من الصفر (${p.price} دج).`,
        affectedId: p.id,
        repairable: true,
        repairType: 'reset_price'
      });
    } else if (p.price === 123456 || p.price === 99999999) {
      issues.push({
        id: `MKR-MOCK-PRICE-${p.id}`,
        system: 'marketplace',
        severity: 'warning',
        title: 'سعر تجريبي/وهمي',
        description: `المنتج "${p.name}" يستعمل سعراً نموذجياً مكرراً غير حقيقي بأسواق الجزائر (${p.price} دج).`,
        affectedId: p.id,
        repairable: true,
        repairType: 'normalise_price'
      });
    }

    // Corrupted structural properties
    if (!p.workspaceId || !allWorkspaces.some(w => w.id === p.workspaceId)) {
      issues.push({
        id: `MKR-ORPHAN-${p.id}`,
        system: 'marketplace',
        severity: 'critical',
        title: 'بيانات يتيمة',
        description: `المنتج "${p.name}" لا ينتمي لأي مساحة عمل أو متجر مسجل بالمنظومة.`,
        affectedId: p.id,
        repairable: true,
        repairType: 'clean_orphaned'
      });
    }

    // Inactive listings with activity flags
    const hasActivity = indexInteractions.some(i => i.productId === p.id);
    if ((p.stock === 0 || p.stock === undefined || p.stock === null) && hasActivity) {
      issues.push({
        id: `MKR-STOCK-INCONSISTENT-${p.id}`,
        system: 'marketplace',
        severity: 'warning',
        title: 'تضارب النشاط مع المخزن',
        description: `المنتج "${p.name}" نفد من المخزون ولكن توجد نقرات مسجلة عليه حديثاً.`,
        affectedId: p.id,
        repairable: true,
        repairType: 'increment_stock'
      });
    }

    if (issues.some(i => i.severity === 'critical')) {
      marketplace.corrupted.push(p);
      marketplace.issues.push(...issues);
    } else if (issues.length > 0) {
      marketplace.flagged.push(p);
      marketplace.issues.push(...issues);
    } else {
      marketplace.clean.push(p);
    }
  });


  // B. SERVICES SCAN
  const serviceProducts = wsProducts.filter(p => p.category === 'خدمات');
  serviceProducts.forEach(s => {
    const issues: AuditIssue[] = [];

    // Pricing Consistency
    if (s.price === 0) {
      issues.push({
        id: `SRV-FREE-${s.id}`,
        system: 'services',
        severity: 'warning',
        title: 'خدمة تسعير مجاني',
        description: `الخدمة "${s.name}" معروضة بسعر 0 دج. قد يقلل ذك من ثقة الزبائن في الاستجابة الحقيقية.`,
        affectedId: s.id,
        repairable: false,
        repairType: ''
      });
    } else if (s.price > 1000000) {
      issues.push({
        id: `SRV-EXTREME-PRICE-${s.id}`,
        system: 'services',
        severity: 'warning',
        title: 'تسعير خدمة غير مألوف',
        description: `سعر الخدمة مبالغ فيه بشكل صارخ بالنسبة للعمل اليومي بالجزائر (${s.price} دج).`,
        affectedId: s.id,
        repairable: true,
        repairType: 'reset_price'
      });
    }

    // Service category check
    if (s.category !== 'خدمات') {
      issues.push({
        id: `SRV-CAT-MISMATCH-${s.id}`,
        system: 'services',
        severity: 'error',
        title: 'خطأ تصنيف الخدمة',
        description: `الخدمة "${s.name}" غير مصنفة رسمياً تحت تصنيف "خدمات".`,
        affectedId: s.id,
        repairable: true,
        repairType: 'fix_category'
      });
    }

    // Missing Availability details or duration
    const duration = s.dynamicData?.serviceDuration || (s as any).serviceDuration;
    if (!duration || duration.trim().length === 0) {
      issues.push({
        id: `SRV-MISS-DURATION-${s.id}`,
        system: 'services',
        severity: 'warning',
        title: 'مدة الانجاز غائبة',
        description: `الخدمة "${s.name}" لا تحتوي على مدة إنجاز أو عمل تقديرية موضحة للزبائن.`,
        affectedId: s.id,
        repairable: true,
        repairType: 'set_default_duration'
      });
    }

    // Unrealistic descriptions
    if (!s.description || s.description.trim().length < 15) {
      issues.push({
        id: `SRV-SHORT-DESC-${s.id}`,
        system: 'services',
        severity: 'warning',
        title: 'وصف خدمة ضعيف',
        description: `الوصف قصير جداً ولا يمنح الزبون فكرة شاملة عن تفاصيل العمل المعروض.`,
        affectedId: s.id,
        repairable: false,
        repairType: ''
      });
    }

    if (issues.length > 0) {
      services.flagged.push(s);
      services.issues.push(...issues);
    } else {
      services.clean.push(s);
    }
  });


  // C. JOBS SCAN
  jobs.forEach(j => {
    const issues: AuditIssue[] = [];

    // Salary ranges checks
    if (j.salaryMin < 1000) {
      issues.push({
        id: `JOB-LOW-SALARY-${j.id}`,
        system: 'jobs',
        severity: 'warning',
        title: 'راتب ضعيف للغاية',
        description: `الراتب الأدنى للوظيفة "${j.title}" أقل من 1000 دج وهو غير منطقي بالجزائر.`,
        affectedId: j.id,
        repairable: true,
        repairType: 'fix_job_salary'
      });
    }
    if (j.salaryMin > j.salaryMax) {
      issues.push({
        id: `JOB-RANGE-FLIP-${j.id}`,
        system: 'jobs',
        severity: 'error',
        title: 'تضارب نطاق الراتب',
        description: `الراتب الأدنى (${j.salaryMin} دج) أكبر من الراتب الأقصى (${j.salaryMax} دج).`,
        affectedId: j.id,
        repairable: true,
        repairType: 'repair_salary_range'
      });
    }

    // Expired jobs still active (> 30 days)
    const ageDays = (Date.now() - j.createdAt) / (1000 * 60 * 60 * 24);
    if (ageDays > 30 && j.status === 'active') {
      issues.push({
        id: `JOB-EXPIRED-ACTIVE-${j.id}`,
        system: 'jobs',
        severity: 'warning',
        title: 'وظيفة قديمة معلقة',
        description: `الوظيفة المعروضة تجاوزت 30 يوماً وتتطلب الإرشفة أو الإغلاق التلقائي.`,
        affectedId: j.id,
        repairable: true,
        repairType: 'archive_old_job'
      });
    }

    // Employer Metadata Check
    const phoneClean = (j.employerPhone || '').replace(/\s+/g, '');
    const validMobPrefix = /^(05|06|07|213)\d{8,9}$/.test(phoneClean);
    if (!validMobPrefix) {
      issues.push({
        id: `JOB-BAD-PHONE-${j.id}`,
        system: 'jobs',
        severity: 'error',
        title: 'رقم هاتف مشتغل تالف',
        description: `رقم هاتف المشغّل لطلب الوظيفة لا يطابق البنية البريدية للجزائر.`,
        affectedId: j.id,
        repairable: false,
        repairType: ''
      });
    }

    if (!j.employerName || j.employerName.trim().length <= 2) {
      issues.push({
        id: `JOB-BAD-EMPLOYER-${j.id}`,
        system: 'jobs',
        severity: 'error',
        title: 'هوية مشغّل مجهولة',
        description: `حساب المشغّل لطلب الوظيفة "${j.title}" تالف أو غير مسمى بدقة.`,
        affectedId: j.id,
        repairable: true,
        repairType: 'set_default_employer'
      });
    }

    if (issues.length > 0) {
      jobsResult.flagged.push(j);
      jobsResult.issues.push(...issues);
    } else {
      jobsResult.clean.push(j);
    }
  });


  // D. WORKERS SCAN
  workers.forEach(w => {
    const issues: AuditIssue[] = [];

    // Skill mismatch check
    if (!w.skills || w.skills.length === 0) {
      issues.push({
        id: `WKR-NO-SKILLS-${w.id}`,
        system: 'workers',
        severity: 'error',
        title: 'ملف خالي من المهارات',
        description: `العامل المستقل "${w.name}" لا يملك أي مهارات مسجلة في ملفه.`,
        affectedId: w.id,
        repairable: true,
        repairType: 'add_default_skills'
      });
    } else {
      const invalidSkills = w.skills.filter(s => s.trim().length < 2);
      if (invalidSkills.length > 0) {
        issues.push({
          id: `WKR-BAD-SKILL-${w.id}`,
          system: 'workers',
          severity: 'warning',
          title: 'مهارات تالفة / فارغة',
          description: `ملف العامل يحتوي على مهارات مشوهة أو قصيرة جداً لا معنى لها.`,
          affectedId: w.id,
          repairable: true,
          repairType: 'clean_bad_skills'
        });
      }
    }

    // Fake Portfolio entries (Heuristic)
    if (w.description && (w.description.includes('lorem ipsum') || w.description.includes('معلومات نموذجية') || w.description.trim().length < 8)) {
      issues.push({
        id: `WKR-FAKE-PORTFOLIO-${w.id}`,
        system: 'workers',
        severity: 'warning',
        title: 'ملف تعريفي مشكوك',
        description: `وصف الأعمال والخبرة للعامل "${w.name}" قصير جداً أو يحتوي نصوصاً تجريبية وهمية.`,
        affectedId: w.id,
        repairable: false,
        repairType: ''
      });
    }

    // Trust score anomalies
    if (w.rating > 5.0 || w.rating < 1.0) {
      issues.push({
        id: `WKR-BAD-RATING-${w.id}`,
        system: 'workers',
        severity: 'error',
        title: 'انحراف تقييم غير طبيعي',
        description: `يحمل العامل "${w.name}" قيمة تقييم خارج النطاق المنطقي المنصوص عليه (${w.rating}/5).`,
        affectedId: w.id,
        repairable: true,
        repairType: 'recalibrate_worker_rating'
      });
    }

    if (w.verified && w.rating < 4.0) {
      issues.push({
        id: `WKR-VERIFIED-CONFLICT-${w.id}`,
        system: 'workers',
        severity: 'warning',
        title: 'توثيق مع تقييم منخفض',
        description: `العامل مرخص وحائز على علامة خضراء بالرغم من تدني تقييم رضا العملاء لـ (${w.rating}/5).`,
        affectedId: w.id,
        repairable: true,
        repairType: 'deverify_low_performer'
      });
    }

    if (issues.length > 0) {
      workersResult.flagged.push(w);
      workersResult.issues.push(...issues);
    } else {
      workersResult.clean.push(w);
    }
  });

  return {
    marketplace,
    services,
    jobs: jobsResult,
    workers: workersResult
  };
}

// 2. TRUST SYSTEM VERIFICATION ENGINE
export async function VERIFY_TRUST_SYSTEM(workspaceId?: string): Promise<{
  state: 'TRUST_OK' | 'TRUST_WARNING' | 'TRUST_CORRUPTION_FLAG';
  reasons: string[];
  issues: AuditIssue[];
}> {
  const allOrders = await getAllItems('orders');
  const allWorkspaces = await getAllItems('workspaces');
  const allInteractions = await getAllItems('interactions');
  
  const reasons: string[] = [];
  const issues: AuditIssue[] = [];

  const targetWorkspaces = workspaceId 
    ? allWorkspaces.filter(w => w.id === workspaceId) 
    : allWorkspaces;

  for (const ws of targetWorkspaces) {
    const wsOrders = allOrders.filter(o => o.workspaceId === ws.id);
    const wsInteractions = allInteractions.filter(i => i.vendorId === ws.id);
    
    // Calculate simulated reputation points
    const deliveredCount = wsOrders.filter(o => o.status === 'delivered' || o.paymentStatus === 'confirmed').length;
    const whatsappCount = wsInteractions.filter(i => i.type === 'whatsapp').length;
    const favoriteCount = wsInteractions.filter(i => i.type === 'favorite').length;
    const refusedCount = wsOrders.filter(o => o.status === 'refused' || o.status === 'cancelled').length;

    let computedPoints = deliveredCount * 25 + whatsappCount * 5 + favoriteCount * 2 - refusedCount * 15;
    computedPoints = Math.max(0, computedPoints);

    // Fetch dynamic performance metrics stored
    const sellerVerifiedBadge = localStorage.getItem(`riyada_gold_verified_${ws.id}`) === 'true';
    const isElite = computedPoints >= 500;
    
    // Check points drift
    const reputationPointsString = localStorage.getItem(`riyada_rep_points_${ws.id}`);
    if (reputationPointsString) {
      const repVal = Number(reputationPointsString);
      if (Math.abs(repVal - computedPoints) > 100) {
        reasons.push(`انحراف حاد بالسمعة للمتجر "${ws.name}": السمعة المحتسبة رياضياً (${computedPoints}) تختلف عن السمعه المخزنة (${repVal}).`);
        issues.push({
          id: `TRS-DRIFT-${ws.id}`,
          system: 'trust',
          severity: 'warning',
          title: 'تلاعب بنقاط السمعة',
          description: `السمعة المخزنة محلياً لا تطابق تدفق طلبيات بريدي موب والتوصيل الفعلي للمتجر.`,
          affectedId: ws.id,
          repairable: true,
          repairType: 'recalculate_reputation'
        });
      }
    }

    // Elite mismatch
    if (isElite && whatsappCount === 0 && deliveredCount === 0) {
      reasons.push(`ترقية مشبوهة للمتجر "${ws.name}": رتبة النخبة Elite مفعلة لكن مع زيرو نشاط تجاري أو مبيعات.`);
      issues.push({
        id: `TRS-FAKE-ELITE-${ws.id}`,
        system: 'trust',
        severity: 'critical',
        title: 'رتبة ترويجية غير مستحقة',
        description: 'المتجر يحصل على رتبة Elite دون تحقيق الحد الأدنى من الطلبيات والنشاط الزبائني.',
        affectedId: ws.id,
        repairable: true,
        repairType: 'reset_tier'
      });
    }

    // Inconsistent rating context
    const hasFakeGoldSeal = sellerVerifiedBadge && deliveredCount === 0 && whatsappCount < 2;
    if (hasFakeGoldSeal) {
      reasons.push(`شارة متجر موثق مذهبة مشبوهة للمتجر "${ws.name}" دون مبيعات فعلية تؤكد التراخيص.`);
      issues.push({
        id: `TRS-BAD-GOLD-${ws.id}`,
        system: 'trust',
        severity: 'warning',
        title: 'شارة توثيق بدون مبيعات',
        description: 'شارة التوثيق المذهبة نشطة محلياً وتظهر للمشترين بدون معاملة تفعيل أو مبيعات حقيقية.',
        affectedId: ws.id,
        repairable: true,
        repairType: 'revoke_verification'
      });
    }
  }

  let state: 'TRUST_OK' | 'TRUST_WARNING' | 'TRUST_CORRUPTION_FLAG' = 'TRUST_OK';
  const hasCritical = issues.some(i => i.severity === 'critical');
  if (hasCritical) {
    state = 'TRUST_CORRUPTION_FLAG';
  } else if (issues.length > 0) {
    state = 'TRUST_WARNING';
  }

  return { state, reasons, issues };
}

// 3. PAYMENT SYSTEM AUDIT ENGINE
export async function AUDIT_PAYMENTS(workspaceId?: string): Promise<{
  issues: AuditIssue[];
  metrics: {
    pendingCount: number;
    approvedWithoutProof: number;
    duplicateTxCount: number;
  }
}> {
  const allOrders = await getAllItems('orders');
  const issues: AuditIssue[] = [];

  // Filter orders by workspace context
  const wsOrders = workspaceId ? allOrders.filter(o => o.workspaceId === workspaceId) : allOrders;

  // Retrieve platform boost manual transactions (PaymentSafety.tsx storage)
  const storedPlatformTxsStr = localStorage.getItem(`riyada_platform_txs_${workspaceId || 'global'}`);
  let platformTxs: any[] = [];
  if (storedPlatformTxsStr) {
    try {
      platformTxs = JSON.parse(storedPlatformTxsStr);
    } catch {
      // JSON Corrupted handles under integrity check
    }
  }

  let pendingCount = 0;
  let approvedWithoutProof = 0;
  
  const seenTxIds = new Map<string, string[]>(); // Map txId to Order/Tx IDs
  const seenProofImages = new Map<string, string[]>(); // Map length signature to Order/Tx IDs

  // A. PAYMENT STATE CONSISTENCY
  wsOrders.forEach(o => {
    // Audit orders under CCP/Baridimob/CIB status
    const method = o.paymentMethod || '';
    const status = o.status;

    const isDigital = ['CCP', 'BaridiMob', 'CIB', 'chargily', 'baridimob_manual'].includes(method);
    
    // Pending stuck too long (> 48 hours)
    const isPending = status === 'pending' || status === 'payment_pending' || status === 'initiated';
    const ageHours = (Date.now() - o.createdAt) / (1000 * 60 * 60);
    if (isDigital && isPending && ageHours > 48) {
      pendingCount++;
      issues.push({
        id: `PAY-STUCK-${o.id}`,
        system: 'payments',
        severity: 'warning',
        title: 'معاملة معلقة متجاوزة للوقت',
        description: `الطلب "${o.id}" معلق بالدفع الرقمي منذ أكثر من 48 ساعة دون تأكيد.`,
        affectedId: o.id,
        repairable: true,
        repairType: 'expire_stuck_payment'
      });
    }

    // Approved without proof (E-payments only)
    const isApproved = status === 'paid' || o.paymentStatus === 'confirmed' || status === 'delivered';
    const hasProof = !!o.paymentProofFile || !!o.receiptImage || !!o.transactionReference || !!o.paymentTxId;
    if (isDigital && isApproved && !hasProof) {
      approvedWithoutProof++;
      issues.push({
        id: `PAY-NO-PROOF-${o.id}`,
        system: 'payments',
        severity: 'error',
        title: 'دفع مقبول بدون مستند إثبات',
        description: `الطلب الرقمي "${o.id}" معلم كـ "مدفوع ومكتمل" بدون تدوين مرجع المعاملة TXID أو صورة الإيصال.`,
        affectedId: o.id,
        repairable: true,
        repairType: 'reset_unverified_payment'
      });
    }

    // Mismatched amount checks
    if (o.total <= 0 && isDigital) {
      issues.push({
        id: `PAY-ZERO-VAL-${o.id}`,
        system: 'payments',
        severity: 'critical',
        title: 'تحويل رقمي بقيمة صفر',
        description: `طلب الشراء الرقمي "${o.id}" يملك إجمالي دفع سلبي أو معدوم، خطر على تسوية الحوالة.`,
        affectedId: o.id,
        repairable: true,
        repairType: 'cancel_zero_payment'
      });
    }

    // Map duplicated Tx ID checks
    const tId = o.paymentTxId || o.transactionReference;
    if (tId && tId.trim().length > 0) {
      const formatted = tId.trim().toLowerCase();
      const current = seenTxIds.get(formatted) || [];
      current.push(`ORDER-${o.id}`);
      seenTxIds.set(formatted, current);
    }

    // Map duplicate Proof images check (Hash-based)
    const imgData = o.paymentProofFile || o.receiptImage;
    if (imgData && imgData.startsWith('data:image')) {
      const hashStr = simulateImageHash(imgData);
      const current = seenProofImages.get(hashStr) || [];
      current.push(`ORDER-${o.id}`);
      seenProofImages.set(hashStr, current);
    }
  });

  // Audit platform boost transactions
  platformTxs.forEach(tx => {
    const isPending = tx.status === 'initiated' || tx.status === 'awaiting_payment' || tx.status === 'payment_submitted';
    const ageHours = (Date.now() - tx.timestamp) / (1000 * 60 * 60);
    
    if (isPending && ageHours > 24) {
      pendingCount++;
      issues.push({
        id: `PAY-BOOST-STUCK-${tx.id}`,
        system: 'payments',
        severity: 'warning',
        title: 'طلب باقة معلق متجاوز',
        description: `باقة التمكين "${tx.planName}" معلقة منذ أكثر من 24 ساعة دون سداد حقيقي.`,
        affectedId: tx.id,
        repairable: true,
        repairType: 'cancel_boost_tx'
      });
    }

    const tId = tx.txId;
    if (tId && tId.trim().length > 0) {
      const formatted = tId.trim().toLowerCase();
      const current = seenTxIds.get(formatted) || [];
      current.push(`BOOST-${tx.id}`);
      seenTxIds.set(formatted, current);
    }

    const imgData = tx.proofFile;
    if (imgData && imgData.startsWith('data:image')) {
      const hashStr = simulateImageHash(imgData);
      const current = seenProofImages.get(hashStr) || [];
      current.push(`BOOST-${tx.id}`);
      seenProofImages.set(hashStr, current);
    }
  });

  // Process Duplicated references and issue alerts
  let duplicateTxCount = 0;
  seenTxIds.forEach((records, txId) => {
    if (records.length > 1) {
      duplicateTxCount++;
      // If it's a common mock / dummy value, we flag warning, otherwise critical
      const isMockVal = ['123456', '000000', '123456789'].includes(txId);
      issues.push({
        id: `PAY-DUP-TXID-${txId}`,
        system: 'payments',
        severity: isMockVal ? 'warning' : 'critical',
        title: isMockVal ? 'استعمال رقم معاملة وهمي مكرر' : 'تكرار رقم العملية فريد (Double Claim)',
        description: `رقم المعاملة "${txId}" تم ادعاؤه في مستندات متعددة بالمنظومة: [${records.join(', ')}]. تفطن لمحاولات الاحتيال بالإيصال المشترك.`,
        affectedId: txId,
        repairable: true,
        repairType: 'isolate_duplicate_txs'
      });
    }
  });

  seenProofImages.forEach((records, hashKey) => {
    if (records.length > 1) {
      issues.push({
        id: `PAY-DUP-RECEIPT-IMAGE-${hashKey}`,
        system: 'payments',
        severity: 'critical',
        title: 'استخدام نفس ملف الإيصال (Screenshot Cloning)',
        description: `خطير جداً: لقطة الشاشة ووصل الحوالة نفسه تم استنساخه وإرفاقه في معاملات منفصلة: [${records.join(', ')}].`,
        affectedId: hashKey,
        repairable: true,
        repairType: 'flag_cloned_receipts'
      });
    }
  });

  return {
    issues,
    metrics: {
      pendingCount,
      approvedWithoutProof,
      duplicateTxCount
    }
  };
}

// 4. FRAUD DETECTION ENGINE
export async function DETECT_FRAUD_SIGNALS(workspaceId?: string): Promise<{
  score: number;
  state: 'SAFE' | 'SUSPICIOUS' | 'HIGH_RISK';
  signals: string[];
  issues: AuditIssue[];
}> {
  const allProducts = await getAllItems('products');
  const allOrders = await getAllItems('orders');
  const signals: string[] = [];
  const issues: AuditIssue[] = [];
  
  let riskPoints = 0;

  const wsProducts = workspaceId ? allProducts.filter(p => p.workspaceId === workspaceId) : allProducts;
  const wsOrders = workspaceId ? allOrders.filter(o => o.workspaceId === workspaceId) : allOrders;

  // A. Price Manipulations Heuristic
  const expensiveProducts = wsProducts.filter(p => p.price > 1500000);
  if (expensiveProducts.length > 0) {
    riskPoints += expensiveProducts.length * 15;
    signals.push(`تم رصد منتجات ذات أسعار غير مسبوقة للبيع الفردي بالولاية (> 150 مليون سنتيم): [${expensiveProducts.slice(0,2).map(p => p.name).join(', ')}]`);
  }

  // B. Repeated Listing Duplications
  const marketplaceScan = await SCAN_ALL_SYSTEMS(workspaceId);
  if (marketplaceScan.marketplace.issues.some(i => i.repairType === 'remove_duplicate')) {
    riskPoints += 20;
    signals.push('وجود سلع متطابقة مكررة بالمتجر لتضخيم المعروضات عشوائياً (Listing Spamming).');
  }

  // C. Repeated Failed Orders / Cancelled
  const cancelledOrders = wsOrders.filter(o => o.status === 'cancelled' || o.status === 'refused');
  const totalOrdersCount = wsOrders.length;
  if (totalOrdersCount > 3 && (cancelledOrders.length / totalOrdersCount) > 0.5) {
    riskPoints += 35;
    signals.push(`معدل إلغاء ورفض مرتفع جداً بالمتجر (${(cancelledOrders.length / totalOrdersCount * 100).toFixed(0)}%). قد يؤشر على وهمية الطلبيات للتجميل.`);
  }

  // D. Duplicate Receipt and Payments claims (Loaded from Audit payments)
  const paymentAudit = await AUDIT_PAYMENTS(workspaceId);
  const clonesCount = paymentAudit.issues.filter(i => i.repairType === 'flag_cloned_receipts' || i.repairType === 'isolate_duplicate_txs').length;
  if (clonesCount > 0) {
    riskPoints += clonesCount * 30;
    signals.push(`تم حظر محاولات تبييض الحوالات البريدية! مطابقة الوصل كشفت ${clonesCount} حوالة مستنسخة بالمتجر.`);
  }

  // Final Evaluation
  let state: 'SAFE' | 'SUSPICIOUS' | 'HIGH_RISK' = 'SAFE';
  if (riskPoints >= 55) {
    state = 'HIGH_RISK';
  } else if (riskPoints >= 20) {
    state = 'SUSPICIOUS';
  }

  return {
    score: Math.min(100, riskPoints),
    state,
    signals,
    issues: paymentAudit.issues.concat(marketplaceScan.marketplace.issues)
  };
}

// 5. DATA INTEGRITY ENGINE
export async function CHECK_DATA_INTEGRITY(workspaceId?: string): Promise<{
  corruptionCount: number;
  issues: AuditIssue[];
}> {
  const allOrders = await getAllItems('orders');
  const allProducts = await getAllItems('products');
  const allCustomers = await getAllItems('customers');
  const issues: AuditIssue[] = [];

  const wsOrders = workspaceId ? allOrders.filter(o => o.workspaceId === workspaceId) : allOrders;
  const wsProducts = workspaceId ? allProducts.filter(p => p.workspaceId === workspaceId) : allProducts;
  const wsCustomers = workspaceId ? allCustomers.filter(c => c.workspaceId === workspaceId) : allCustomers;

  let corruptionCount = 0;

  // Check Broken References in Orders (Orphaned item references)
  wsOrders.forEach(o => {
    // Check missing items
    if (!o.items || o.items.length === 0) {
      corruptionCount++;
      issues.push({
        id: `INTG-ORD-EMPTY-${o.id}`,
        system: 'integrity',
        severity: 'critical',
        title: 'طلب فارغ بدون سلع',
        description: `الطلب رقم "${o.id}" يسجل تلميحاً فارغاً لا يحتوي على أي منتجات أو كلفة.`,
        affectedId: o.id,
        repairable: true,
        repairType: 'clean_orphaned'
      });
    } else {
      o.items.forEach(item => {
        const productExists = allProducts.some(p => p.id === item.productId);
        if (!productExists) {
          corruptionCount++;
          issues.push({
            id: `INTG-ORD-ORPHAN-PRD-${o.id}-${item.productId}`,
            system: 'integrity',
            severity: 'warning',
            title: 'منتج مفقود من المخزن بالطلب',
            description: `الطلب "${o.id}" يحتوي على السلعة "${item.name}" التي تم حذفها نهائياً من قاعدة المنتج.`,
            affectedId: o.id,
            repairable: false,
            repairType: ''
          });
        }
      });
    }

    // Check broken customer reference
    const customerExists = wsCustomers.some(c => c.id === o.customerId);
    if (!customerExists && o.customerId) {
      corruptionCount++;
      issues.push({
        id: `INTG-ORD-ORPHAN-CST-${o.id}`,
        system: 'integrity',
        severity: 'warning',
        title: 'زبون مفقود بالطلب',
        description: `الطلب يشير لهوية زبون (${o.customerId}) لا تمتلك ملفاً تفصيلياً بقاعدة الزبائن.`,
        affectedId: o.id,
        repairable: true,
        repairType: 'recreate_missing_customer'
      });
    }
  });

  // Verify Local Storage Corrupted structures
  try {
    const rawPl = localStorage.getItem(`riyada_platform_txs_${workspaceId || 'global'}`);
    if (rawPl) {
      JSON.parse(rawPl);
    }
  } catch {
    corruptionCount++;
    issues.push({
      id: `INTG-PLATFORM-TX-DB-FAIL`,
      system: 'integrity',
      severity: 'critical',
      title: 'تلف قاعدة ترقيات الباقات',
      description: 'تعذر تحليل مصفوفة معاملات ترقية الباقات المكتوبة محلياً. هيكلية JSON تالفة بالكامل.',
      affectedId: 'localStorage',
      repairable: true,
      repairType: 'reset_corrupted_localStorage'
    });
  }

  return {
    corruptionCount,
    issues
  };
}

// 6. STATE MACHINE VERIFICATION ENGINE
export async function VERIFY_STATE_TRANSITIONS(workspaceId?: string): Promise<{
  violationsCount: number;
  violations: string[];
  issues: AuditIssue[];
}> {
  const allOrders = await getAllItems('orders');
  const wsOrders = workspaceId ? allOrders.filter(o => o.workspaceId === workspaceId) : allOrders;
  const violations: string[] = [];
  const issues: AuditIssue[] = [];

  // Allowed states definition:
  // ORDER: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled' | 'initiated' | 'awaiting_seller_confirmation' | 'seller_confirmed' | 'payment_pending' | 'paid' | 'expired' | 'refused'
  
  wsOrders.forEach(o => {
    // 1. Double cancellation and payment conflict rule
    if ((o.status === 'cancelled' || o.status === 'refused') && (o.paymentStatus === 'confirmed' || o.paymentStatus === 'paid')) {
      violations.push(`الطلب "${o.id}": تضارب الحالة! الطلب معلم ملغى أو مرفوض، بيْد أن الدفع مسجل كـ "مقبول أو مؤكد".`);
      issues.push({
        id: `STA-CONFLICT-CANCEL-${o.id}`,
        system: 'trust',
        severity: 'critical',
        title: 'تضارب حالة المبيعات والدفع',
        description: 'تضارب منطقي في سير المعاملة؛ طلبيات ملغاة في الحين الذي تم ترصيد الحوالة بريدياً.',
        affectedId: o.id,
        repairable: true,
        repairType: 'resolve_status_conflict'
      });
    }

    // 2. Shippment before verification rule
    if (o.status === 'shipped' && o.paymentStatus === 'pending') {
      violations.push(`الطلب "${o.id}": خطأ الترانزيت. لا يجب شحن المنتج قبل وسم الطلب بالقبول المبدئي.`);
    }

    // 3. Delivered but order is expired
    if (o.status === 'delivered' && o.paymentStatus === 'expired') {
      violations.push(`الطلب "${o.id}": تضارب زمني! تم التوصيل النهائي لصالح الزبون بالحقيبة برغم انتهاء وتلف صلاحية المعاملة.`);
    }
  });

  // Allowed platform transaction boost transitions audit
  const rawPl = localStorage.getItem(`riyada_platform_txs_${workspaceId || 'global'}`);
  if (rawPl) {
    try {
      const txs = JSON.parse(rawPl);
      txs.forEach((tx: any) => {
        // Boost payment states: 'initiated' | 'awaiting_payment' | 'payment_submitted' | 'under_review' | 'approved' | 'rejected' | 'expired'
        
        if (tx.status === 'approved' && !tx.txId) {
          violations.push(`معاملة ترقية "${tx.id}": تمت الموافقة النهائية وتحديث المتجر دون وجود مرجع معاملة TXID.`);
          issues.push({
            id: `STA-BOOST-CONFLICT-${tx.id}`,
            system: 'payments',
            severity: 'error',
            title: 'ترقية باقة بدون توثيق مالي',
            description: 'حالة الترقية مسجلة كمقبولة بالمنصة في حين يغيب معرف التتبع أو إثبات CCP.',
            affectedId: tx.id,
            repairable: true,
            repairType: 'demote_boost_tx'
          });
        }
      });
    } catch {
      // JSON issues handled in integration
    }
  }

  return {
    violationsCount: violations.length,
    violations,
    issues
  };
}

// 7. SYSTEM HEALTH STATUS EVALUATOR
export async function SYSTEM_HEALTH(workspaceId?: string): Promise<SystemHealthState> {
  const mkt = await SCAN_ALL_SYSTEMS(workspaceId);
  const trust = await VERIFY_TRUST_SYSTEM(workspaceId);
  const pay = await AUDIT_PAYMENTS(workspaceId);
  const fraud = await DETECT_FRAUD_SIGNALS(workspaceId);
  const integrity = await CHECK_DATA_INTEGRITY(workspaceId);
  const transitions = await VERIFY_STATE_TRANSITIONS(workspaceId);

  // Group all diagnostic issues
  const allIssues: AuditIssue[] = [];
  const registeredIds = new Set<string>();

  const pushUnique = (issues: AuditIssue[]) => {
    issues.forEach(i => {
      if (!registeredIds.has(i.id)) {
        registeredIds.add(i.id);
        allIssues.push(i);
      }
    });
  };

  pushUnique(mkt.marketplace.issues);
  pushUnique(mkt.services.issues);
  pushUnique(mkt.jobs.issues);
  pushUnique(mkt.workers.issues);
  pushUnique(trust.issues);
  pushUnique(pay.issues);
  pushUnique(fraud.issues);
  pushUnique(integrity.issues);
  pushUnique(transitions.issues);

  // Health Score Mathematical Recalculations (Heuristics)
  const mktErrors = mkt.marketplace.issues.filter(i => i.severity === 'critical' || i.severity === 'error').length;
  const mktWarns = mkt.marketplace.issues.filter(i => i.severity === 'warning').length;
  const marketplaceScore = Math.max(0, 100 - mktErrors * 15 - mktWarns * 5);

  const trustIssuesCount = trust.issues.length;
  const trustScore = Math.max(0, 100 - trustIssuesCount * 12);

  const payIssuesCount = pay.issues.length;
  const paymentsScore = Math.max(0, 100 - payIssuesCount * 10);

  const fraudIndex = fraud.score; // Higher means worse fraud indicators
  const corruptionIndex = Math.min(100, integrity.corruptionCount * 25 + transitions.violationsCount * 15);

  return {
    marketplaceScore,
    trustScore,
    paymentsScore,
    fraudIndex,
    corruptionIndex,
    issues: allIssues
  };
}

// 8. AUTO-REPAIR ENGINE
export async function AUTO_REPAIR(
  issue: AuditIssue, 
  workspaceId?: string
): Promise<{ success: boolean; message: string }> {
  // Safe validation guards
  const db = await getDB();
  
  if (issue.repairType === 'remove_duplicate') {
    // Remove duplicate marketplace products
    const p = await db.get('products', issue.affectedId);
    if (p) {
      await db.delete('products', issue.affectedId);
      return { success: true, message: `تم حذف السلعة المكررة "${p.name}" وتنظيف متجر العرض.` };
    }
  }

  if (issue.repairType === 'reset_price') {
    // Reset product/service price to positive default
    const p = await db.get('products', issue.affectedId);
    if (p) {
      p.price = 500; // Reset to safe min DZD
      await db.put('products', p);
      return { success: true, message: `تمت معايرة وتعديل السعر التالف لسلعة "${p.name}" إلى قيمة نظامية (500 دج).` };
    }
  }

  if (issue.repairType === 'normalise_price') {
    // Normalise dummy prices (like 123456 or 99999999) to realistic negotiability or default
    const p = await db.get('products', issue.affectedId);
    if (p) {
      p.price = 0; // Use 0 for negotiable
      await db.put('products', p);
      return { success: true, message: `تم تحويل سعر منتج "${p.name}" عريض الأرقام إلى سعر "تفاوضي" (0 دج) لتفادي البلاغات.` };
    }
  }

  if (issue.repairType === 'clean_orphaned') {
    // Clean products having invalid workspace pointers
    const p = await db.get('products', issue.affectedId);
    if (p) {
      await db.delete('products', issue.affectedId);
      return { success: true, message: `تم تنظيف المنتج اليتيم "${p.name}" غير مربوط بمتجر نشط.` };
    }
    const o = await db.get('orders', issue.affectedId);
    if (o) {
      await db.delete('orders', issue.affectedId);
      return { success: true, message: "تم شطب الطلبية الفارغة بشكل نهائي من السجلات." };
    }
  }

  if (issue.repairType === 'fix_category') {
    // Fix category
    const p = await db.get('products', issue.affectedId);
    if (p) {
      p.category = 'خدمات';
      await db.put('products', p);
      return { success: true, message: `تم تأريض وتعديل تصنيف "${p.name}" كخدمة تخصصية.` };
    }
  }

  if (issue.repairType === 'set_default_duration') {
    const p = await db.get('products', issue.affectedId);
    if (p) {
      p.dynamicData = {
        ...p.dynamicData,
        serviceDuration: 'حسب الاتفاق'
      };
      await db.put('products', p);
      return { success: true, message: `تم كتابة مدة للتنفيذ ("حسب الاتفاق") تلقائياً للخدمة "${p.name}".` };
    }
  }

  if (issue.repairType === 'increment_stock') {
    const p = await db.get('products', issue.affectedId);
    if (p) {
      p.stock = 5; // Add positive values
      await db.put('products', p);
      return { success: true, message: `تم ملئ مخزون "${p.name}" المنقرض برمز ترقية (5 قطع).` };
    }
  }

  if (issue.repairType === 'repair_salary_range') {
    // Expired or bad jobs
    const jobs = getJobs();
    const idx = jobs.findIndex(j => j.id === issue.affectedId);
    if (idx > -1) {
      const min = jobs[idx].salaryMin;
      jobs[idx].salaryMin = jobs[idx].salaryMax;
      jobs[idx].salaryMax = min; // Flip
      saveJobs(jobs);
      return { success: true, message: `تم تعديل وعكس حدود راتب الوظيفة المقلوبة "${jobs[idx].title}".` };
    }
  }

  if (issue.repairType === 'archive_old_job') {
    const jobs = getJobs();
    const idx = jobs.findIndex(j => j.id === issue.affectedId);
    if (idx > -1) {
      jobs[idx].status = 'completed'; // Archive it
      saveJobs(jobs);
      return { success: true, message: `تم بنجاح إغلاق وتحديث ملف التوظيف القديم "${jobs[idx].title}".` };
    }
  }

  if (issue.repairType === 'recalibrate_worker_rating') {
    const workers = getWorkers();
    const idx = workers.findIndex(w => w.id === issue.affectedId);
    if (idx > -1) {
      workers[idx].rating = 5.0; // Recalibrate
      saveWorkers(workers);
      return { success: true, message: `تمت إعادة تمليس وضبط تصنيف التقييم للعامل "${workers[idx].name}" لقيمته الطبيعية (5.0/5).` };
    }
  }

  if (issue.repairType === 'deverify_low_performer') {
    const workers = getWorkers();
    const idx = workers.findIndex(w => w.id === issue.affectedId);
    if (idx > -1) {
      workers[idx].verified = false; // revoke green badge
      saveWorkers(workers);
      return { success: true, message: `تم سحب وسام التوثيق عن "${workers[idx].name}" لوجود مستويات تقييم منخفضة.` };
    }
  }

  if (issue.repairType === 'recalculate_reputation') {
    // Recalculate local reputation score in background
    const orders = await getAllItems('orders');
    const interactions = await getAllItems('interactions');
    const wsOrders = orders.filter(o => o.workspaceId === issue.affectedId);
    const wsInters = interactions.filter(i => i.vendorId === issue.affectedId);

    const delivered = wsOrders.filter(o => o.status === 'delivered' || o.paymentStatus === 'confirmed').length;
    const whats = wsInters.filter(i => i.type === 'whatsapp').length;
    const favs = wsInters.filter(i => i.type === 'favorite').length;
    const refs = wsOrders.filter(o => o.status === 'refused' || o.status === 'cancelled').length;

    const rep = Math.max(0, delivered * 25 + whats * 5 + favs * 2 - refs * 15);
    localStorage.setItem(`riyada_rep_points_${issue.affectedId}`, rep.toString());
    return { success: true, message: "تمت إعادة احتساب السمعة الرياضية وتعديل السجلات محلياً." };
  }

  if (issue.repairType === 'revoke_verification') {
    // Revoke gold verified
    localStorage.removeItem(`riyada_gold_verified_${issue.affectedId}`);
    return { success: true, message: "تم سحب الهوية المذهبة المشبوهة لمتجر العرض بنجاح." };
  }

  if (issue.repairType === 'expire_stuck_payment') {
    const o = await db.get('orders', issue.affectedId);
    if (o) {
      o.status = 'cancelled';
      await db.put('orders', o);
      return { success: true, message: `تم وسم الطلبية "${o.id}" كملغاة ومنتهية الصلاحية لعدم الالتزام بالتأكيد.` };
    }
  }

  if (issue.repairType === 'reset_unverified_payment') {
    const o = await db.get('orders', issue.affectedId);
    if (o) {
      o.status = 'payment_pending';
      if (o.paymentStatus) o.paymentStatus = 'pending';
      await db.put('orders', o);
      return { success: true, message: `تم إلغاء تأكيد دفع الطلب "${o.id}" وإعادته لكشف المراجعة للتحقق من الملحقات المكتومة.` };
    }
  }

  if (issue.repairType === 'reset_corrupted_localStorage') {
    localStorage.setItem(`riyada_platform_txs_${workspaceId || 'global'}`, '[]');
    return { success: true, message: "تم شحن وصفر مصفوفة ترقيات البقاع المحلية بنجاح." };
  }

  if (issue.repairType === 'resolve_status_conflict') {
    const o = await db.get('orders', issue.affectedId);
    if (o) {
      o.paymentStatus = 'refund_due';
      o.status = 'cancelled';
      await db.put('orders', o);
      return { success: true, message: `تم ضبط تصنيف الطلب "${o.id}" كطلب ملغى قيد استرجاع الرسوم (Refund Due) لحل التعارض الفني.` };
    }
  }

  return { success: false, message: "نوع الإصلاح مبرمج بآخر إصدار وغير مسموح حالياً." };
}
