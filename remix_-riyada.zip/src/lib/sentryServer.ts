/**
 * RIYADA - SENTRY API, DATABASE AND REALTIME INTEGRATION OBSERVABILITY
 * Passive server-side proxy tracking for Aiven PostgreSQL, Ably events, and backup services
 */
import * as Sentry from '@sentry/react';

export const sentryServer = {
  /**
   * Capture failures in Aiven PostgreSQL transactions
   */
  captureDatabaseError: (sql: string, error: any, params?: any[]) => {
    console.error(`[SENTRY_DB_FAILURE] SQL execution failed: ${error.message || error}`, { sql });
    
    try {
      Sentry.withScope((scope) => {
        scope.setTag('system', 'AIVEN_POSTGRESQL');
        scope.setTag('service', 'riyada-database-layer');
        scope.setLevel('error');
        
        // Strip out params structure if potential sensitive variables are present
        const safeParams = params ? params.map(val => {
          if (typeof val === 'string' && (val.length > 300 || val.includes('data:image') || val.includes('http'))) {
            return '[DATA_REDACTED_FOR_SENTRY_STORAGE]';
          }
          return val;
        }) : undefined;

        scope.setExtras({
          sqlQuery: sql,
          sqlParams: safeParams,
          rawErrorMessage: error.message || String(error)
        });

        Sentry.captureException(error);
      });
    } catch (e) {
      console.error('Sentry database capture failed:', e);
    }
  },

  /**
   * Capture Ably realtime network delivery or subscribe exceptions
   */
  captureRealtimeError: (event: string, action: 'publish' | 'subscribe' | 'connect', error: any) => {
    console.warn(`[SENTRY_REALTIME_FAILURE] Ably connection issue during "${action}": ${error.message || error}`);

    try {
      Sentry.withScope((scope) => {
        scope.setTag('system', 'ABLY_REALTIME');
        scope.setTag('realtime_action', action);
        scope.setTag('delivery_event', event);
        scope.setLevel('warning');
        
        scope.setExtras({
          eventName: event,
          actionPerformed: action,
          errorMessage: error.message || String(error)
        });

        Sentry.captureException(error);
      });
    } catch (e) {
      // Slient fail
    }
  },

  /**
   * Monitor npoint backup snapshot archives
   */
  captureBackupError: (action: 'export' | 'restore', npointId: string, error: any) => {
    console.error(`[SENTRY_BACKUP_FAILURE] Snapshot exception during "${action}" for Bin: "${npointId}"`);

    try {
      Sentry.withScope((scope) => {
        scope.setTag('system', 'NPOINT_BACKUP');
        scope.setTag('backup_action', action);
        scope.setLevel('error');

        scope.setExtras({
          action,
          targetNpointId: npointId,
          errorMessage: error.message || String(error)
        });

        Sentry.captureException(error);
      });
    } catch (e) {
      // Silent fail
    }
  },

  /**
   * Capture standard central routing/API gateway exceptions
   */
  captureApiError: (endpoint: string, error: any, requestPayload?: any) => {
    console.error(`[SENTRY_API_FAILURE] Request to endpoint "${endpoint}" threw exception: ${error.message || error}`);

    try {
      Sentry.withScope((scope) => {
        scope.setTag('system', 'FRONTEND_API_GATEWAY');
        scope.setTag('endpoint', endpoint);
        scope.setLevel('error');

        scope.setExtras({
          endpoint,
          payloadSample: requestPayload ? JSON.stringify(requestPayload).slice(0, 500) : undefined,
          errorMessage: error.message || String(error)
        });

        Sentry.captureException(error);
      });
    } catch (e) {
      // Silent fail
    }
  }
};
