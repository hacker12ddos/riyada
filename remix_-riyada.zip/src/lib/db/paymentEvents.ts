/**
 * DATABASE OPERATIONS FOR PAYMENT EVENTS
 * Stores and processes incoming JSON payloads to maintain resilient historical proof.
 */

import { query } from '../infrastructure';
import { logTelemetry } from '../infrastructure';

export interface PaymentEvent {
  id: string;
  orderId: string;
  status: string;
  payload: string; // JSON-stringened structure
  createdAt: number;
  processed: boolean;
}

const paymentEventsMemoryDb: Map<string, PaymentEvent> = new Map();

/**
 * Persists raw incoming webhook data before processing state transition checks.
 */
export async function savePaymentEvent(event: Omit<PaymentEvent, 'createdAt' | 'processed'>): Promise<PaymentEvent> {
  const newEvent: PaymentEvent = {
    ...event,
    createdAt: Date.now(),
    processed: false,
  };

  paymentEventsMemoryDb.set(newEvent.id, newEvent);

  // Aiven PostgreSQL raw query parameters insertion
  const sql = `
    INSERT INTO payment_events (id, order_id, status, payload, created_at, processed)
    VALUES ($1, $2, $3, $4, $5, $6)
    ON CONFLICT (id) DO NOTHING
  `;
  const params = [
    newEvent.id,
    newEvent.orderId,
    newEvent.status,
    newEvent.payload,
    newEvent.createdAt,
    0, // Represented as int/boolean safely
  ];

  await query(sql, params);

  logTelemetry({
    source: 'AIVEN_POSTGRES',
    type: 'success',
    message: `[DB_PAYMENT_EVENT_STORED] Saved audit state for payload message block ${newEvent.id}.`
  });

  return newEvent;
}

/**
 * Flag an event as handled inside the master databases.
 */
export async function markPaymentEventProcessed(id: string): Promise<boolean> {
  const existing = paymentEventsMemoryDb.get(id);
  if (existing) {
    existing.processed = true;
  }

  const sql = `UPDATE payment_events SET processed = 1 WHERE id = $1`;
  await query(sql, [id]);

  return true;
}

/**
 * Selects unprocessed events to rerun during background recovery sweeps.
 */
export async function getUnprocessedEvents(): Promise<PaymentEvent[]> {
  const list = Array.from(paymentEventsMemoryDb.values()).filter(ev => !ev.processed);
  
  const sql = `SELECT * FROM payment_events WHERE processed = 0 ORDER BY created_at ASC`;
  await query(sql, []);

  return list;
}
