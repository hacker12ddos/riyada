/**
 * RIYADA - SENTRY FRONTEND OBSERVABILITY LAYER
 * Standard passive wrappers for client clicks, page routing, and interface triggers
 */
import * as Sentry from '@sentry/react';

export const sentryClient = {
  /**
   * Safe Capture of React Runtime exceptions
   */
  captureException: (error: any, context?: Record<string, any>) => {
    // Console log fallback
    console.warn('[sentryClient_fail_captured]', error, context);
    
    try {
      Sentry.withScope((scope) => {
        scope.setTag('source', 'react-client');
        if (context) {
          scope.setExtras(context);
        }
        Sentry.captureException(error);
      });
    } catch (e) {
      console.error('Sentry client capture failed:', e);
    }
  },

  /**
   * Log critical telemetry messages
   */
  captureMessage: (message: string, level: Sentry.SeverityLevel = 'info', context?: Record<string, any>) => {
    console.info(`[sentryClient_telemetry] ${message}`, context);
    
    try {
      Sentry.withScope((scope) => {
        scope.setLevel(level);
        if (context) {
          scope.setExtras(context);
        }
        Sentry.captureMessage(message);
      });
    } catch (e) {
      console.error('Sentry client message capture failed:', e);
    }
  },

  /**
   * Lightweight breadcrumb tracker that contains zero sensitive user inputs
   */
  addBreadcrumb: (category: string, message: string, data?: Record<string, any>) => {
    try {
      Sentry.addBreadcrumb({
        category,
        message,
        data,
        level: 'info'
      });
    } catch (e) {
      // Slient fail
    }
  }
};
