import { getAllItems } from './db';

const TIME_DECAY = 1000 * 60 * 60 * 24 * 7; // 7 days

export const calculateProductsScore = async (products: any[]) => {
  const interactions = await getAllItems('interactions');
  const now = Date.now();

  const scores: Record<string, number> = {};

  // Weights
  const weights = {
    view: 1,
    favorite: 5,
    whatsapp: 10
  };

  interactions.forEach(interaction => {
    const age = now - interaction.timestamp;
    if (age > TIME_DECAY) return; // ignore old interactions

    const decayFactor = 1 - (age / TIME_DECAY);
    const scoreIncrease = weights[interaction.type as keyof typeof weights] * decayFactor;

    scores[interaction.productId] = (scores[interaction.productId] || 0) + scoreIncrease;
  });

  return products.map(p => {
    // Base score from local interactions
    let score = scores[p.id] || 0;
    
    // Pure, real-only small verified seller boost
    if (p.verified) score += 5;
    
    // Recency boost (up to 10 points for products published in the last 72 hours)
    const productAge = now - (p.createdAt || now);
    const threeDays = 1000 * 60 * 60 * 24 * 3;
    if (productAge < threeDays) {
      const recencyBoost = 10 * (1 - (productAge / threeDays));
      score += recencyBoost;
    }

    return {
      ...p,
      trendingScore: score
    };
  }).sort((a, b) => b.trendingScore - a.trendingScore); // Sort by highest score first
};

export const getTrendingProducts = async (products: any[], limit: number = 10) => {
  const scored = await calculateProductsScore(products);
  return scored.slice(0, limit);
};
