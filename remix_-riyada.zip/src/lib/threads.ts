export interface ChatMessage {
  id: string;
  sender: 'buyer' | 'seller';
  text: string;
  timestamp: number;
  offerPrice?: number;
}

export interface NegotiateThread {
  id: string;
  productId: string;
  productName: string;
  productPrice: number;
  productImage?: string | null;
  vendorId: string;
  buyerName: string;
  buyerPhone: string;
  status: 'initiated' | 'offer_sent' | 'negotiation' | 'deal_accepted' | 'deal_rejected';
  buyerOfferPrice?: number;
  sellerOfferPrice?: number;
  messages: ChatMessage[];
  updatedAt: number;
}

const STORAGE_KEY = 'riyada_negotiations';

export function getNegotiationThreads(): NegotiateThread[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error(e);
    return [];
  }
}

export function saveNegotiationThreads(threads: NegotiateThread[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(threads));
  } catch (e) {
    console.error(e);
  }
}

export function saveNegotiationThread(thread: NegotiateThread) {
  const all = getNegotiationThreads();
  const idx = all.findIndex(t => t.id === thread.id);
  thread.updatedAt = Date.now();
  if (idx > -1) {
    all[idx] = thread;
  } else {
    all.push(thread);
  }
  saveNegotiationThreads(all);
}

export function createNegotiationThread(
  productId: string,
  productName: string,
  productPrice: number,
  productImage: string | null | undefined,
  vendorId: string,
  buyerName: string,
  buyerPhone: string,
  initialText: string,
  offerPrice?: number
): NegotiateThread {
  const newThread: NegotiateThread = {
    id: `THR-${Math.floor(100000 + Math.random() * 900000)}`,
    productId,
    productName,
    productPrice,
    productImage,
    vendorId,
    buyerName,
    buyerPhone,
    status: offerPrice ? 'offer_sent' : 'initiated',
    buyerOfferPrice: offerPrice,
    messages: [
      {
        id: crypto.randomUUID(),
        sender: 'buyer',
        text: initialText,
        timestamp: Date.now(),
        offerPrice
      }
    ],
    updatedAt: Date.now()
  };
  saveNegotiationThread(newThread);
  return newThread;
}
