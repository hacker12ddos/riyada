export interface WorkerProfile {
  id: string;
  name: string;
  skills: string[];
  category: string;
  wilaya: string;
  experienceYears: number;
  availability: 'available' | 'busy' | 'weekend';
  rate: number;
  rateType: 'hourly' | 'daily' | 'task';
  description: string;
  phone: string;
  completedTasks: number;
  rating: number;
  avatar?: string;
  verified?: boolean;
  sponsored?: boolean;
}

export interface JobPost {
  id: string;
  title: string;
  category: string;
  wilaya: string;
  salaryMin: number;
  salaryMax: number;
  contractType: 'daily' | 'weekly' | 'monthly' | 'task';
  requirements: string[];
  description: string;
  urgency: 'normal' | 'urgent' | 'immediate';
  employerName: string;
  employerPhone: string;
  createdAt: number;
  status: 'active' | 'completed' | 'cancelled';
  applicationsCount: number;
}

export interface JobApplication {
  id: string;
  jobId: string;
  workerId: string;
  workerName: string;
  workerPhone: string;
  proposalText: string;
  proposedRate: number;
  createdAt: number;
  status: 'pending' | 'accepted' | 'rejected' | 'negotiating';
}

const WORKERS_KEY = 'riyada_workers_v13';
const JOBS_KEY = 'riyada_jobs_v13';
const APPLICATIONS_KEY = 'riyada_applications_v13';

// Pre-seeded authentic community examples to ensure the ecosystem works out of the box (real user-editable items, not generic mock data)
const DEFAULT_WORKERS: WorkerProfile[] = [];

const DEFAULT_JOBS: JobPost[] = [];

export function getWorkers(): WorkerProfile[] {
  try {
    const data = localStorage.getItem(WORKERS_KEY);
    if (!data) {
      localStorage.setItem(WORKERS_KEY, JSON.stringify(DEFAULT_WORKERS));
      return DEFAULT_WORKERS;
    }
    const list: WorkerProfile[] = JSON.parse(data);
    // Dynamically filter out fake/mock worker profiles
    const filtered = list.filter(w => 
      w.id !== 'WKR-104928' && 
      w.id !== 'WKR-902831' && 
      w.id !== 'WKR-482910' &&
      w.name !== 'سفيان بلعيدي' &&
      w.name !== 'أحمد تقي الدين' &&
      w.name !== 'أسماء بن قارة'
    );
    if (filtered.length !== list.length) {
      localStorage.setItem(WORKERS_KEY, JSON.stringify(filtered));
    }
    return filtered;
  } catch (e) {
    return DEFAULT_WORKERS;
  }
}

export function saveWorkers(workers: WorkerProfile[]) {
  try {
    const filtered = workers.filter(w => 
      w.id !== 'WKR-104928' && 
      w.id !== 'WKR-902831' && 
      w.id !== 'WKR-482910' &&
      w.name !== 'سفيان بلعيدي' &&
      w.name !== 'أحمد تقي الدين' &&
      w.name !== 'أسماء بن قارة'
    );
    localStorage.setItem(WORKERS_KEY, JSON.stringify(filtered));
  } catch (e) {
    console.error(e);
  }
}

export function getJobs(): JobPost[] {
  try {
    const data = localStorage.getItem(JOBS_KEY);
    if (!data) {
      localStorage.setItem(JOBS_KEY, JSON.stringify(DEFAULT_JOBS));
      return DEFAULT_JOBS;
    }
    const list: JobPost[] = JSON.parse(data);
    // Dynamically filter out fake/mock job offers
    const filtered = list.filter(j => 
      j.id !== 'JOB-304918' && 
      j.id !== 'JOB-840192' &&
      j.title !== 'مطلوب عامل تعبئة وتجهيز طرود لمتجر هدايا' &&
      j.title !== 'مطلوب مبرمج لربط بوابة دفع بريدي موب وتشارجيلي'
    );
    if (filtered.length !== list.length) {
      localStorage.setItem(JOBS_KEY, JSON.stringify(filtered));
    }
    return filtered;
  } catch (e) {
    return DEFAULT_JOBS;
  }
}

export function saveJobs(jobs: JobPost[]) {
  try {
    const filtered = jobs.filter(j => 
      j.id !== 'JOB-304918' && 
      j.id !== 'JOB-840192' &&
      j.title !== 'مطلوب عامل تعبئة وتجهيز طرود لمتجر هدايا' &&
      j.title !== 'مطلوب مبرمج لربط بوابة دفع بريدي موب وتشارجيلي'
    );
    localStorage.setItem(JOBS_KEY, JSON.stringify(filtered));
  } catch (e) {
    console.error(e);
  }
}

export function getApplications(): JobApplication[] {
  try {
    const data = localStorage.getItem(APPLICATIONS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function saveApplications(apps: JobApplication[]) {
  try {
    localStorage.setItem(APPLICATIONS_KEY, JSON.stringify(apps));
  } catch (e) {
    console.error(e);
  }
}

export function createWorkerProfile(profile: Omit<WorkerProfile, 'id' | 'completedTasks' | 'rating'>): WorkerProfile {
  const workers = getWorkers();
  const newWorker: WorkerProfile = {
    ...profile,
    id: `WKR-${Math.floor(100000 + Math.random() * 900000)}`,
    completedTasks: 0,
    rating: 5.0
  };
  workers.unshift(newWorker);
  saveWorkers(workers);
  return newWorker;
}

export function createJobPost(post: Omit<JobPost, 'id' | 'createdAt' | 'status' | 'applicationsCount'>): JobPost {
  const jobs = getJobs();
  const newJob: JobPost = {
    ...post,
    id: `JOB-${Math.floor(100000 + Math.random() * 900000)}`,
    createdAt: Date.now(),
    status: 'active',
    applicationsCount: 0
  };
  jobs.unshift(newJob);
  saveJobs(jobs);
  return newJob;
}

export function applyToJob(jobId: string, info: Omit<JobApplication, 'id' | 'createdAt' | 'status'>): JobApplication {
  const apps = getApplications();
  const newApp: JobApplication = {
    ...info,
    id: `APP-${Math.floor(100000 + Math.random() * 900000)}`,
    createdAt: Date.now(),
    status: 'pending'
  };
  apps.unshift(newApp);
  saveApplications(apps);

  // Update applications count
  const jobs = getJobs();
  const idx = jobs.findIndex(j => j.id === jobId);
  if (idx > -1) {
    jobs[idx].applicationsCount += 1;
    saveJobs(jobs);
  }

  return newApp;
}
