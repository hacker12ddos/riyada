/**
 * RIYADA v23 Environment Variable Safety and Connection Validator
 * Ensures zero hardcoding of secrets and clean local database fallback
 */

const metaEnv = (import.meta as any).env || {};

export const ENV = {
  isVercelProd: metaEnv.VITE_VERCEL_ENV === 'production',
  isVercelPreview: metaEnv.VITE_VERCEL_ENV === 'preview',
  isLocalDev: (import.meta as any).DEV || false,
};

export interface ConnectionStatus {
  isConnected: boolean;
  mode: 'local-indexeddb';
  explanation: string;
}

export function getDatabaseConnectionStatus(): ConnectionStatus {
  return {
    isConnected: true,
    mode: 'local-indexeddb',
    explanation: 'أنت الآن في (وضع المحاكاة المحلية الآمنة). يتم تخزين كافة البيانات والوظائف والسلع في متصفحك مباشرة عبر IndexedDB دون الحاجة لخادم مستضاف.'
  };
}
