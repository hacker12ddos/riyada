import React, { useState, useEffect } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { LayoutDashboard, Package, ShoppingCart, Users, Settings, LogOut, MessageSquare, FileText, Wifi, WifiOff, Calculator, Shield, Activity, Coins, Chrome, Terminal, ExternalLink } from 'lucide-react';
import { useWorkspace } from '../../contexts/WorkspaceContext';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

const NAV_ITEMS = [
  { icon: LayoutDashboard, label: 'لوحة التحكم', path: '/dashboard' },
  { icon: Package, label: 'المخزون', path: '/dashboard/products' },
  { icon: ShoppingCart, label: 'الطلبات', path: '/dashboard/orders' },
  { icon: Users, label: 'الزبائن', path: '/dashboard/customers' },
  { icon: MessageSquare, label: 'المراسلات والصفقات', path: '/dashboard/whatsapp' },
  { icon: Calculator, label: 'حاسبة ومؤشرات', path: '/dashboard/utilities' },
  { icon: Shield, label: 'مركّز الدفع والأمان', path: '/dashboard/safety' },
  { icon: Coins, label: 'مركز النمو والترقيات', path: '/dashboard/monetization' },
  { icon: Chrome, label: 'ملحقات المتصفح', path: '/dashboard/extensions' },
  { icon: Activity, label: 'سلامة ونزاهة النظام', path: '/dashboard/system-audit' },
  { icon: Terminal, label: 'مساعد النشر السحابي', path: '/dashboard/setup-wizard' },
  { icon: Settings, label: 'الإعدادات', path: '/dashboard/settings' },
];

export default function DashboardLayout() {
  const { activeWorkspace } = useWorkspace();
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [degradationLevel, setDegradationLevel] = useState(() => localStorage.getItem('riyada_v3_degradation_level') || '1');

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    
    const handleDegradationChange = () => {
      setDegradationLevel(localStorage.getItem('riyada_v3_degradation_level') || '1');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('riyada_degradation_change', handleDegradationChange);

    const interval = setInterval(handleDegradationChange, 1000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('riyada_degradation_change', handleDegradationChange);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col md:flex-row overflow-hidden relative font-sans text-white bg-[#05070a]">
      {/* Offline Banner */}
      <AnimatePresence>
        {isOffline && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="absolute top-0 left-0 w-full z-[100] bg-orange-500 text-white text-xs font-bold py-1.5 text-center flex items-center justify-center gap-2 overflow-hidden shadow-lg"
          >
            <WifiOff className="w-3.5 h-3.5" />
            أنت تعمل في وضع عدم الاتصال (Offline) - سيتم مزامنة البيانات تلقائياً عند الاتصال
          </motion.div>
        )}
      </AnimatePresence>

      {/* System Degradation Level Banner */}
      <AnimatePresence>
        {degradationLevel !== '1' && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className={cn(
              "w-full z-[99] text-white text-[11px] sm:text-xs font-bold py-2 px-4 text-center flex items-center justify-center gap-2 overflow-hidden shadow-lg shrink-0",
              degradationLevel === '2' ? "bg-amber-600 border-b border-amber-500" : "bg-red-700 border-b border-red-600 animate-pulse"
            )}
          >
            <Activity className="w-4 h-4 text-white" />
            <span>
              {degradationLevel === '2' && "⚠️ وضع ضغط الشبكة النشط (LEVEL 2): تم تخفيض استهلاك الأي بي إس وتحجيم استعلامات التحليل لضمان دقة واستمرارية المعرض."}
              {degradationLevel === '3' && "🚨 وضع الاستعادة الحرج (LEVEL 3): المنصة تعمل في وضع القراءة فقط (Read-Only) لحماية نوى قواعد البيانات D1 والاتصالات."}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar (Bottom on mobile, Right on desktop) */}
      <aside className="bg-[#0a0f18] md:w-64 md:h-screen sticky bottom-0 md:top-0 z-50 flex flex-col border-t md:border-t-0 md:border-l border-white/10 md:py-8 md:px-4">
        <div className="hidden md:flex flex-col items-center gap-2 mb-8">
          <div className="w-12 h-12 bg-[#1AAE8A] rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(26,174,138,0.3)]">
            <span className="text-2xl font-bold italic text-[#05070a]">R</span>
          </div>
          <h1 className="text-xl font-bold tracking-wider text-white">ريادة</h1>
          <p className="text-[10px] text-[#1AAE8A] font-mono tracking-[4px] opacity-70 uppercase">R I Y A D A</p>
        </div>

        <nav className="flex md:flex-col overflow-x-auto md:overflow-visible gap-1 md:gap-2 flex-1 scrollbar-hide w-full">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center flex-shrink-0 md:w-full gap-4 px-4 py-3 rounded-lg cursor-pointer transition-colors",
                isActive 
                  ? "bg-white/5 border-r-2 border-brand-500 text-white" 
                  : "text-white/50 hover:bg-white/5"
              )}
            >
              <item.icon className="w-5 h-5 flex-shrink-0 opacity-80" />
              <span className="hidden md:block text-sm font-medium">{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="hidden md:block mt-auto w-full px-2">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-brand-400 tracking-tighter uppercase">Verified Store</span>
              <div className="w-2 h-2 rounded-full bg-brand-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
            </div>
            <p className="text-xs text-white/70 line-clamp-1">{activeWorkspace?.name || 'متجر بومرداس'}</p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative w-full overflow-hidden">
        <div className="hidden md:flex h-16 border-b border-white/10 items-center justify-between px-8 bg-[#0a0f18]/50 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-6">
            <NavLink to="/" target="_blank" rel="noopener noreferrer" className="text-xs text-white/50 hover:text-white flex items-center gap-1 transition-colors border border-white/10 bg-white/5 px-3 py-1.5 rounded-full shadow-sm hover:bg-white/10">
              &rarr; العودة للمنصة العامة
            </NavLink>
            <a 
              href={window.location.origin + window.location.pathname}
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors border border-cyan-500/20 bg-cyan-500/10 px-3.5 py-1.5 rounded-full shadow-lg shadow-cyan-500/5 hover:bg-cyan-500/15"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>الفتح في نافذة مستقلة ↗</span>
            </a>
            <div className="flex items-center gap-2">
              <div className={cn("w-3 h-3 rounded-full", isOffline ? "bg-orange-500 animate-pulse" : "bg-brand-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]")}></div>
              <span className="text-xs font-semibold text-white">
                {isOffline ? 'غير متصل بالإنترنت' : 'متصل (مزامنة أوفلاين)'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
              <span className="text-xs text-white">أدمن: {activeWorkspace?.name || 'مستخدم'}</span>
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-brand-400 to-cyan-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]"></div>
            </div>
          </div>
        </div>
        <div className="p-4 md:p-8 flex-1 overflow-y-auto mt-6 md:mt-0">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
