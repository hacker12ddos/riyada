import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Search, ShoppingBag, Heart, User, Store, ShieldCheck } from 'lucide-react';
import { Button } from '../ui/Button';

export default function PublicLayout() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col font-sans text-white bg-[#05070a] selection:bg-brand-500/30">
      {/* Top Navigation */}
      <nav className="sticky top-0 z-50 bg-[#0a0f18]/80 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-4">
          <div className="flex items-center justify-between gap-4">
            
            {/* Logo */}
            <div 
              className="flex items-center gap-3 cursor-pointer shrink-0" 
              onClick={() => navigate('/')}
            >
              <div className="w-10 h-10 bg-[#1AAE8A] rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(26,174,138,0.3)]">
                <span className="text-xl font-bold italic text-[#05070a]">R</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg font-bold tracking-wider text-white leading-none mb-1">ريادة</h1>
                <p className="text-[9px] text-[#1AAE8A] font-mono tracking-[3px] opacity-80 uppercase leading-none">Marketplace</p>
              </div>
            </div>

            {/* Search Bar (Desktop) */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                const q = new FormData(e.currentTarget).get('q');
                if (q) navigate(`/marketplace?q=${encodeURIComponent(q as string)}`);
                else navigate(`/marketplace`);
              }}
              className="hidden md:flex flex-1 max-w-2xl mx-8"
            >
              <div className="relative w-full border border-white/10 rounded-full focus-within:border-brand-500/50 focus-within:ring-1 focus-within:ring-brand-500/50 transition-all">
                <input 
                  type="text" 
                  name="q"
                  placeholder="ابحث عن منتجات، متاجر، إلكترونيات..." 
                  className="w-full bg-white/5 rounded-full h-12 px-6 pl-12 text-sm text-white focus:outline-none transition-all placeholder:text-white/30"
                />
                <button type="submit" className="absolute left-2 top-2 p-2 text-white/50 hover:text-white hover:bg-white/5 rounded-full transition-colors">
                  <Search className="w-5 h-5" />
                </button>
              </div>
            </form>

            {/* Actions */}
            <div className="flex items-center gap-2 sm:gap-4 shrink-0">
              <button 
                onClick={() => {
                  const q = prompt("ابحث عن فوري بـ ريادة:");
                  if (q) navigate(`/marketplace?q=${encodeURIComponent(q)}`);
                }}
                className="md:hidden p-2 text-white/70 hover:text-white hover:bg-white/5 rounded-full transition-colors"
              >
                <Search className="w-5 h-5" />
              </button>
              <button 
                onClick={() => navigate('/saved')}
                className="p-2 text-white/70 hover:text-white hover:bg-white/5 rounded-full transition-colors relative"
              >
                <Heart className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-brand-500"></span>
              </button>
              
              <div className="w-[1px] h-6 bg-white/10 mx-1 hidden sm:block"></div>
              
              <Button 
                variant="ghost" 
                className="hidden sm:flex"
                onClick={() => navigate('/onboarding')}
              >
                بيع على ريادة
              </Button>
              <Button 
                className="gap-2 px-4 py-2 h-10"
                onClick={() => navigate('/dashboard')}
              >
                <Store className="w-4 h-4" />
                <span className="text-sm">متجري</span>
              </Button>
            </div>
          </div>
          
          {/* Categories Bar */}
          <div className="flex items-center gap-6 mt-4 overflow-x-auto scrollbar-hide pb-2 text-sm text-white/60">
            <button onClick={() => navigate('/')} className="shrink-0 hover:text-white transition-colors text-brand-400 font-bold">🏠 الرئيسية</button>
            <button onClick={() => navigate('/workers')} className="shrink-0 hover:text-white transition-colors text-brand-400 font-bold">👷 شبكة العمال والحرفيين</button>
            <button onClick={() => navigate('/jobs')} className="shrink-0 hover:text-white transition-colors text-brand-400 font-bold">💼 سوق المقاولات والوظائف</button>
            <div className="w-[1px] h-4 bg-white/20 shrink-0"></div>
            <button onClick={() => navigate('/marketplace')} className="shrink-0 hover:text-white transition-colors">كل المعروضات</button>
            <button onClick={() => navigate('/marketplace?category=إلكترونيات')} className="shrink-0 hover:text-white transition-colors">إلكترونيات</button>
            <button onClick={() => navigate('/marketplace?category=ملابس وأزياء')} className="shrink-0 hover:text-white transition-colors">ملابس وأزياء</button>
            <button onClick={() => navigate('/marketplace?category=مستحضرات تجميل')} className="shrink-0 hover:text-white transition-colors block">مستحضرات تجميل</button>
            <button onClick={() => navigate('/marketplace?category=عقارات')} className="shrink-0 hover:text-white transition-colors">عقارات</button>
            <button onClick={() => navigate('/marketplace?category=سيارات')} className="shrink-0 hover:text-white transition-colors">سيارات</button>
            <button onClick={() => navigate('/marketplace?category=خدمات')} className="shrink-0 hover:text-white transition-colors">خدمات</button>
            <button onClick={() => navigate('/marketplace?category=مطاعم وأكل')} className="shrink-0 hover:text-white transition-colors">مطاعم وأكل</button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 md:px-8 py-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-white/5 py-8 bg-[#0a0f18]/50">
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-brand-500" />
            <span className="text-sm text-white/50">ريادة - المنصة اللامركزية للتجارة الآمنة بالجزائر © 2026</span>
          </div>
          <div className="flex gap-4 text-sm text-white/40">
            <NavLink to="/about" className="hover:text-brand-400 transition-colors">عن ريادة</NavLink>
            <NavLink to="/terms" className="hover:text-brand-400 transition-colors">قوانين المنصة والخصوصية</NavLink>
          </div>
        </div>
      </footer>
    </div>
  );
}
