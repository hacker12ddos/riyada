import React, { useState, useEffect } from 'react';
import { Image, ShieldAlert, Loader2 } from 'lucide-react';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src?: string | null;
  alt: string;
  fallbackType?: 'product' | 'avatar';
  className?: string;
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  fallbackType = 'product',
  className = '',
  ...props
}) => {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    // Reset status on source change
    setLoaded(false);
    setError(false);
  }, [src]);

  const handleLoad = () => {
    setLoaded(true);
  };

  const handleError = () => {
    setError(true);
  };

  // Safe Fallback Display
  if (error || !src) {
    return (
      <div className={`bg-neutral-900 border border-white/5 flex flex-col items-center justify-center p-4 text-center select-none ${className}`}>
        {fallbackType === 'product' ? (
          <Image className="w-8 h-8 text-neutral-600 mb-1" />
        ) : (
          <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-500 font-bold">
            {alt.charAt(0)}
          </div>
        )}
        <span className="text-[9px] text-white/30 font-semibold mt-1">صورة المعروض</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Loading state indicator */}
      {!loaded && (
        <div className="absolute inset-0 bg-[#0c121e] flex items-center justify-center">
          <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
        </div>
      )}

      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={handleLoad}
        onError={handleError}
        referrerPolicy="no-referrer"
        className={`w-full h-full object-cover transition-transform duration-500 ${
          loaded ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
        }`}
        {...props}
      />
    </div>
  );
};
export default OptimizedImage;
