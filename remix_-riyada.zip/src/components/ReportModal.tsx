import React, { useState } from 'react';
import { Flag, X, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/Button';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId: string;
  targetType: 'product' | 'vendor';
}

const REPORT_REASONS = [
  'منتج مزيف / مقلد',
  'بائع وهمي / احتيال',
  'إعلان مكرر',
  'سعر مضلل / غير حقيقي',
  'منتج ممنوع قانونياً',
  'سلوك مشبوه'
];

export function ReportModal({ isOpen, onClose, targetId, targetType }: ReportModalProps) {
  const [selectedReason, setSelectedReason] = useState<string>('');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReason) return;
    
    setIsSubmitting(true);
    
    // Simulate API call since no backend
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      // We would track this interaction in DB locally
      import('../lib/db').then(({ trackInteraction }) => {
        trackInteraction(targetId, 'report', undefined);
      });
      
      setTimeout(() => {
        setIsSubmitted(false);
        setSelectedReason('');
        setDetails('');
        onClose();
      }, 2000);
    }, 1000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative bg-[#0f1520] border border-white/10 p-6 rounded-2xl shadow-2xl w-full max-w-md"
          >
            <button
              onClick={onClose}
              className="absolute top-4 left-4 text-white/50 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {isSubmitted ? (
              <div className="flex flex-col items-center justify-center py-8 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center border-2 border-emerald-500/50">
                  <Flag className="w-8 h-8 text-emerald-400" />
                </div>
                <h3 className="text-xl font-bold text-white">تم استلام بلاغك</h3>
                <p className="text-white/60">شكراً لمساهمتك في جعل منصة ريادة مكاناً أكثر أماناً. سيتم مراجعة بلاغك في أقرب وقت.</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-red-500/10 rounded-full flex items-center justify-center border border-red-500/20">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      الإبلاغ عن {targetType === 'product' ? 'منتج' : 'متجر'}
                    </h3>
                    <p className="text-xs text-white/50">سيتم التعامل مع بلاغك بسرية تامة</p>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white/80">سبب الإبلاغ <span className="text-red-400">*</span></label>
                    <select 
                      value={selectedReason}
                      onChange={(e) => setSelectedReason(e.target.value)}
                      required
                      className="w-full bg-[#0a0f18] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors"
                    >
                      <option value="">-- اختر السبب --</option>
                      {REPORT_REASONS.map(r => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white/80">تفاصيل إضافية (اختياري)</label>
                    <textarea 
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      rows={3}
                      placeholder="يرجى تزويدنا بأي تفاصيل إضافية تساعدنا في مراجعة البلاغ..."
                      className="w-full bg-[#0a0f18] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors resize-none"
                    />
                  </div>

                  <div className="pt-2 flex gap-3">
                    <Button type="button" variant="secondary" className="flex-1" onClick={onClose}>إلغاء</Button>
                    <Button type="submit" className="flex-1 bg-red-500 hover:bg-red-600 border-red-600" disabled={!selectedReason || isSubmitting} isLoading={isSubmitting}>
                      إرسال البلاغ
                    </Button>
                  </div>
                </form>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
