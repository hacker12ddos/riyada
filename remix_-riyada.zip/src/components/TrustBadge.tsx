import React, { useState } from 'react';
import { ShieldCheck, Info, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

interface TrustBadgeProps {
  className?: string;
}

export function TrustBadge({ className = '' }: TrustBadgeProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <span 
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(true);
        }}
        className={`bg-emerald-500/20 text-emerald-400 text-xs px-2 py-1 rounded border border-emerald-500/30 flex items-center gap-1 cursor-pointer hover:bg-emerald-500/30 transition-colors ${className}`}
      >
        <ShieldCheck className="w-3.5 h-3.5" /> موثق
      </span>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4" onClick={(e) => e.stopPropagation()}>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-[#0f1520] border border-white/10 p-6 rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
            >
              <button 
                onClick={() => setIsOpen(false)}
                className="absolute top-4 left-4 text-white/50 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mb-4 mx-auto border border-emerald-500/20">
                <ShieldCheck className="w-6 h-6 text-emerald-400" />
              </div>
              
              <h3 className="text-xl font-bold text-white text-center mb-2">متجر موثوق</h3>
              <p className="text-sm text-white/70 text-center mb-6 leading-relaxed">
                هذا البائع تم التحقق من هويته عبر منصة ريادة. نحن نضمن مستوى عالٍ من الأمان والموثوقية للمتاجر الموثقة.
              </p>

              <div className="space-y-3 bg-[#0a0f18] p-4 rounded-xl border border-white/5">
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-1.5 h-1.5 rounded-full bg-brand-400 shrink-0"></div>
                  <p className="text-xs text-white/80 leading-relaxed">تم التحقق من رقم الهاتف ومعلومات الاتصال لتوفير أمان أكبر.</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-1.5 h-1.5 rounded-full bg-brand-400 shrink-0"></div>
                  <p className="text-xs text-white/80 leading-relaxed">البائع نشط ويملك تقييمات إيجابية في توصيل الطلبات.</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="mt-1 w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0"></div>
                  <p className="text-xs text-white/70 leading-relaxed">
                    <span className="text-amber-400 font-bold">تنويه:</span> الشراء دائماً مسؤوليتك. يُرجى التحقق من جودة المنتج عند الاستلام (الدفع عند الاستلام).
                  </p>
                </div>
              </div>

              <div className="mt-6 flex justify-center">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="bg-white/10 hover:bg-white/20 text-white text-sm px-6 py-2 rounded-xl transition-colors"
                >
                  حسناً، فهمت
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
