import React from 'react';
import { cn } from '../../lib/utils';

// removed interface SkeletonProps

export function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-white/5", className)}
      {...props}
    />
  );
}

export function SkeletonCard() {
  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between backdrop-blur-sm shadow-xl h-32">
      <div className="flex justify-between items-start">
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-4 w-12 rounded-full" />
      </div>
      <div className="flex items-baseline gap-2 mt-auto">
        <Skeleton className="h-8 w-32" />
      </div>
    </div>
  );
}

export function SkeletonRow() {
  return (
    <div className="border-b border-white/5 h-14 flex items-center px-4 gap-4">
      <Skeleton className="h-8 w-8 rounded-lg" />
      <Skeleton className="h-4 w-32" />
      <div className="ml-auto flex gap-4">
        <Skeleton className="h-4 w-16" />
        <Skeleton className="h-6 w-16 rounded" />
      </div>
    </div>
  );
}
