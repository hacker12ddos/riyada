import React from 'react';
import { cn } from '../../lib/utils';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, icon, ...props }, ref) => {
    return (
      <div className="w-full space-y-1.5">
        {label && (
          <label className="block text-sm font-medium text-white/70">
            {label}
          </label>
        )}
        <div className="relative">
          <input
            ref={ref}
            className={cn(
              'glass-input flex h-11 w-full rounded-xl px-4 py-2 text-sm text-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-white/30 disabled:cursor-not-allowed disabled:opacity-50',
              icon && 'ps-10',
              error && 'border-red-500/50 focus:border-red-500/50 focus:ring-red-500/50',
              className
            )}
            {...props}
          />
          {icon && (
            <div className="absolute inset-y-0 start-0 flex items-center ps-3 text-white/50 pointer-events-none">
              {icon}
            </div>
          )}
        </div>
        {error && (
          <p className="text-sm text-red-400">{error}</p>
        )}
      </div>
    );
  }
);
Input.displayName = 'Input';
