/**
 * RIYADA RECONCILIATION SWEEPER
 * Automatic background recover routine to protect against network drops or system crashes.
 * Resolves stale WAITING_WEBHOOK orders by validating stored RAW payment events.
 */

import { getUnprocessedEvents, markPaymentEventProcessed } from '../lib/db/paymentEvents';
import { updateOrderStatus } from '../lib/services/ordersService';
import { logTelemetry } from '../lib/infrastructure';
import { sentryServer } from '../lib/sentryServer';

const IS_RUNNING = { active: false };

/**
 * Sweeps unprocessed events and applies state machine changes based on verified data.
 */
export async function runReconciliationSweep(): Promise<{ processedCount: number }> {
  if (IS_RUNNING.active) {
    return { processedCount: 0 };
  }

  IS_RUNNING.active = true;
  let processedCount = 0;

  try {
    logTelemetry({
      source: 'SYSTEM',
      type: 'info',
      message: '[RECONCILIATION_JOB] Launching background payment recovery sweeping pass...'
    });

    const unprocessedList = await getUnprocessedEvents();

    for (const event of unprocessedList) {
      try {
        const payloadData = JSON.parse(event.payload);
        const orderId = event.orderId;
        const checkoutStatus = event.status;

        if (checkoutStatus === 'paid') {
          logTelemetry({
            source: 'AIVEN_POSTGRES',
            type: 'warning',
            message: `[RECONCILIATION] Unresolved payment event found for Order: "${orderId}". Triggering automatic recovery.`
          });

          // Ensure order transitions securely
          const committed = await updateOrderStatus(orderId, 'paid');
          if (committed) {
            await markPaymentEventProcessed(event.id);
            processedCount++;
          }
        } else {
          // Non-paid event is marked processed since no payment state modification is required
          await markPaymentEventProcessed(event.id);
          processedCount++;
        }
      } catch (innerError: any) {
        sentryServer.captureDatabaseError('RECONCILIATION_ITEM_PASS', innerError, [event.id]);
      }
    }

    logTelemetry({
      source: 'SYSTEM',
      type: 'success',
      message: `[RECONCILIATION_JOB] Sweeper pass completed. Reconciled and resolved ${processedCount} payment records.`
    });

  } catch (error: any) {
    sentryServer.captureApiError('paymentRecoverySweepJob', error);
  } finally {
    IS_RUNNING.active = false;
  }

  return { processedCount };
}

/**
 * Schedules the recovery routine to loop cleanly every 4 minutes.
 */
export function startRecoveryScheduler() {
  setInterval(() => {
    runReconciliationSweep().catch(e => {
      console.error('[SCHEDULER] Sweeper error:', e);
    });
  }, 240000); // 4 minutes
}
