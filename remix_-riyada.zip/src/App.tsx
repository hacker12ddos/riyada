import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { WorkspaceProvider, useWorkspace } from './contexts/WorkspaceContext';
import { ToastProvider, useToast } from './contexts/ToastContext';
import { Loader2, AlertTriangle, ShieldAlert, CheckCircle2, ServerCrash, Hammer } from 'lucide-react';

import DashboardLayout from './components/layout/DashboardLayout';
import PublicLayout from './components/layout/PublicLayout';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import WhatsAppEngine from './pages/WhatsApp';
import Orders from './pages/Orders';
import Customers from './pages/Customers';
import Settings from './pages/Settings';
import MarketplaceFeed from './pages/Marketplace';
import VendorProfile from './pages/VendorProfile';
import ProductDetail from './pages/ProductDetail';
import Saved from './pages/Saved';
import Utilities from './pages/Utilities';
import About from './pages/About';
import Terms from './pages/Terms';
import Workers from './pages/Workers';
import Jobs from './pages/Jobs';
import Home from './pages/Home';
import PaymentSafety from './pages/PaymentSafety';
import SystemAudit from './pages/SystemAudit';
import SellerMonetization from './pages/SellerMonetization';
import ExtensionEcosystem from './pages/ExtensionEcosystem';
import SetupWizard from './pages/SetupWizard';

import ErrorBoundary from './components/ErrorBoundary';
import { getActiveSession } from './lib/roles';
import { SITE_MAINTENANCE } from './lib/constants';
import { API } from './lib/api';

// Protected Route Wrapper with Workspace and Role Authorization checks
const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode; allowedRoles?: string[] }) => {
  const { activeWorkspace, isLoading } = useWorkspace();
  const session = getActiveSession();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#05070a] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#18C29C] animate-spin" />
      </div>
    );
  }

  if (!activeWorkspace) {
    return <Navigate to="/onboarding" replace />;
  }

  // Role verification check
  if (allowedRoles && !allowedRoles.includes(session.role)) {
    return (
      <div className="min-h-screen bg-[#05070a] flex flex-col items-center justify-center p-6 text-right">
        <div className="bg-[#0b121e] border border-red-500/10 p-8 rounded-2xl max-w-sm text-center space-y-4">
          <ShieldAlert className="w-12 h-12 text-red-400 mx-auto" />
          <h1 className="text-white font-bold text-lg">غير مصرح بالدخول</h1>
          <p className="text-xs text-white/50 leading-relaxed">
            حسابك لا يملك الصلاحية اللازمة للوصول لهذه التحكم المركزي. يرجى مراجعة مسؤول منصة ريادة.
          </p>
          <button 
            onClick={() => window.location.href = '/dashboard'}
            className="px-4 py-2 text-xs rounded-xl bg-[#18C29C] text-black font-semibold cursor-pointer"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

// Onboarding Wrapper
const OnboardingRoute = ({ children }: { children: React.ReactNode }) => {
  const { activeWorkspace, isLoading } = useWorkspace();
  
  if (isLoading) return null;
  if (activeWorkspace) return <Navigate to="/dashboard" replace />;
  
  return <>{children}</>;
};

// Environmental Variable Validation Guardian Splash Screen
function StartupValidationWrapper({ children }: { children: React.ReactNode }) {
  const [dbChecking, setDbChecking] = useState(true);
  const [dbOnline, setDbOnline] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [sessionBypass, setSessionBypass] = useState(() => localStorage.getItem('riyada_env_bypass') === 'true');

  useEffect(() => {
    let active = true;
    const checkDbHealth = async () => {
      try {
        const health = await API.getHealth();
        if (active) {
          if (health.database === 'online') {
            setDbOnline(true);
          } else {
            setDbOnline(false);
            setDbError('قاعدة بيانات Aiven PostgreSQL غير متصلة أو لم يتم تهيئتها بعد.');
          }
        }
      } catch (err: any) {
        if (active) {
          setDbOnline(false);
          setDbError(err.message || 'فشل الاتصال بمركز صحة النظام.');
        }
      } finally {
        if (active) {
          setDbChecking(false);
        }
      }
    };

    checkDbHealth();
    return () => { active = false; };
  }, []);

  const envVal = API.validateEnvironment();
  const hasErrors = !envVal.isValid || !dbOnline;
  const errors = [...envVal.errors];
  if (!dbOnline && dbError) {
    errors.push(dbError);
  }

  if (dbChecking && !sessionBypass) {
    return (
      <div className="min-h-screen bg-[#05070a] flex flex-col items-center justify-center p-6 text-center font-sans">
        <div className="space-y-4">
          <div className="relative w-16 h-16 mx-auto">
            <div className="absolute inset-0 border-4 border-[#18C29C]/20 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-t-[#18C29C] rounded-full animate-spin"></div>
          </div>
          <div className="space-y-1.5">
            <h3 className="text-sm font-bold text-white">جاري اختبار اتصال قاعدة بيانات Aiven Cloud...</h3>
            <p className="text-xs text-white/50">نظام ريادة يتحقق من قنوات الربط السحابي</p>
          </div>
        </div>
      </div>
    );
  }

  if (hasErrors && !sessionBypass) {
    return (
      <div className="min-h-screen bg-[#05070a] flex items-center justify-center p-6 text-right font-sans">
        <div className="bg-[#0c121e] border border-amber-500/25 rounded-2xl p-8 max-w-lg w-full space-y-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl"></div>
          
          <div className="flex items-center gap-3 border-b border-white/5 pb-4 justify-end">
            <div>
              <h2 className="text-base font-bold text-white">البنية التحتية السحابية غير مكتملة (AIVEN_DB_OFFLINE)</h2>
              <span className="text-[10px] text-amber-400 font-mono">SYSTEM_ENFORCEMENT_WARNING</span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>

          <p className="text-xs text-white/70 leading-relaxed">
            يرجى تهيئة المتغيرات الأساسية المحددة في النظام للتحويل لقاعدة البيانات السحابية الحية <strong>Aiven PostgreSQL</strong> و <strong>Ably Pipeline</strong>. يمكنك متابعة الفحص في ملف الإعدادات <code>.env.example</code>.
          </p>

          <div className="bg-black/40 rounded-xl p-4 border border-white/5 space-y-2.5">
            <span className="text-[10px] text-white/40 block font-bold">المتغيرات والاتصال الشاغر حالياً:</span>
            {errors.map((err, i) => (
              <div key={i} className="flex gap-2 items-start justify-end text-xs text-white/80">
                <span className="leading-tight text-[11px] font-medium">{err}</span>
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-1.5 shrink-0"></span>
              </div>
            ))}
          </div>

          <div className="flex gap-2.5 pt-2">
            <button
              onClick={() => {
                setSessionBypass(true);
                localStorage.setItem('riyada_env_bypass', 'true');
              }}
              className="flex-1 py-3 rounded-xl bg-[#18C29C] hover:opacity-90 text-black text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-brand-500/10"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>الاستمرار بـ (وضع المحاكاة المحلية الآمنة)</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

// 13. SITE MAINTENANCE FALLBACK SCREEN
function MaintenanceScreen() {
  return (
    <div className="min-h-screen bg-[#05070a] flex items-center justify-center p-6 text-right font-sans">
      <div className="bg-[#0c121e] border border-cyan-500/15 rounded-2xl p-8 max-w-md w-full text-center space-y-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl"></div>
        
        <div className="w-16 h-16 rounded-full bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto">
          <Hammer className="w-8 h-8 animate-bounce" />
        </div>

        <div className="space-y-2">
          <h1 className="text-lg font-bold text-white">منصة ريادة في وضع الصيانة الاستباقية</h1>
          <p className="text-xs text-brand-400 font-bold uppercase tracking-widest font-mono">SITE_MAINTENANCE = TRUE</p>
          <p className="text-xs text-white/50 leading-relaxed">
            يخضع السوق حالياً لعملية هجرة دورية لبنى البيانات وقواعد الفهرسة في <strong>Aiven PostgreSQL</strong> لتأمين تداول تجاري فائق السرعة. سنعود للخدمة بأمان فور انتهاء عمليات الترحيل.
          </p>
        </div>

        <div className="text-[10px] text-white/30 border-t border-white/5 pt-4">
          ريادة © {new Date().getFullYear()} — بوابتك الحرة للاقتصاد الجزائري الموثق
        </div>
      </div>
    </div>
  );
}

export default function App() {
  if (SITE_MAINTENANCE) {
    return <MaintenanceScreen />;
  }

  return (
    <ErrorBoundary>
      <StartupValidationWrapper>
        <ToastProvider>
          <WorkspaceProvider>
            <BrowserRouter>
              <Routes>
                {/* Public Marketplace Feed Routes */}
                <Route path="/" element={<PublicLayout />}>
                  <Route index element={<Home />} />
                  <Route path="marketplace" element={<MarketplaceFeed />} />
                  <Route path="store/:storeId" element={<VendorProfile />} />
                  <Route path="product/:productId" element={<ProductDetail />} />
                  <Route path="saved" element={<Saved />} />
                  <Route path="about" element={<About />} />
                  <Route path="terms" element={<Terms />} />
                  <Route path="workers" element={<Workers />} />
                  <Route path="jobs" element={<Jobs />} />
                </Route>

                <Route path="/onboarding" element={<OnboardingRoute><Onboarding /></OnboardingRoute>} />
                
                {/* Central Seller Dashboard Routes */}
                <Route path="/dashboard" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
                  <Route index element={<Dashboard />} />
                  <Route path="products" element={<Products />} />
                  <Route path="whatsapp" element={<WhatsAppEngine />} />
                  <Route path="orders" element={<Orders />} />
                  <Route path="customers" element={<Customers />} />
                  <Route path="utilities" element={<Utilities />} />
                  <Route path="settings" element={<Settings />} />
                  <Route path="safety" element={<PaymentSafety />} />
                  <Route path="system-audit" element={<SystemAudit />} />
                  <Route path="monetization" element={<SellerMonetization />} />
                  <Route path="extensions" element={<ExtensionEcosystem />} />
                  <Route path="setup-wizard" element={<SetupWizard />} />
                </Route>
              </Routes>
            </BrowserRouter>
          </WorkspaceProvider>
        </ToastProvider>
      </StartupValidationWrapper>
    </ErrorBoundary>
  );
}
