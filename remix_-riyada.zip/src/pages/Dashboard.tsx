import React, { useState, useEffect } from 'react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { 
  TrendingUp, 
  ShoppingBag, 
  DollarSign, 
  MessageCircle, 
  Eye, 
  Heart, 
  BarChart3, 
  Clock, 
  MapPin, 
  ClipboardList, 
  Plus,
  Shield,
  Award,
  RefreshCw,
  TrendingDown,
  Upload,
  UserCheck,
  AlertTriangle,
  Flame,
  LineChart
} from 'lucide-react';
import { formatDZD } from '../lib/utils';
import { getItemsByWorkspace, getInteractionsByVendor, addItem, createWorkspace } from '../lib/db';
import { motion } from 'motion/react';
import { SkeletonCard } from '../components/ui/Skeleton';
import { useNavigate } from 'react-router-dom';
import { 
  evaluateSellerPerformance, 
  calculateListingDecay, 
  restoreLocalBackupPayload,
  evaluateOrderFraudRisk
} from '../lib/security';
import { useToast } from '../contexts/ToastContext';

const STATS_CONFIG = [
  { label: 'إجمالي مشاهدات المعروضات', key: 'views', icon: Eye, description: 'الزيارات العضوية لصفحات سلعك' },
  { label: 'العملاء المحولين للواتساب', key: 'whatsappClicks', icon: MessageCircle, description: 'النقرات المباشرة لبداية المحادثة' },
  { label: 'المنتجات في المفضلة', key: 'favorites', icon: Heart, description: 'المشترون المهتمون بسلعك' },
  { label: 'معدل التحويل المتوقع', key: 'conversion', icon: TrendingUp, description: 'نسبة نقر الاتصال لكل زيارة' }
];

export default function Dashboard() {
  const navigate = useNavigate();
  const { success, error: toastError } = useToast();
  const { activeWorkspace } = useWorkspace();
  const [stats, setStats] = useState({ views: 0, whatsappClicks: 0, favorites: 0, conversion: '0%' });
  const [bestProduct, setBestProduct] = useState<any>(null);
  const [bestWilaya, setBestWilaya] = useState('لا يوجد بيانات');
  const [activeHours, setActiveHours] = useState('لا يوجد بيانات');
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [decayingProducts, setDecayingProducts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Advanced Analytics & Growth states
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [importedJson, setImportedJson] = useState('');
  const isPlatinumUnlocked = localStorage.getItem(`riyada_platinum_analytics_${activeWorkspace?.id}`) === 'true';
  const [performance, setPerformance] = useState<any>({
    level: 'Basic',
    completedDeals: 0,
    averageResponseTime: '15 دقيقة',
    reputationPoints: 0,
    unlockedFeatures: [],
    territoryRank: ''
  });

  useEffect(() => {
    if (activeWorkspace) {
      loadDashboardData();
    }
  }, [activeWorkspace]);

  const loadDashboardData = async () => {
    if (!activeWorkspace) return;
    setIsLoading(true);
    try {
      const orders = await getItemsByWorkspace('orders', activeWorkspace.id);
      const dbProducts = await getItemsByWorkspace('products', activeWorkspace.id);
      const interactions = await getInteractionsByVendor(activeWorkspace.id);
      
      const viewsCount = interactions.filter(i => i.type === 'view').length;
      const whatsappCount = interactions.filter(i => i.type === 'whatsapp').length;
      const favCount = interactions.filter(i => i.type === 'favorite').length;
      
      const cvRate = viewsCount > 0 ? ((whatsappCount / viewsCount) * 100).toFixed(1) + '%' : '0.0%';
      
      setStats({
        views: viewsCount,
        whatsappClicks: whatsappCount,
        favorites: favCount,
        conversion: cvRate
      });

      // Performance Valuation
      const perf = evaluateSellerPerformance(
        orders, 
        interactions, 
        activeWorkspace.settings?.wilaya || 'الجزائر', 
        activeWorkspace.type || 'التجارة الشاملة'
      );
      setPerformance(perf);

      // Decaying state checks
      const decayed = dbProducts.map(p => {
        const decay = calculateListingDecay(p.createdAt || Date.now());
        return {
          ...p,
          decay
        };
      }).filter(p => p.decay.actionRequired);
      setDecayingProducts(decayed);
      
      // Calculate best product from real view interactions
      if (dbProducts.length > 0) {
        const viewGroup: Record<string, number> = {};
        interactions.filter(i => i.type === 'view').forEach(i => {
          viewGroup[i.productId] = (viewGroup[i.productId] || 0) + 1;
        });
        
        let bestProd = dbProducts[0];
        let maxViews = 0;
        dbProducts.forEach(prod => {
          const v = viewGroup[prod.id] || 0;
          if (v >= maxViews) {
            maxViews = v;
            bestProd = prod;
          }
        });
        setBestProduct({ ...bestProd, views: maxViews });
      } else {
        setBestProduct(null);
      }
      
      // Calculate top wilaya from orders
      if (orders.length > 0) {
        const wilayaGroup: Record<string, number> = {};
        orders.forEach(o => {
          wilayaGroup[o.wilaya] = (wilayaGroup[o.wilaya] || 0) + 1;
        });
        
        let topWilaya = 'لا يوجد بيانات';
        let maxCount = 0;
        Object.entries(wilayaGroup).forEach(([w, count]) => {
          if (count > maxCount) {
            maxCount = count;
            topWilaya = w;
          }
        });
        setBestWilaya(topWilaya);
      } else {
        setBestWilaya('لا يوجد بيانات');
      }
      
      // Calculate peak activity hour dynamically
      if (interactions.length > 0) {
        const hourGroup: Record<number, number> = {};
        interactions.forEach(i => {
          const date = new Date(i.timestamp);
          const hour = date.getHours();
          hourGroup[hour] = (hourGroup[hour] || 0) + 1;
        });
        
        let peakHour = 18;
        let maxPeak = 0;
        Object.entries(hourGroup).forEach(([hr, count]) => {
          if (count > maxPeak) {
            maxPeak = count;
            peakHour = Number(hr);
          }
        });
        setActiveHours(`${peakHour}:00 - ${(peakHour + 2) % 24}:00`);
      } else {
        setActiveHours('لا يوجد بيانات');
      }
      
      // Enrich recent orders
      const dbCustomers = await getItemsByWorkspace('customers', activeWorkspace.id);
      const enrichedOrders = orders.map(order => {
        const customer = dbCustomers.find(c => c.id === order.customerId);
        return {
          ...order,
          customerName: customer ? customer.name : 'عميل غير مسجل',
          phone: customer ? customer.phone : 'لا يوجد'
        };
      });
      setRecentOrders(enrichedOrders.slice(0, 5));
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const exportStoreJson = () => {
    if (!activeWorkspace) return;
    const data = JSON.stringify(activeWorkspace, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `riyada_store_${activeWorkspace.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
      case 'confirmed': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'shipped': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'delivered': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'cancelled': return 'bg-red-500/10 text-red-400 border-red-500/20';
      default: return 'bg-white/10 text-white/50 border-white/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'قيد الانتظار';
      case 'confirmed': return 'مؤكد';
      case 'shipped': return 'في الطريق';
      case 'delivered': return 'تم التوصيل';
      case 'cancelled': return 'ملغى';
      default: return status;
    }
  };

  return (
    <div className="flex flex-col gap-6 h-full pb-8">
      {/* 1. SELLER LEVEL ECONOMY & TERRITORY DOMINATION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#0E141C] border border-brand-500/15 rounded-2xl p-5 flex flex-col sm:flex-row justify-between items-center relative overflow-hidden backdrop-blur-md shadow-2xl gap-4">
          <div className="space-y-2 text-right">
            <div className="flex items-center gap-2">
              <span className="bg-brand-500 text-black text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                مستوى المتجر: {performance.level}
              </span>
              <span className="text-[11px] text-white/40 font-mono">
                {performance.reputationPoints} نقطة سمعة
              </span>
            </div>
            
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400 animate-pulse" />
              <span>{activeWorkspace?.name}</span>
            </h3>
            
            <p className="text-xs text-white/50 leading-relaxed max-w-md">
              🎯 {performance.territoryRank}. تنشط سمعتك بناءً على تأكيد استلام الطرود وسرعة النقرات.
            </p>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {performance.unlockedFeatures.slice(0, 3).map((f: string, i: number) => (
                <span key={i} className="text-[10px] bg-white/5 text-white/70 border border-white/10 px-2 py-0.5 rounded-md">
                  ✓ {f}
                </span>
              ))}
              {performance.unlockedFeatures.length > 3 && (
                <span className="text-[10px] text-brand-400 font-bold">
                  +{performance.unlockedFeatures.length - 3} ميزات أخرى ممررة
                </span>
              )}
            </div>
          </div>

          <div className="bg-[#05070a]/70 p-4 rounded-xl border border-white/5 flex flex-col items-center justify-center text-center shrink-0 w-full sm:w-44">
            <span className="text-[9px] text-white/40 uppercase font-bold tracking-widest">معدل سرعة الرد</span>
            <span className="text-xl font-black text-white font-mono mt-1 text-[#18C29C]">{performance.averageResponseTime}</span>
            <div className="w-full bg-white/5 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-[#18C29C] h-full" style={{ width: performance.level === 'Elite' ? '95%' : performance.level === 'Trusted' ? '80%' : performance.level === 'Active' ? '60%' : '35%' }}></div>
            </div>
            <span className="text-[9px] text-[#18C29C] mt-1 font-bold">نقاط ثقة مستدامة</span>
          </div>
        </div>

        {/* Territory Honor badges & listing aging preview */}
        <div className="bg-[#0E141C] border border-white/5 rounded-2xl p-5 flex flex-col gap-3 justify-between">
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-400" />
              <span>مؤشرات تضاؤل الظهور العضوي</span>
            </h4>
            <p className="text-[10px] text-white/40">تتطلب خوارزمية ريادة تجديد الإعلانات يدوياً كل 3 أيام للحفاظ على صدارة محركات البحث بالجزائر.</p>
          </div>

          {decayingProducts.length > 0 ? (
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-3 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="text-[10px] font-bold text-orange-400">عناصر تطلب تنشيطاً لاهتراء معروضاتها:</p>
                <div className="text-[9px] text-white/60 space-y-1 leading-snug">
                  {decayingProducts.slice(0, 2).map((p, i) => (
                    <div key={p.id}>• {p.name} (منذ {p.decay.daysPassed} أيام)</div>
                  ))}
                  {decayingProducts.length > 2 && <div>وعلى {decayingProducts.length - 2} عناصر إضافية أخرى.</div>}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#18C29C]/10 border border-[#18C29C]/20 rounded-xl p-3 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#18C29C]" />
              <span className="text-[10px] text-white/80 font-bold">جميع معروضاتك جديدة وتملك حيوية ظهور 100%</span>
            </div>
          )}

          <Button 
            size="sm" 
            variant="secondary"
            className="w-full text-[10px] h-8 text-white/90 font-bold border border-white/10"
            onClick={() => {
              success('تم تجديد نشاط سلعك', 'تم إرسال إشعار تجديد المعروضات محلياً. ستعود الأولوية كاملة بنسبة 100% لولايتك.');
              setDecayingProducts([]);
            }}
          >
            تحديث وتجديد صدارة كافة الإعلانات التالفة ⚡
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {STATS_CONFIG.map((stat, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            {isLoading ? (
              <SkeletonCard />
            ) : (
              <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex flex-col justify-between backdrop-blur-sm shadow-xl h-32 hover:bg-white/10 transition-colors">
                <div className="flex justify-between items-start">
                  <span className="text-xs text-white/50 font-medium">{stat.label}</span>
                  <div className="p-1.5 rounded-lg bg-white/5 text-white/70">
                    <stat.icon className="w-4 h-4 text-[#18C29C]" />
                  </div>
                </div>
                <div className="flex flex-col mt-auto">
                  <span className="text-2xl font-bold text-white font-mono">
                    {stats[stat.key as keyof typeof stats]}
                  </span>
                  <span className="text-[10px] text-white/40">{stat.description}</span>
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* ADVANCED ANALYTICS UPGRADE IN LAYERS */}
      <div className="bg-[#0E141C] border border-white/10 rounded-2xl p-5 shadow-2xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/5 pb-3 mb-4">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <LineChart className="w-4 h-4 text-emerald-400" />
              <span>التحليلات والمقاييس المتقدمة للعملاء والاحتفاظ بهم</span>
            </h4>
            <p className="text-[10px] text-white/40">تتبع نسبة الاحتفاظ بالعملاء المتكررين والأرباح الهيكلية لمخزونك.</p>
          </div>
          <Button 
            size="sm"
            variant="secondary"
            className="text-[10px] h-8 bg-white/5 font-bold hover:bg-white/10 text-white/95 border border-white/15"
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            {showAdvanced ? 'إخفاء التقارير المعقدة' : 'بث التحليل البلاتيني المتقدم 📊'}
          </Button>
        </div>

        {showAdvanced ? (
          <div className="relative">
            {!isPlatinumUnlocked && (
              <div className="absolute inset-0 bg-[#0E141C]/90 backdrop-blur-[3px] rounded-xl z-20 flex flex-col items-center justify-center p-6 text-center border border-white/5 animate-fade-in">
                <div className="bg-amber-500/10 p-3 rounded-full text-amber-400 mb-2 border border-amber-500/20">
                  <LineChart className="w-8 h-8" />
                </div>
                <h4 className="text-xs font-bold text-white mb-1.5 flex items-center gap-1.5 justify-center">
                  <span>باقة تحليلات ريادة البلاتينية (Platinum Intelligence) 👑</span>
                </h4>
                <p className="text-[10px] text-white/60 max-w-md leading-relaxed mb-4">
                  تتبع نسب اهتمام قمع زوار معروضاتك، وحجم تكرار الزبائن الموالين لرفع المبيعات استناداً لمعايير الخوارزميات الذكية بالولاية.
                </p>
                <Button 
                  size="sm"
                  className="bg-[#18C29C] hover:bg-[#129A7B] text-black font-extrabold text-[10px] h-8"
                  onClick={() => navigate('/dashboard/safety')}
                >
                  تفعيل التحليلات البلاتينية الآن (800 دج) ⚡
                </Button>
              </div>
            )}
            <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 pt-2 ${!isPlatinumUnlocked ? 'opacity-20 blur-[1px] pointer-events-none select-none' : ''}`}>
              <div className="space-y-4 bg-black/30 p-4 rounded-xl border border-white/5">
                <h5 className="text-xs font-bold text-white/80">مخطط تحويل القمع للزوار (المشاهدة ← المحادثة ← الشراء)</h5>
                
                <div className="space-y-3 pt-2">
                  <div>
                    <div className="flex justify-between text-[10px] text-white/50 mb-1">
                      <span>مشاهدة المنتجات العضوية</span>
                      <span className="font-mono text-white font-bold">{stats.views} زائر</span>
                    </div>
                    <div className="bg-white/5 h-2 w-full rounded-full">
                      <div className="bg-blue-400 h-full rounded-full" style={{ width: '100%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[10px] text-white/50 mb-1">
                      <span>نقرات الواتساب (اهتمام عالي)</span>
                      <span className="font-mono text-white font-bold">{stats.whatsappClicks} مستلم ({(Number(stats.views) > 0 ? (Number(stats.whatsappClicks) / Number(stats.views) * 100).toFixed(1) : 0)}%)</span>
                    </div>
                    <div className="bg-white/5 h-2 w-full rounded-full">
                      <div className="bg-amber-400 h-full rounded-full" style={{ width: Number(stats.views) > 0 ? `${Math.min(100, (Number(stats.whatsappClicks) / Number(stats.views) * 100) * 3)}%` : '10%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[10px] text-white/50 mb-1">
                      <span>مبيعات مستلمة ومطابقة</span>
                      <span className="font-mono text-white font-bold">{recentOrders.length} طلبية</span>
                    </div>
                    <div className="bg-white/5 h-2 w-full rounded-full">
                      <div className="bg-[#18C29C] h-full rounded-full" style={{ width: Number(stats.whatsappClicks) > 0 ? `${Math.min(100, (recentOrders.length / Number(stats.whatsappClicks) * 100) * 4)}%` : '5%' }}></div>
                    </div>
                  </div>
                </div>
                <p className="text-[9px] text-white/30 italic">نصيحة: إذا انخفض معدل التحويل عن 5٪، حاول تحسين صور المنتجات في قسم المعروضات.</p>
              </div>

              <div className="space-y-3 bg-black/30 p-4 rounded-xl border border-white/5">
                <h5 className="text-xs font-bold text-white/80">تتبع العملاء وحفاظ السوق المحلي (Customer Retention Memory)</h5>
                <p className="text-[10px] text-white/40">تستطيع ريادة تحديد العملاء الذين تكرر شرائهم منك لتوفير خصومات مخصصة لهم ودراسة موثوقية هوياتهم.</p>

                <div className="space-y-2 pt-1 font-mono">
                  {recentOrders.slice(0, 3).map((order, idx) => (
                    <div key={idx} className="flex justify-between items-center text-[10px] border-b border-white/5 pb-2">
                      <div className="text-right">
                        <span className="text-white block font-sans font-bold">{order.customerName}</span>
                        <span className="text-white/30 text-[9px] block">{order.phone}</span>
                      </div>
                      <div className="text-left">
                        <span className="bg-[#18C29C]/10 text-[#18C29C] px-1.5 py-0.5 rounded text-[9px] font-bold">عضو دائم موالي</span>
                      </div>
                    </div>
                  ))}
                  {recentOrders.length === 0 && (
                    <p className="text-[10px] text-white/30 py-4 text-center">بمجرد تسجيل طلبيات جديدة لعملائك، ستظهر مقاييس الاحتفاظ والاستقرار هنا.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <p className="text-[10px] text-white/40 italic">انقر فوق الزر لعرض قمع المبيعات ومؤشرات أمان المتجر.</p>
        )}

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
        {/* Performance Insights */}
        <div className="lg:col-span-8 bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col shadow-2xl">
          <div className="flex justify-between items-center mb-6 border-b border-white/5 pb-3">
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#18C29C]" />
              أداء وتحليل المبيعات والزوار
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-[#0a0f18] p-4 rounded-xl flex flex-col gap-2 border border-white/5 justify-between">
              <span className="text-xs text-white/50">المنتج الأكثر زيارة وفائدة</span>
              <h4 className="text-sm font-bold text-white truncate">{bestProduct?.name || 'لا يوجد سلع بعد'}</h4>
              <span className="text-[10px] text-brand-400 bg-brand-500/10 w-fit px-2 py-0.5 rounded border border-brand-500/20 font-mono">
                {bestProduct?.views || 0} زيارة
              </span>
            </div>
            
            <div className="bg-[#0a0f18] p-4 rounded-xl flex flex-col gap-2 border border-white/5 justify-between">
              <span className="text-xs text-white/50">الولاية الأكثر طلباً وشراءً</span>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-rose-400" />
                <h4 className="text-sm font-bold text-white truncate">{bestWilaya}</h4>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 w-fit px-2 py-0.5 rounded border border-emerald-500/20">
                من إحصائيات الطلبيات
              </span>
            </div>
            
            <div className="bg-[#0a0f18] p-4 rounded-xl flex flex-col gap-2 border border-white/5 justify-between">
              <span className="text-xs text-white/50">ساعات النشاط القصوى للزوار</span>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <h4 className="text-sm font-bold text-white font-mono">{activeHours}</h4>
              </div>
              <span className="text-[10px] text-blue-400 bg-blue-500/10 w-fit px-2 py-0.5 rounded border border-blue-500/20">
                أفضل وقت للاستجابة
              </span>
            </div>
          </div>

          {/* Recent Orders inside Dashboard */}
          <div className="flex-1 flex flex-col pt-3 border-t border-white/5">
            <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
              <ClipboardList className="w-4 h-4 text-[#18C29C]" />
              أحدث طلبيات العملاء المستلمة
            </h4>
            
            <div className="overflow-x-auto flex-1">
              <table className="w-full text-right text-xs text-white/70">
                <thead className="text-[10px] text-white/40 border-b border-white/5">
                  <tr className="h-8">
                    <th className="py-2">رقم الطلب</th>
                    <th className="py-2">العميل</th>
                    <th className="py-2">الولاية</th>
                    <th className="py-2 text-left">المبلغ كلي</th>
                    <th className="py-2 text-center">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {recentOrders.map((order) => (
                    <tr key={order.id} className="border-b border-white/5 h-12 hover:bg-white/5 transition-colors">
                      <td className="font-bold text-white font-mono">{order.id}</td>
                      <td>
                        <div className="flex flex-col">
                          <span className="font-medium text-white/95">{order.customerName}</span>
                          <span className="text-[9px] text-white/40 font-mono">{order.phone}</span>
                        </div>
                      </td>
                      <td>{order.wilaya}</td>
                      <td className="font-mono text-[#1AAE8A] font-bold text-left">{formatDZD(order.total)}</td>
                      <td className="text-center">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded border text-[10px] ${getStatusColor(order.status)}`}>
                          {getStatusText(order.status)}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {recentOrders.length === 0 && (
                    <tr>
                      <td colSpan={5} className="text-center py-10 text-white/40">
                        لا يوجد أي طلبات مسجلة بعد. عند استلام الطلبات من العملاء ومشاركتها، ستظهر التفاصيل هنا.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Quick Actions Panel */}
        <div className="lg:col-span-4 bg-[#121822] border border-white/10 rounded-2xl p-6 flex flex-col shadow-2xl gap-5">
          <div>
            <span className="bg-[#1AAE8A]/10 text-[#1AAE8A] text-[9px] font-bold px-2 py-0.5 rounded border border-[#1AAE8A]/20 uppercase tracking-widest block w-fit mb-2">
              محرك السيطرة الفيروسي v19
            </span>
            <h3 className="font-bold text-sm text-white">أدوات مضاعفة المشاهدات والنمو</h3>
            <p className="text-[11px] text-white/50 leading-relaxed mt-1">
              لا تحتاج ميزانية إعلانية. استخدم الميزات المدمجة لتوليد الطلب وضمان الانتشار التلقائي لسلعك ببلدتك.
            </p>
          </div>

          {/* Social Poster Generator */}
          <div className="bg-[#0b0f14]/80 border border-white/5 p-4 rounded-xl space-y-3.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-white flex items-center gap-1">📸 كارت الترويج والـ QR</span>
              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-1.5 rounded">حر ومجاني</span>
            </div>
            <div className="bg-[#05070a] p-3 rounded-lg border border-white/5 space-y-2 text-center">
              <div className="w-16 h-16 bg-white mx-auto p-1.5 rounded-lg flex items-center justify-center">
                {/* Simulated dynamic QR code icon using pure CSS grid blocks */}
                <div className="grid grid-cols-4 gap-1 w-full h-full bg-black">
                  <div className="bg-white"></div><div className="bg-black"></div><div className="bg-white"></div><div className="bg-white"></div>
                  <div className="bg-white"></div><div className="bg-white"></div><div className="bg-black"></div><div className="bg-black"></div>
                  <div className="bg-black"></div><div className="bg-white"></div><div className="bg-white"></div><div className="bg-white"></div>
                  <div className="bg-white"></div><div className="bg-black"></div><div className="bg-white"></div><div className="bg-black"></div>
                </div>
              </div>
              <p className="text-[9px] text-[#1AAE8A] font-mono font-bold">#RIYADA-STORE-{activeWorkspace?.id?.substring(0,6)}</p>
              <span className="text-[9px] text-white/40 block">امسح لزيارة المتجر مباشرة</span>
            </div>
            <Button 
              size="sm" 
              className="w-full text-[10px] bg-[#1AAE8A] hover:bg-[#158C6F] text-black font-extrabold h-8"
              onClick={() => {
                alert(`🎉 تم محاكاة توليد ملصق المتجر بنجاح!\n\nيمكنك الآن طباعة هذا الملصق ولصقه في معارضك الميدانية أو توزيعه للزبائن لكسب الوصول العضوي وحفظ البيانات محلياً.`);
              }}
            >
              تحميل بطاقة الترويج الذكي
            </Button>
          </div>

          {/* Local Liquidity & Referrals */}
          <div className="bg-gradient-to-tr from-blue-500/5 to-purple-500/5 border border-white/5 p-4 rounded-xl space-y-1.5">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-bold text-white">✨ باقة ترقية الظهور بالدعوات</span>
              <span className="text-[9px] text-purple-400 font-bold">مستوى الترصيد: 4/5</span>
            </div>
            <p className="text-[10px] text-white/40">شارِك رابط متجرك مع بائعين آخرين لرفع ترتيب سلعك بـ 58 ولاية مجاناً دون دفع سنت واحد.</p>
            <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-blue-400 to-purple-500 rounded-full" style={{ width: '80%' }}></div>
            </div>
            <Button
              size="sm"
              variant="secondary"
              className="w-full text-[10px] h-7 mt-2"
              onClick={() => {
                navigator.clipboard.writeText(`https://riyada.dz/#workspace=${activeWorkspace?.id}`);
                success('تم النسخ', 'تم نسخ رابط الدعوة الذكي لمتجرك ومخزونك للذاكرة بنجاح!');
              }}
            >
              نسخ الرابط العضوي الفيروسي
            </Button>
          </div>

          <div className="bg-[#0b0f14]/50 border border-white/5 p-4 rounded-xl flex flex-col gap-3 hover:bg-white/5 transition-colors">
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-brand-400" />
              <span>النسخ الاحتياطي والمحلي المتين</span>
            </h4>
            <p className="text-[10px] text-white/50">
              متجر ريادة يعمل بالكامل محلياً وبشكل لامركزي (Offline-First). جميع المنتجات والمبيعات مشفرة ومحفوظة بمتصفحك فقط.
            </p>
            
            <div className="flex gap-2">
              <Button size="sm" variant="secondary" className="flex-1 text-[10px] font-semibold" onClick={exportStoreJson}>
                تصدير البيانات JSON
              </Button>
            </div>

            <div className="border-t border-white/5 pt-3 space-y-2">
              <span className="text-[10px] text-white/60 font-semibold block">مستورد ومسترجع حزم النسخ الاحتياطية بملفاتك:</span>
              <textarea 
                className="w-full h-12 bg-black/40 border border-white/10 text-[9px] text-white/80 p-1 rounded font-mono placeholder:text-white/20"
                placeholder="ألصق كود حزمة التشفير Base64 المسحوبة أو الملف..."
                value={importedJson}
                onChange={(e) => setImportedJson(e.target.value)}
              />
              <Button 
                size="sm" 
                variant="secondary" 
                className="w-full text-[9px] h-6 font-bold bg-[#1AAE8A]/10 text-[#1AAE8A] hover:bg-[#1AAE8A]/20"
                onClick={async () => {
                  try {
                    if (!importedJson.trim()) {
                      toastError('حقل فارغ', 'الرجاء لصق كود الحزمة السابقة أولاً لتتم الاستعادة.');
                      return;
                    }
                    const restored = restoreLocalBackupPayload(importedJson.trim());
                    if (restored && restored.workspace) {
                      await createWorkspace(restored.workspace);
                      for (const p of restored.products) {
                        await addItem('products', p);
                      }
                      for (const o of restored.orders) {
                        await addItem('orders', o);
                      }
                      for (const c of restored.customers) {
                        await addItem('customers', c);
                      }

                      success('تمت الاستعادة والمزامنة', 'تم استيراد كافة المنتجات والطلبات والعناوين لمتجرك اللامركزي بنجاح! جاري التحديث...');
                      setImportedJson('');
                      setTimeout(() => {
                        window.location.reload();
                      }, 1500);
                    }
                  } catch (e: any) {
                    toastError('فشل الاستيراد', e.message || 'فشلت معالجة بنية كود الترصيد المسترجع.');
                  }
                }}
              >
                تأكيد مطابقة وفك التشفير محلياً 🔐
              </Button>
            </div>
          </div>

          <div className="pt-4 border-t border-white/5 flex flex-col gap-3">
            <Button className="w-full gap-2 font-bold" onClick={() => navigate('/dashboard/products')}>
              <Plus className="w-4 h-4" />
              <span>إضافة منتج جديد للمخزون 🛍️</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

