import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { ALGERIAN_WILAYAS, getAllItems } from '../lib/db';
import { getWorkers, getJobs } from '../lib/economy';
import { 
  ShoppingBag, 
  Wrench, 
  Briefcase, 
  Users, 
  ArrowLeft,
  ShieldCheck,
  Check,
  Globe,
  Lock,
  ArrowRight,
  TrendingUp,
  MapPin
} from 'lucide-react';
import { motion } from 'motion/react';

export default function Home() {
  const navigate = useNavigate();
  const [selectedWilaya, setSelectedWilaya] = useState('الكل');
  const [stats, setStats] = useState({
    storesCount: 0,
    listingsCount: 0,
    servicesCount: 0,
    jobsCount: 0
  });

  useEffect(() => {
    async function loadRealStats() {
      try {
        const pkList = await getAllItems('products');
        const wkList = await getAllItems('workspaces');
        const workers = getWorkers();
        const jobs = getJobs();

        // Count as service if category is 'خدمات'
        const services = pkList.filter((p: any) => p.category === 'خدمات').length;
        const products = pkList.filter((p: any) => p.category !== 'خدمات').length;

        setStats({
          storesCount: wkList.length || 0,
          listingsCount: products || 0,
          servicesCount: services || 0,
          jobsCount: jobs.length || 0
        });
      } catch (e) {
        console.error('Error fetching statistics for Home:', e);
      }
    }
    loadRealStats();
  }, []);

  const handleExplore = () => {
    const query = selectedWilaya !== 'الكل' ? `?wilaya=${encodeURIComponent(selectedWilaya)}` : '';
    navigate(`/marketplace${query}`);
  };

  const intentCards = [
    {
      title: 'سوق السلع والمخزون',
      desc: 'تصفح واقتنِ السلع المنزلية والمعدات الحرة.',
      icon: <ShoppingBag className="w-5 h-5 text-[#18C29C]" />,
      path: '/marketplace',
      themeColor: 'hover:border-[#18C29C]/30'
    },
    {
      title: 'عروض الحرف والخدمات',
      desc: 'مستقلون وتقنيون لأجل الصيانة والتعليم والخدمات الرقمية.',
      icon: <Wrench className="w-5 h-5 text-blue-400" />,
      path: '/marketplace?category=خدمات',
      themeColor: 'hover:border-blue-400/30'
    },
    {
      title: 'سوق المقاولات والوظائف',
      desc: 'أعلن عن فرصة عمل شاغرة أو تقدّم للتوظيف المباشر.',
      icon: <Briefcase className="w-5 h-5 text-emerald-400" />,
      path: '/jobs',
      themeColor: 'hover:border-emerald-400/30'
    },
    {
      title: 'شبكة العمال والحرفيين',
      desc: 'تواصل مباشرة مع العمال والمهنيين بضمان الموثوقية.',
      icon: <Users className="w-5 h-5 text-amber-400" />,
      path: '/workers',
      themeColor: 'hover:border-amber-400/30'
    }
  ];

  return (
    <div className="py-12 md:py-24 max-w-4xl mx-auto space-y-16 px-4">
      {/* 1. HERO SECTION (ONLY FOCUS AREA) */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center space-y-6"
      >
        <span className="bg-[#1AAE8A]/10 text-[#1AAE8A] text-[10px] md:text-xs px-4 py-1.5 rounded-full font-bold border border-[#1AAE8A]/20 tracking-wider">
          🇩🇿 ريادة — نظام التشغيل الاقتصادي الجزائري المستقل
        </span>

        <h1 className="text-3xl md:text-6xl font-black text-white tracking-tight leading-tight">
          RIYADA — السوق الرقمي الجزائري
        </h1>
        
        <p className="text-base md:text-xl font-bold bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
          اشترِ، بِع، اعمل، وظّف… كل شيء في مكان واحد
        </p>

        <p className="text-white/50 text-xs md:text-sm max-w-xl mx-auto leading-relaxed">
          منصة تجمع المنتجات، الخدمات، الوظائف، والعمال داخل نظام رقمي بسيط وسريع. بدون حواجز، بدون رسوم اشتراك، وبتحكّم محلي آمن وعام.
        </p>

        {/* PRIMARY CTA BUTTONS */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
          <Button 
            onClick={handleExplore}
            className="w-full sm:w-auto bg-[#1AAE8A] hover:bg-[#158C6F] text-[#05070a] font-black text-xs px-8 h-12 rounded-xl shadow-[0_0_20px_rgba(26,174,138,0.15)] flex items-center justify-center gap-2 transition-all duration-300 transform hover:scale-[1.02]"
          >
            <span>استكشف السوق الشامل</span>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <Button 
            onClick={() => navigate('/onboarding')}
            variant="secondary"
            className="w-full sm:w-auto border border-white/10 hover:bg-white/5 text-white/90 font-bold text-xs px-8 h-12 rounded-xl flex items-center justify-center gap-2"
          >
            📊 ابدأ متجرك الآن مجاناً
          </Button>
        </div>
      </motion.div>

      {/* 2. TRUST MICRO STRIP (VERY SMALL) */}
      <div className="border border-white/5 bg-[#0E141C]/40 rounded-2xl py-3 px-4 md:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="flex items-center justify-center gap-1.5 text-white/60 text-[11px] font-medium">
            <Check className="w-3.5 h-3.5 text-[#18C29C]" />
            <span>منتجات حقيقية مفعّلة</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-white/60 text-[11px] font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>تصنيف مبني على الثقة</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-white/60 text-[11px] font-medium">
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>اقتصاد محلي لامركزي</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-white/60 text-[11px] font-medium">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>خصوصية تامة وحفظ محلي</span>
          </div>
        </div>
      </div>

      {/* 3. WILAYA SELECTOR */}
      <div className="max-w-md mx-auto bg-[#0E141C] border border-white/5 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-right">
          <MapPin className="w-4 h-4 text-[#1AAE8A] shrink-0" />
          <span className="text-xs text-white/60 font-semibold">تخصيص الولايات للبحث والمطابقة:</span>
        </div>
        <select 
          value={selectedWilaya}
          onChange={(e) => setSelectedWilaya(e.target.value)}
          className="bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-semibold outline-none focus:border-[#1AAE8A] cursor-pointer"
        >
          <option value="الكل">🇩🇿 كل ولايات الجزائر (58)</option>
          {ALGERIAN_WILAYAS.map(w => (
            <option key={w.id} value={w.name}>{w.name}</option>
          ))}
        </select>
      </div>

      {/* 4. QUICK INTENT SELECTOR (4 Entry Cards Only) */}
      <div className="space-y-4">
        <div className="text-center">
          <h2 className="text-xs font-black text-[#1AAE8A] tracking-wider uppercase">بوابات التبادل التجاري والخدماتي</h2>
          <p className="text-white/40 text-[11px]">انقر لتحديد قطاعك وبدء المعاملات</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {intentCards.map((card, index) => (
            <Card 
              key={index}
              onClick={() => {
                const query = selectedWilaya !== 'الكل' ? `&wilaya=${encodeURIComponent(selectedWilaya)}` : '';
                if (card.path.includes('?')) {
                  navigate(`${card.path}${query}`);
                } else {
                  const q = selectedWilaya !== 'الكل' ? `?wilaya=${encodeURIComponent(selectedWilaya)}` : '';
                  navigate(`${card.path}${q}`);
                }
              }}
              className={`p-5 bg-[#0E141C] border border-white/5 ${card.themeColor} cursor-pointer transition-all duration-300 group rounded-2xl flex items-start gap-4`}
            >
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                {card.icon}
              </div>
              <div className="space-y-1 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs md:text-sm text-white group-hover:text-[#1AAE8A] transition-colors">
                    {card.title}
                  </h3>
                  <ArrowLeft className="w-3.5 h-3.5 text-white/20 transform group-hover:-translate-x-1 transition-transform" />
                </div>
                <p className="text-white/40 text-[11px] leading-relaxed">
                  {card.desc}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* 5. HOW IT WORKS (ULTRA SHORT - DISPLAYING ONLY 3 STEPS) */}
      <div className="space-y-6 pt-4">
        <h3 className="text-center text-xs font-black text-white/50 tracking-wider">كيف تتم المعاملات في ريادة في 3 خطوات سريعة؟</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          <div className="bg-[#0E141C]/30 border border-white/5 p-5 rounded-2xl space-y-2 text-center relative z-10">
            <span className="text-xl inline-block bg-white/5 px-3 py-1 rounded-full font-mono text-[#18C29C] font-bold">01</span>
            <h4 className="text-xs font-bold text-white">أنشئ إعلانك</h4>
            <p className="text-[10px] text-white/40 leading-relaxed">أضف منتجاتك أو خدماتك أو تخصصك المهني في 30 ثانية بدون رسوم ولا تعقيد حسابات.</p>
          </div>

          <div className="bg-[#0E141C]/30 border border-white/5 p-5 rounded-2xl space-y-2 text-center relative z-10">
            <span className="text-xl inline-block bg-white/5 px-3 py-1 rounded-full font-mono text-[#18C29C] font-bold">02</span>
            <h4 className="text-xs font-bold text-white">استقبل العروض</h4>
            <p className="text-[10px] text-white/40 leading-relaxed">يتواصل معك الزبائن أو أصحاب العمل مباشرة عبر نظام المفاوضة والاتفاق الداخلي المريح.</p>
          </div>

          <div className="bg-[#0E141C]/30 border border-white/5 p-5 rounded-2xl space-y-2 text-center relative z-10">
            <span className="text-xl inline-block bg-white/5 px-3 py-1 rounded-full font-mono text-[#18C29C] font-bold">03</span>
            <h4 className="text-xs font-bold text-white">أتمّ الصفقة</h4>
            <p className="text-[10px] text-white/40 leading-relaxed">تأكيد ومطابقة الدفع والاستلام يدوياً وبصورة آمنة وموفرة للغاية دون اقتطاع عمولات.</p>
          </div>
        </div>
      </div>

      {/* 6. MINIMAL REAL DATA STATS (NO FAKE DATA) */}
      {(stats.storesCount > 0 || stats.listingsCount > 0 || stats.servicesCount > 0 || stats.jobsCount > 0) && (
        <div className="pt-4 border-t border-white/5">
          <div className="bg-[#0E141C]/30 p-4 rounded-xl border border-white/5 max-w-2xl mx-auto flex flex-wrap justify-around items-center gap-4">
            <div className="text-center py-2 px-4">
              <span className="block text-xl font-bold text-white font-mono">{stats.storesCount}</span>
              <span className="text-[10px] text-white/40">متاجر مفعلة</span>
            </div>
            <div className="w-[1px] h-8 bg-white/10 hidden sm:block"></div>
            <div className="text-center py-2 px-4">
              <span className="block text-xl font-bold text-white font-mono">{stats.listingsCount}</span>
              <span className="text-[10px] text-white/40">سلع معروضة</span>
            </div>
            <div className="w-[1px] h-8 bg-white/10 hidden sm:block"></div>
            <div className="text-center py-2 px-4">
              <span className="block text-xl font-bold text-[#18C29C] font-mono">{stats.servicesCount}</span>
              <span className="text-[10px] text-white/40">خدمات حرة</span>
            </div>
            <div className="w-[1px] h-8 bg-white/10 hidden sm:block"></div>
            <div className="text-center py-2 px-4">
              <span className="block text-xl font-bold text-amber-400 font-mono">{stats.jobsCount}</span>
              <span className="text-[10px] text-white/40">فرصة عمل متاحة</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
