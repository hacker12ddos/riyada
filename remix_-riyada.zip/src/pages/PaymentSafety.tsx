import React, { useState, useEffect } from 'react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { useToast } from '../contexts/ToastContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  CreditCard, 
  Settings, 
  FileCheck, 
  AlertTriangle, 
  Coins, 
  Sparkles, 
  ExternalLink, 
  Eye, 
  Lock, 
  CheckCircle, 
  Upload, 
  RefreshCw, 
  ArrowLeft, 
  X,
  FileText,
  BadgeAlert,
  Flame,
  Award
} from 'lucide-react';
import { getItemsByWorkspace, addItem, Product } from '../lib/db';
import { formatDZD } from '../lib/utils';

interface BoostPlan {
  id: string;
  name: string;
  price: number;
  durationDays: number;
  description: string;
  type: 'wilaya_spotlight' | 'category_dominance' | 'premium_badge' | 'platinum_analytics';
}

const PLANS: BoostPlan[] = [
  {
    id: 'wilaya_spot',
    name: '🎯 تسليط الضوء على الولاية (Wilaya Spotlight)',
    price: 500,
    durationDays: 7,
    description: 'يتم رفع منتجاتك في البحث العضوي لولايتك المختارة ليتصدر الصفحة الأولى لجميع الباحثين القريبين منك مجاناً.',
    type: 'wilaya_spotlight'
  },
  {
    id: 'cat_dom',
    name: '👑 السيادة الذهبية للفئات (Category Dominance)',
    price: 1200,
    durationDays: 14,
    description: 'تأمين المركز الأول الثابت في تصنيف منتجاتك لضمان تدفق عالي لزيارات عملاء الشراء الجادين.',
    type: 'category_dominance'
  },
  {
    id: 'gold_badge',
    name: '✨ شارة التوثيق المعززة للمتجر (VIP Gold Identity)',
    price: 1000,
    durationDays: 30,
    description: 'تغيير شكل متجرك وعرض شارة "بائع مرخص رسمي" مذهبة في الفيد العام لتعزيز ثقة المشترين بـ 250%.',
    type: 'premium_badge'
  },
  {
    id: 'analytics_up',
    name: '📊 التحليلات البلاتينية المعمقة (Platinum Analytics)',
    price: 800,
    durationDays: 30,
    description: 'فتح تتبع مخطط تحويل زوار القمع، تفاصيل العملاء الموالين المتكررين، وتحليل مؤشرات السلامة بالكامل.',
    type: 'platinum_analytics'
  }
];

interface PlatformTransaction {
  id: string;
  planId: string;
  planName: string;
  amount: number;
  paymentMethod: 'chargily' | 'baridimob_manual';
  status: 'initiated' | 'awaiting_payment' | 'payment_submitted' | 'under_review' | 'approved' | 'rejected' | 'expired';
  txId?: string;
  proofFile?: string;
  timestamp: number;
  unlockedProductId?: string;
}

export default function PaymentSafety() {
  const { activeWorkspace } = useWorkspace();
  const { success, error: toastError } = useToast();
  const [activeTab, setActiveTab] = useState<'safety' | 'monetization'>('safety');
  
  // Products list for selecting product to boost
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  
  // Selected plan for upgrading
  const [selectedPlan, setSelectedPlan] = useState<BoostPlan | null>(null);
  const [paymentStep, setPaymentStep] = useState<'plan_selection' | 'method_selection' | 'process_payment' | 'review'>('plan_selection');
  const [paymentMethod, setPaymentMethod] = useState<'chargily' | 'baridimob_manual'>('chargily');
  
  // Manual submission fields
  const [txId, setTxId] = useState('');
  const [proofFile, setProofFile] = useState('');
  const [senderName, setSenderName] = useState('');
  
  // Simulation and animation triggers
  const [isSimulatingRedirect, setIsSimulatingRedirect] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showChargilySandbox, setShowChargilySandbox] = useState(false);
  
  // Local platform transactions database (persisted to localStorage)
  const [transactions, setTransactions] = useState<PlatformTransaction[]>([]);
  
  // Fraud Detector Simulator States (Safety Tab)
  const [testTxId, setTestTxId] = useState('');
  const [testAmount, setTestAmount] = useState('');
  const [testReceiptImage, setTestReceiptImage] = useState('');
  const [detectorResult, setDetectorResult] = useState<{
    score: number;
    state: 'Safe' | 'Review Required' | 'High Risk';
    reasons: string[];
  } | null>(null);

  // Load products & transactions
  useEffect(() => {
    if (activeWorkspace) {
      getItemsByWorkspace('products', activeWorkspace.id).then(setProducts);
    }
    
    // Load local platform transactions
    const stored = localStorage.getItem(`riyada_platform_txs_${activeWorkspace?.id || 'global'}`);
    if (stored) {
      try {
        setTransactions(JSON.parse(stored));
      } catch (e) {
        console.error(e);
      }
    }
  }, [activeWorkspace]);

  // Persist transactions helper
  const saveTransactions = (updated: PlatformTransaction[]) => {
    setTransactions(updated);
    localStorage.setItem(
      `riyada_platform_txs_${activeWorkspace?.id || 'global'}`,
      JSON.stringify(updated)
    );
  };

  // Run receipt fraud analyzer simulator
  const handleAnalyzeReceipt = () => {
    if (!testTxId) {
      toastError('بيانات ناقصة', 'الرجاء إدخال رقم المعاملة TXID المراد فحص موثوقيته.');
      return;
    }

    let score = 0;
    const reasons: string[] = [];

    // Rule 1: Code formats
    const isStandardDigitsOnly = /^\d+$/.test(testTxId);
    if (!isStandardDigitsOnly || testTxId.length < 5) {
      score += 35;
      reasons.push('معرف العملية TXID لا يتطابق مع النمط الرياضي لحوالات CCP أو بريدي موب القياسي (يحتاج أرقاماً متسلسلة).');
    }

    // Rule 2: Duplicate transaction check inside sandbox and orders
    if (testTxId === '123456' || testTxId === '000000') {
      score += 70;
      reasons.push('معرّف عملية معروف ومكرر لسيناريو اختبار وهمي مكشوف (شائع التزوير).');
    }

    // Rule 3: Amount checks
    const parsedAmount = Number(testAmount);
    if (parsedAmount > 100000) {
      score += 25;
      reasons.push('مبلغ الإشعار ضخم جداً (> 10 ملايين سنتيم) - يتطلب شهادة مطابقة ورقية للتأكد من حساب ECCP.');
    } else if (parsedAmount <= 0 || isNaN(parsedAmount)) {
      score += 15;
      reasons.push('المبلغ المدخل ليس قيمة رقمية صحيحة في الجزائر.');
    }

    // Rule 4: Timestamp check delay (Simulated)
    if (testTxId.endsWith('00') || testTxId.endsWith('99')) {
      score += 40;
      reasons.push('توقيت العملية مشبوه ويتداخل مع فترات انقطاع تسوية الحسابات اليومية ببريد الجزائر.');
    }

    // Rule 5: Receipt Image checklist
    if (testReceiptImage) {
      // If we have an image, we assume it's good but remind about photoshop checks
      reasons.push('تم استلام مستند الإشعار بنجاح. انتبه لعدم تطابق خط الأرقام أو وجود تعديل للألوان بالخلفية.');
    } else {
      score += 20;
      reasons.push('لم يتم تحميل مستند الإثبات المرئي (صورة الوصل) - مستوى الجدية منخفض.');
    }

    // Risk classification
    let state: 'Safe' | 'Review Required' | 'High Risk' = 'Safe';
    if (score >= 60) {
      state = 'High Risk';
    } else if (score >= 25) {
      state = 'Review Required';
    }

    setDetectorResult({
      score: Math.min(100, score),
      state,
      reasons
    });

    success('تنفيذ الفحص', 'تم تشغيل خوارزمية الفحص الهيكلي بنجاح.');
  };

  // Initiate purchase plan
  const handleInitiateBoost = (plan: BoostPlan) => {
    setSelectedPlan(plan);
    setPaymentStep('method_selection');
  };

  // Start checkout step
  const handleProceedToPayment = () => {
    if (!selectedPlan) return;
    
    // Check if product is required
    if ((selectedPlan.type === 'wilaya_spotlight' || selectedPlan.type === 'category_dominance') && !selectedProductId) {
      toastError('يرجى تحديد السلعة', 'الرجاء اختيار أحد المنتجات من مخزنك أولاً لربط ترويج الظهور به.');
      return;
    }

    setPaymentStep('process_payment');

    if (paymentMethod === 'chargily') {
      // Simulate redirect to Chargily checkout link
      setIsSimulatingRedirect(true);
      setTimeout(() => {
        setIsSimulatingRedirect(false);
        setShowChargilySandbox(true); // Open simulated Chargily Invoice Page
      }, 1800);
    }
  };

  // Handle mock manual submission
  const handleSubmitManualProof = () => {
    if (!selectedPlan) return;
    if (!txId.trim()) {
      toastError('رمز الحوالة فارغ', 'الرجاء كتابة رقم المعاملة للتحقق المطابق.');
      return;
    }

    // Create initiated payment state transaction
    const newTx: PlatformTransaction = {
      id: `RYD-UP-${Math.floor(100000 + Math.random() * 900000)}`,
      planId: selectedPlan.id,
      planName: selectedPlan.name,
      amount: selectedPlan.price,
      paymentMethod: 'baridimob_manual',
      status: 'payment_submitted', // Submitted state
      txId: txId.trim(),
      proofFile: proofFile || undefined,
      timestamp: Date.now(),
      unlockedProductId: selectedProductId || undefined
    };

    saveTransactions([newTx, ...transactions]);
    success('تم إرسال إثباتك', 'تم تقديم إشعار الترقية يدوياً وهو الآن قيد المراجعة البشرية في لوحة محاكاة الأدمن.');
    setPaymentStep('review');
    
    // Reset inputs
    setTxId('');
    setProofFile('');
    setSenderName('');
  };

  // Simulated gateway responses from chargily
  const handleChargilyCallback = (outcome: 'accepted' | 'canceled') => {
    setShowChargilySandbox(false);
    if (!selectedPlan) return;

    if (outcome === 'accepted') {
      const newTx: PlatformTransaction = {
        id: `RYD-UP-${Math.floor(100000 + Math.random() * 900000)}`,
        planId: selectedPlan.id,
        planName: selectedPlan.name,
        amount: selectedPlan.price,
        paymentMethod: 'chargily',
        status: 'payment_submitted', // Redirect callback doesn't auto-verify, goes to review
        txId: `CHG-${Math.floor(1000000 + Math.random() * 9000000)}`,
        timestamp: Date.now(),
        unlockedProductId: selectedProductId || undefined
      };

      saveTransactions([newTx, ...transactions]);
      success('ترصيد المعاملة', 'تم الاتصال ببوابة Chargily بنجاح وتوجيه الإشعار كـ "قيد التحقق اليدوي".');
    } else {
      toastError('تم إلغاء الدفع', 'أغلقت نافذة المعالجة عبر بوابة Chargily الشريكة.');
    }
    setPaymentStep('review');
  };

  // ADMIN CONTROL BYPASS SIMULATOR WORKBENCH (Manual Approval Simulation for users)
  const handleAdminAction = async (tx: PlatformTransaction, action: 'approve' | 'reject') => {
    const updatedStatus = action === 'approve' ? 'approved' : 'rejected';
    
    const nextTransactions = transactions.map(t => {
      if (t.id === tx.id) {
        return { ...t, status: updatedStatus as any };
      }
      return t;
    });
    
    saveTransactions(nextTransactions);

    if (action === 'approve') {
      success('عملية تفعيل ناجحة ✨', `تم تفعيل ترقية "${tx.planName}" لمتجرك رسمياً بالمنظومة.`);
      
      // If of type verify badge, we can update workspace properties if there was a real write.
      // If product spotlight, we update the product sponsored tag in indexeddb!
      if (tx.unlockedProductId) {
        try {
          const dbProducts = await getItemsByWorkspace('products', activeWorkspace?.id || '');
          const targetPr = dbProducts.find(p => p.id === tx.unlockedProductId);
          if (targetPr) {
            targetPr.sponsored = true;
            // Let's add custom tags
            targetPr.dynamicData = {
              ...targetPr.dynamicData,
              boostedAt: Date.now(),
              boostPlan: tx.planId
            };
            await addItem('products', targetPr);
          }
        } catch (e) {
          console.error('Failed to auto-update product table: ', e);
        }
      } else if (tx.planId === 'gold_badge') {
        // Unlocks badge on workspace client memory
        localStorage.setItem(`riyada_gold_verified_${activeWorkspace?.id}`, 'true');
      } else if (tx.planId === 'analytics_up') {
        // Unlock analytics
        localStorage.setItem(`riyada_platinum_analytics_${activeWorkspace?.id}`, 'true');
      }
    } else {
      toastError('معاملة مرفوضة', 'تم وسم المستند بـ "مرفوض لتضارب الإثباتات". يمكن للبائع إعادة التقديم.');
    }
  };

  return (
    <div className="flex flex-col gap-6 h-full pb-8 select-none text-right" dir="rtl">
      
      {/* 1. HEADER SECTION & RISK MITIGATION EXPLANATION */}
      <div className="bg-[#0e141c] border border-brand-500/20 rounded-2xl p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 left-0 bg-brand-500 text-black px-3 py-1 font-bold text-xs rounded-br-2xl flex items-center gap-1.5 animate-pulse">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>تعديل الأمان المعتمد v20</span>
        </div>

        <div className="space-y-2 mt-2">
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Coins className="w-7 h-7 text-brand-400" />
            <span>نظام دفع ومبيعات ريادة الآمن (Riyada Trust Engine)</span>
          </h2>
          <p className="text-xs text-white/60 leading-relaxed max-w-4xl">
            تعمل منصة ريادة كـ <strong className="text-brand-400">منظومة إشراف وتنسيق لا مركزي للأعمال</strong>. 
            لحماية خصوصية وأمان الجميع، <span className="text-rose-400 underline decoration-wavy">نحن لا نحتفظ بأموالك ولا نقوم بدور الوساطة المالية المطلقة (Escrow)</span>. 
            تتم مبيعاتك مباشرة يداً بيد أو عبر بريد الجزائر، بينما نضمن لك الأدوات الرقمية المناسبة لمطابقة الهوية، تتبع أثر الحوالات، وكشف محاولات التزوير بدقة.
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex gap-2.5 mt-6 border-t border-white/5 pt-4">
          <button
            onClick={() => setActiveTab('safety')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'safety' 
                ? 'bg-brand-500 text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>مركز الأمان والوقاية من الاحتيال بالجزائر</span>
          </button>
          
          <button
            onClick={() => setActiveTab('monetization')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'monetization' 
                ? 'bg-brand-500 text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>ترقيات الظهور وتمويل المنصة (Monetization Center)</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* TAB 1: SAFETY & FRAUD PREVENTION */}
        {activeTab === 'safety' && (
          <>
            <div className="xl:col-span-2 space-y-6">
              
              {/* Fake Receipt Protection Guidelines */}
              <Card className="p-6 border-white/10 space-y-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-white/5 pb-2">
                  <BadgeAlert className="w-5 h-5 text-rose-400 animate-bounce" />
                  <span>دليل ريادة الذهبي للوقاية من إيصالات CCP / بريدي موب المزورة</span>
                </h3>

                <p className="text-xs text-white/50 leading-relaxed">
                  يتعرض البائعون في الجزائر دورياً لخسارة بضائعهم نتيجة إرسال المشترين للقطات شاشة (Screenshots) لحوالات بريدي موب أو وصولات بريدية مزيفة عبر برامج تحرير الصور وسرقتها رقمياً بريادة. التزم دوماً بمطابقات الدفع اللامركزية التالية:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 font-sans">
                  
                  <div className="bg-[#121620] p-4 rounded-xl border border-white/5 space-y-2">
                    <span className="text-xs text-rose-400 font-bold block">1. التحقق البصري من خطوط الإيصال ✍️</span>
                    <p className="text-[11px] text-white/70 leading-relaxed">
                      تطابق خط الأرقام: الخط القياسي في تطبيق "بريدي موب" هو نظامي ومتساوي المحاذاة. إذا لاحظت أن رقم المعاملة TXID أو قيمة المبلغ مشوشة أو تختلف عن باقي نصوص الرسالة، فإنها مزورة غالباً ببرامج المونتاج.
                    </p>
                  </div>

                  <div className="bg-[#121620] p-4 rounded-xl border border-white/5 space-y-2">
                    <span className="text-xs text-rose-400 font-bold block">2. رقم العملية الفريد TXID ومطابقته 🔢</span>
                    <p className="text-[11px] text-white/70 leading-relaxed">
                      ابتكار ثوري: لا يُمكن أن يحمل زبونان مختلفان نفس معرّف العملية (Transaction ID). سجّل الرموز دوماً بنظام الطلبيات، وإذا نبهك محرك ريادة "بالرمز المكرر" فاقطع الاتصال بالشخص فوراً لحظر هويته.
                    </p>
                  </div>

                  <div className="bg-[#121620] p-4 rounded-xl border border-white/5 space-y-2">
                    <span className="text-xs text-rose-400 font-bold block">3. لا ترسل المنتجات قبل رسالة ECCP 📱</span>
                    <p className="text-[11px] text-white/70 leading-relaxed">
                      القاعدة المطلقة: لا تثق أبداً بمستند العميل وحده مهما بدا رسمياً. تريّث ولا تشحن الطرد حتى تفتش حسابك البنكي يدوياً أو تتحقق من استلام الإشعار النصي الرسمي لبريد الجزائر على هاتفك المربوط بالدفع.
                    </p>
                  </div>

                  <div className="bg-[#121620] p-4 rounded-xl border border-white/5 space-y-2">
                    <span className="text-xs text-brand-400 font-bold block">4. تفعيل وضع الإثبات العضوي للزبون 🔒</span>
                    <p className="text-[11px] text-white/70 leading-relaxed">
                      عند التزام الدفع CCP، وجّه الزبون لتسليم لقطة شاشة فيديو كاملة لتحريك الحساب، أو طالبه بكتابة اسم المحل "ريادة: {activeWorkspace?.name}" في حقل الملاحظات الاختياري لمستند بريدي موب لإثبات جدية التحويل الفعلي.
                    </p>
                  </div>

                </div>
              </Card>

              {/* Account Isolation and Privacy Proof */}
              <Card className="p-6 border-white/10 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-[#18C29C]" />
                  <span>عزل البيانات وحماية المتراكبات الحيوية للبائع (Account Isolation)</span>
                </h3>
                <p className="text-xs text-white/60 leading-relaxed">
                  منعاً للاستهداف أو سرقة الهوية المالية بالجزائر، تفصل ريادة تماماً معلوماتك البنكية. لا يرى المتسوقون رقم حسابك الذهبي الكامل أو معلوماتك التعريفية الحساسة. يتم قصر العرض في فواتير المحادثات على الأسماء المرمّزة والرموز الحسابية المشفرة:
                </p>

                <div className="bg-[#05070a]/70 p-4 rounded-xl border border-white/5 font-mono space-y-2 max-w-lg">
                  <div className="flex justify-between text-xs border-b border-white/5 pb-1">
                    <span className="text-white/40">الحالة العامة للمتسوق</span>
                    <span className="text-emerald-400 font-bold">مخفي بالكامل ✓</span>
                  </div>
                  <div className="flex justify-between text-xs border-b border-white/5 pb-1">
                    <span className="text-white/40">رقم حساب بريدي موب (RIP)</span>
                    <span className="text-white">************004839</span>
                  </div>
                  <div className="flex justify-between text-xs border-b border-white/5 pb-1">
                    <span className="text-white/40">الهوية المستلمة للولاية</span>
                    <span className="text-white">متجر معتمد - {activeWorkspace?.settings?.wilaya || 'بومرداس'}</span>
                  </div>
                </div>
              </Card>
            </div>

            {/* RIGHT COLUMN: FAKE RECEIPT DETECTOR SIMULATOR */}
            <div className="space-y-6">
              <Card className="p-6 border-white/10 bg-gradient-to-b from-[#111925] to-[#070b13] space-y-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-brand-400 font-bold uppercase tracking-wider block">فاحص الإيصالات الآلي — Heuristics Sandbox</span>
                  <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                    <ShieldAlert className="w-4.5 h-4.5 text-brand-400" />
                    <span>محاكاة رادار كشف الاحتيال الرياضي</span>
                  </h3>
                  <p className="text-[11px] text-white/50 leading-relaxed">
                    ألصق بيانات الإشعار الذي أرسله المشتري لتطبيق فحص النطاقات الثنائية والهياكل الحسابية لتوليد تقييم فوري من ريادة.
                  </p>
                </div>

                <div className="space-y-3.5 pt-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/40">رقم العملية المستلم TXID:</label>
                    <input
                      type="text"
                      placeholder="مثال: 009219382901"
                      value={testTxId}
                      onChange={(e) => setTestTxId(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2 focus:outline-none focus:border-brand-500 font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-white/40">قيمة التحويل المسجلة بالإشعار (DZD):</label>
                    <input
                      type="number"
                      placeholder="مثال: 4500"
                      value={testAmount}
                      onChange={(e) => setTestAmount(e.target.value)}
                      className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2 focus:outline-none focus:border-brand-500 font-mono"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] text-white/40 block">مستند الإيصال أو لقطة التحويل:</label>
                    <div className="border border-dashed border-white/10 rounded-xl p-3 bg-black/20 text-center hover:bg-white/5 transition-colors relative">
                      <input
                        type="file"
                        accept="image/*"
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const rd = new FileReader();
                            rd.onload = () => setTestReceiptImage(rd.result as string);
                            rd.readAsDataURL(file);
                          }
                        }}
                      />
                      {testReceiptImage ? (
                        <div className="space-y-1">
                          <img src={testReceiptImage} alt="Simulated Receipt Preview" className="max-h-20 mx-auto rounded" referrerPolicy="no-referrer" />
                          <span className="text-[9px] text-[#18C29C]">تم تحميل المرفق للفحص البصري ✓</span>
                        </div>
                      ) : (
                        <div className="space-y-1 py-1">
                          <Upload className="w-4 h-4 text-white/40 mx-auto" />
                          <span className="text-[9px] text-white/40 block">تحميل صورة مستند المتسوق (اختياري)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Button 
                    className="w-full text-xs font-bold bg-[#18C29C] hover:bg-[#129A7B] text-black h-9"
                    onClick={handleAnalyzeReceipt}
                  >
                    بدء محاكاة مطابقة وفحص المستند 🔎
                  </Button>
                </div>

                {/* Detector Result View */}
                <AnimatePresence>
                  {detectorResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className={`p-4 rounded-xl border mt-3 space-y-2 ${
                        detectorResult.state === 'High Risk'
                          ? 'bg-rose-500/10 border-rose-500/20 text-rose-300'
                          : detectorResult.state === 'Review Required'
                            ? 'bg-amber-500/10 border-amber-500/20 text-amber-300'
                            : 'bg-[#18C29C]/10 border-[#18C29C]/20 text-emerald-400'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold flex items-center gap-1">
                          🛡️ استجابة رادار الفحص:
                        </span>
                        <span className="text-[10px] font-black px-2 py-0.5 rounded-full uppercase bg-black/45">
                          {detectorResult.state === 'High Risk' ? 'قلق عالي الخطورة ⚠️' : detectorResult.state === 'Review Required' ? 'تنبيه للمراجعة 🔎' : 'مستند سليم حسابياً ✓'}
                        </span>
                      </div>
                      <div className="text-[10px] space-y-1.5 leading-relaxed text-white/85">
                        {detectorResult.reasons.map((r, i) => (
                          <div key={i} className="flex gap-1.5 items-start">
                            <span>•</span>
                            <p>{r}</p>
                          </div>
                        ))}
                      </div>
                      <div className="pt-1.5 border-t border-white/5 flex justify-between items-center text-[9px] text-white/40">
                        <span>مؤشر الريبة: {detectorResult.score}%</span>
                        <button 
                          onClick={() => setDetectorResult(null)}
                          className="text-white/60 hover:underline"
                        >
                          إغلاق النتيجة
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </div>
          </>
        )}

        {/* TAB 2: MONETIZATION & PLATFORM UPGRADES */}
        {activeTab === 'monetization' && (
          <>
            <div className="xl:col-span-2 space-y-6">
              
              {/* Core selection flow wrapper */}
              <Card className="p-6 border-white/10 space-y-6">
                
                {paymentStep === 'plan_selection' && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-white/5 pb-3">
                      <div>
                        <h3 className="text-base font-bold text-white flex items-center gap-2">
                          <Sparkles className="w-5 h-5 text-amber-400" />
                          <span>ترقيات الظهور والتمكين العضوي (100% اختياري)</span>
                        </h3>
                        <p className="text-xs text-white/40 mt-1">
                          جميع وظائف ريادة الأساسية ومخازنها ومبيعاتها مجانية للجميع للأبد. اختر إحدى باقات التمكين لزيادة المبيعات وتمويل خوادم الصيانة:
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {PLANS.map((plan) => (
                        <div 
                          key={plan.id}
                          className="bg-[#111622] rounded-xl p-4 border border-white/5 flex flex-col justify-between hover:border-brand-500/20 transition-all gap-4"
                        >
                          <div className="space-y-2">
                            <span className="text-xs font-bold text-brand-400 block">{plan.name}</span>
                            <p className="text-[10px] text-white/60 leading-relaxed h-12 overflow-hidden">
                              {plan.description}
                            </p>
                          </div>

                          <div className="flex justify-between items-end border-t border-white/5 pt-3">
                            <div className="flex flex-col text-right">
                              <span className="text-[10px] text-white/40">الكلفة الكلية لمرة واحدة:</span>
                              <span className="text-sm font-black text-emerald-400 font-mono">{plan.price} دج ({plan.durationDays} يوم)</span>
                            </div>
                            <Button 
                              size="sm"
                              className="text-[11px] h-7 bg-brand-500 hover:bg-brand-600 text-black font-extrabold"
                              onClick={() => handleInitiateBoost(plan)}
                            >
                              اختيار الترقية ⚡
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {paymentStep === 'method_selection' && selectedPlan && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                      <button 
                        onClick={() => setPaymentStep('plan_selection')}
                        className="p-1 rounded-lg hover:bg-white/5 text-white/40 text-xs flex items-center gap-1"
                      >
                        <ArrowLeft className="w-4 h-4 rotate-180" />
                        <span>العودة للباقات</span>
                      </button>
                    </div>

                    <div className="bg-[#0b0f14]/80 p-4 rounded-xl border border-white/5 flex justify-between items-center">
                      <div className="text-right">
                        <span className="text-[10px] text-white/40 block">الخيار المختار للتفعيل:</span>
                        <strong className="text-sm text-white">{selectedPlan.name}</strong>
                      </div>
                      <span className="text-sm font-mono font-black text-brand-400">{selectedPlan.price} دج</span>
                    </div>

                    {/* Product Selector for Listing Boost */}
                    {(selectedPlan.type === 'wilaya_spotlight' || selectedPlan.type === 'category_dominance') && (
                      <div className="space-y-2 bg-[#090d15] p-4 rounded-xl border border-white/5">
                        <label className="text-xs text-white/70 block font-bold">🎯 حدد السلعة التي تريد ربط ترويج الظهور بها:</label>
                        <select
                          value={selectedProductId}
                          onChange={(e) => setSelectedProductId(e.target.value)}
                          className="w-full bg-[#121620] border border-white/10 rounded-lg p-2.5 text-xs text-white focus:outline-none"
                        >
                          <option value="">-- اضغط لاختيار أحد سلع مخزنك --</option>
                          {products.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} ({formatDZD(p.price)})
                            </option>
                          ))}
                        </select>
                        <p className="text-[9px] text-[#18C29C] italic">تتطلب المزامنة ترويج سلع مسجلة سلفاً في تبويب المخزون لمتجرك.</p>
                      </div>
                    )}

                    {/* Step 2: Choose Payment Method */}
                    <div className="space-y-3 pt-2">
                      <label className="text-xs text-white/70 block font-bold">💳 حدد طريقة إرسال الرسوم والربط المالي:</label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        
                        <div 
                          onClick={() => setPaymentMethod('chargily')}
                          className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col gap-1.5 ${
                            paymentMethod === 'chargily' 
                              ? 'bg-brand-500/5 border-brand-500 text-white' 
                              : 'bg-black/25 border-white/5 text-white/50 hover:bg-white/5'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-white flex items-center gap-1.5">
                              <ExternalLink className="w-3.5 h-3.5 text-brand-400" />
                              <span>بوابة Chargily الجزائرية الشهيرة</span>
                            </span>
                            <span className="text-[9px] bg-brand-500 text-black px-1.5 rounded-full font-bold">آلي ونقدي</span>
                          </div>
                          <p className="text-[10px] text-white/40 leading-relaxed">
                            ادفع ببطاقة الذهبية أو CIB مباشرة عبر نافذة الدخول الموحد لشركة Chargily المعترف بها رسمياً بالجزائر. لا يتم تخزين تفاصيل كارت الدفع بالمنصة.
                          </p>
                        </div>

                        <div 
                          onClick={() => setPaymentMethod('baridimob_manual')}
                          className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col gap-1.5 ${
                            paymentMethod === 'baridimob_manual' 
                              ? 'bg-brand-500/5 border-brand-500 text-white' 
                              : 'bg-black/25 border-white/5 text-white/50 hover:bg-white/5'
                          }`}
                        >
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-white flex items-center gap-1.5">
                              <CreditCard className="w-3.5 h-3.5 text-blue-400" />
                              <span>حوالة CCP / تطبيق بريدي موب يدوي</span>
                            </span>
                            <span className="text-[9px] bg-blue-500 text-white px-1.5 rounded-full font-bold">تحويل ذاتي</span>
                          </div>
                          <p className="text-[10px] text-white/40 leading-relaxed">
                            حول الكلفة مباشرة لحساب بريدي موب الخاص بمدير خوادم ريادة، ثم ألصق رقم المعاملة TXID أو لقطة إشعار التحويل لتلقي الترقية للسلعة المختارة.
                          </p>
                        </div>

                      </div>
                    </div>

                    <div className="pt-2 flex justify-end">
                      <Button 
                        onClick={handleProceedToPayment}
                        className="w-full md:w-48 text-xs font-bold bg-[#18C29C] hover:bg-[#129A7B] text-black h-9"
                      >
                        متابعة لإعداد الترقية 🚀
                      </Button>
                    </div>

                  </div>
                )}

                {paymentStep === 'process_payment' && selectedPlan && !showChargilySandbox && (
                  <div className="space-y-4 pt-1">
                    <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                      <button 
                        onClick={() => setPaymentStep('method_selection')}
                        className="p-1 rounded-lg hover:bg-white/5 text-white/40 text-xs flex items-center gap-1"
                      >
                        <ArrowLeft className="w-4 h-4 rotate-180" />
                        <span>تغيير وسيلة الدفع</span>
                      </button>
                    </div>

                    {isSimulatingRedirect ? (
                      <div className="py-12 flex flex-col items-center justify-center gap-4 text-center">
                        <RefreshCw className="w-10 h-10 text-brand-400 animate-spin" />
                        <div className="space-y-1">
                          <h4 className="text-sm font-bold text-white">جاري الاتصال المشفر بـ Chargily Sandbox...</h4>
                          <p className="text-[10px] text-white/40">يرجى الانتظار، يتم توليد فاتورة الإيداع المؤمنة لولاية المزامنة مجهولة الهوية.</p>
                        </div>
                      </div>
                    ) : (
                      // Manual BaridiMob details (Masked carefully to avoid critical identity exposure)
                      <div className="space-y-4">
                        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3.5 flex gap-2.5 text-amber-200">
                          <AlertTriangle className="w-4.5 h-4.5 text-amber-400 shrink-0 mt-0.5" />
                          <div className="space-y-1 text-xs leading-relaxed text-right">
                            <strong className="block">حماية العزل البنكي مفعلة (Identity Isolation):</strong>
                            <p className="text-white/70">
                              تقع مسؤولية التحقيق على عاتق صيانة التطبيق. معطياتنا البنكية مجمّعة ومحميّة ومعرّضة بشكل مجتزأ. تجنّب مشاركة تفاصيل دفع كاملة أو الحوالات الأصلية على الويب العام.
                            </p>
                          </div>
                        </div>

                        <div className="bg-[#121722] p-4 rounded-xl border border-white/5 space-y-3 font-sans max-w-lg">
                          <h4 className="text-xs font-bold text-white">🏦 معلومات حساب الترصيد لريادة (مستلم الرسوم):</h4>
                          
                          <div className="grid grid-cols-2 gap-3 text-[11px] pt-1 border-t border-white/5">
                            <div>
                              <span className="text-white/40 block">الاسم المرمّز المعزّز:</span>
                              <span className="text-white font-bold font-mono">RIYADA Platform Operator</span>
                            </div>
                            <div>
                              <span className="text-white/40 block">حساب الجاري CCP:</span>
                              <span className="text-white font-bold font-mono">002492931 / مفتاح 32</span>
                            </div>
                            <div className="col-span-2 pt-1">
                              <span className="text-white/40 block">رقم الـ RIP لبريدي موب:</span>
                              <span className="text-white font-bold font-mono">00799999002492931032</span>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3 pt-2 max-w-lg">
                          <div className="space-y-1">
                            <label className="text-[11px] text-white/50 font-bold block">رقم أو مرجع التحويلة المكتملة TXID:</label>
                            <input
                              type="text"
                              required
                              placeholder="أدخل الـ 12 رقماً الموجود في وصل بريديموب / CCP"
                              value={txId}
                              onChange={(e) => setTxId(e.target.value)}
                              className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2.5 focus:outline-none focus:border-brand-500 font-mono"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] text-white/50 block">صورة إيصال التحويل (وصل CCP أو لقطة شاشة بريديموب):</label>
                            <div className="border border-dashed border-white/10 rounded-xl p-3 bg-black/20 text-center hover:bg-white/5 cursor-pointer relative">
                              <input
                                type="file"
                                accept="image/*"
                                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const rd = new FileReader();
                                    rd.onload = () => setProofFile(rd.result as string);
                                    rd.readAsDataURL(file);
                                  }
                                }}
                              />
                              {proofFile ? (
                                <div className="space-y-1">
                                  <img src={proofFile} alt="Proof base64 representation" className="max-h-24 mx-auto rounded border border-white/10" referrerPolicy="no-referrer" />
                                  <button type="button" onClick={() => setProofFile('')} className="text-[10px] text-red-400 hover:underline">حذف المرفق</button>
                                </div>
                              ) : (
                                <div className="space-y-1">
                                  <Upload className="w-5 h-5 text-white/40 mx-auto" />
                                  <span className="text-[10px] text-white/40 block">اسحب وألقِ لقطة الشاشة هنا</span>
                                  <span className="text-[8px] text-white/30">تحفظ محلياً ومشفرة بالكامل على جهازك</span>
                                </div>
                              )}
                            </div>
                          </div>

                          <Button 
                            onClick={handleSubmitManualProof}
                            className="w-full text-xs font-bold bg-[#18C29C] hover:bg-[#129A7B] text-black h-9"
                          >
                            تأكيد التقديم وقيد المطبوعات المعلقة 📥
                          </Button>
                        </div>
                      </div>
                    )}

                  </div>
                )}

                {/* Submited payment confirmation & bypass simulator panel instructions */}
                {paymentStep === 'review' && (
                  <div className="space-y-4 pt-1">
                    <div className="bg-emerald-500/10 border border-[#18C29C]/30 text-emerald-400/95 p-4 rounded-xl space-y-1">
                      <strong className="text-xs font-bold block">✓ تم تسجيل طلب الترقية بنجاح بالمتطابقة المحمية!</strong>
                      <p className="text-[11px] leading-relaxed text-white/80">
                        طلبك معلّق بقاعدة البيانات اللامركزية. نظراً لعدم وجود خوادم خلفية حية ومجابهة للإنترنت، يمكنك اختبار تفعيل الميزة على الفور محلياً عبر <strong className="text-brand-400 font-bold">وحة محاكاة تفعيل الأدمن</strong> بالنافذة الجانبية اليسرى.
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        variant="secondary"
                        size="sm"
                        className="text-[10px]"
                        onClick={() => {
                          setSelectedPlan(null);
                          setPaymentStep('plan_selection');
                        }}
                      >
                        قائمة الباقات من جديد
                      </Button>
                      
                      <Button 
                        size="sm"
                        className="text-[10px] bg-white/5 border border-white/10 text-white"
                        onClick={() => setActiveTab('safety')}
                      >
                        مشاهدة تعليمات فحص التزوير
                      </Button>
                    </div>
                  </div>
                )}

              </Card>

              {/* simulated payment gateway popup window inside UI */}
              <AnimatePresence>
                {showChargilySandbox && selectedPlan && (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.95, opacity: 0 }}
                    className="fixed inset-0 bg-black/85 backdrop-blur-sm z-[200] flex items-center justify-center p-4 font-sans text-right"
                    dir="rtl"
                  >
                    <div className="bg-[#0f1422] border border-emerald-500/30 rounded-2xl p-6 max-w-md w-full shadow-2xl relative space-y-4">
                      
                      {/* Brand Logo Header */}
                      <div className="flex justify-between items-center border-b border-white/5 pb-2">
                        <div className="flex items-center gap-1.5">
                          <div className="w-7 h-7 bg-emerald-500 rounded-lg flex items-center justify-center font-black text-black italic text-xs">Ch</div>
                          <span className="text-xs font-bold text-white font-mono">Chargily invoice billing sandbox v20</span>
                        </div>
                        <span className="text-[9px] bg-amber-500/20 text-amber-300 px-2 rounded-full">بيئة محاكاة تجريبية</span>
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] text-white/40 uppercase block">اسم التاجر المستلم:</span>
                        <strong className="text-xs font-black text-white">RIYADA MULTI-PORTAL APPS</strong>
                      </div>

                      <div className="bg-black/30 p-3 rounded-lg border border-white/5 space-y-2">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/50">الخدمة المطلوبة:</span>
                          <span className="text-white font-bold">{selectedPlan.name}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/50">رقم الفاتورة:</span>
                          <span className="text-white font-mono font-bold">INV-CHG-{Math.floor(888122 + Math.random()*112344)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs text-emerald-400 border-t border-white/5 pt-2">
                          <span>المبلغ الكلي لدفعه:</span>
                          <span className="font-mono font-black">{selectedPlan.price} دج</span>
                        </div>
                      </div>

                      <div className="p-3 bg-white/5 rounded-lg text-[10px] text-white/40 leading-relaxed">
                        ⚠️ هذا المشهد يجسّد نموذج بوابة الدفع لشركة Chargily الشريكة. ستتحول دفعتك مباشرة في العالم الحقيقي إلى بروتوكول تصفية الإغلاق ورفع ترصيد البائع يدوياً بريادة.
                      </div>

                      {/* Simulation Interaction Buttons */}
                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => handleChargilyCallback('accepted')}
                          className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-black text-xs font-bold py-2 rounded-xl"
                        >
                          تأكيد المحاكاة بالدفع السليم 💳
                        </button>
                        
                        <button
                          onClick={() => handleChargilyCallback('canceled')}
                          className="flex-1 bg-white/5 hover:bg-white/10 text-white/80 text-xs font-bold py-2 rounded-xl"
                        >
                          إلغاء العملية ✕
                        </button>
                      </div>

                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>

            {/* UPGRADE AND PENDING BOOSTS HISTORY PANEL + ADMIN BYPASS OVERRUN console */}
            <div className="space-y-6">
              
              {/* ADMIN MODE BYPASS MONITOR PANEL */}
              <Card className="p-5 border-amber-500/25 bg-[#171612] space-y-3.5">
                <div className="space-y-1">
                  <span className="bg-amber-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded tracking-widest uppercase block w-fit">
                    أدوات المطور والمشرف المدمجة v20
                  </span>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Settings className="w-4 h-4 text-amber-400 animate-spin" />
                    <span>لوحة محاكاة إدارة الموافقات والاعتمادات</span>
                  </h4>
                  <p className="text-[10px] text-white/50 leading-relaxed">
                    من هنا، يُمكنك تمثيل دور المشرف الأساسي للمنصة (Admin) للموافقة الفورية على طلبات الدفع والترقيات المعلقة لتختبر تأثيراتها اللامركزية.
                  </p>
                </div>

                <div className="space-y-3.5 pt-2 max-h-96 overflow-y-auto">
                  {transactions.length === 0 ? (
                    <div className="text-center py-6 border border-white/5 rounded-xl bg-black/40 text-white/30 text-[10px] leading-relaxed">
                      بمجرد تحديد باقة وتقديم طلب تحويل CCP أو دفع Chargily، ستظهر المعاملات هنا فوراً للموافقة والتفعيل.
                    </div>
                  ) : (
                    transactions.map((tx) => (
                      <div 
                        key={tx.id}
                        className="bg-black/40 p-3 rounded-lg border border-white/5 space-y-2 font-mono text-[10px]"
                      >
                        <div className="flex justify-between items-center text-[9px] border-b border-white/5 pb-1 select-text">
                          <span className="text-white/40">{tx.id}</span>
                          <span className={`px-1.5 rounded-full text-[9px] font-bold ${
                            tx.status === 'approved' 
                              ? 'bg-emerald-500/10 text-[#18C29C]' 
                              : tx.status === 'rejected'
                                ? 'bg-rose-500/10 text-rose-400'
                                : 'bg-amber-500/10 text-amber-400 animate-pulse'
                          }`}>
                            {tx.status === 'approved' ? 'مقبول ونشط ✓' : tx.status === 'rejected' ? 'معرّف مرفوض' : 'قيد المراجعة ⏳'}
                          </span>
                        </div>

                        <div className="space-y-1 text-right font-sans">
                          <p className="text-xs font-bold text-white">{tx.planName}</p>
                          <p className="text-[10px] text-white/50">طريقة الترصيد: {tx.paymentMethod === 'chargily' ? ' Chargily الموحدة' : 'حوالة بريديموب يدوياً'}</p>
                          {tx.txId && <p className="text-[9px] text-[#18C29C] font-mono select-text">معرف العملية: {tx.txId}</p>}
                        </div>

                        {tx.status === 'payment_submitted' && (
                          <div className="flex gap-1.5 pt-1">
                            <button
                              onClick={() => handleAdminAction(tx, 'approve')}
                              className="flex-1 bg-[#18C29C] text-black text-[9px] font-bold py-1 rounded"
                            >
                              موافقة وتفعيل المعاملة ✓
                            </button>
                            <button
                              onClick={() => handleAdminAction(tx, 'reject')}
                              className="flex-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-[9px] font-bold py-1 rounded border border-rose-500/10"
                            >
                              رفض المعاملة
                            </button>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </Card>

              {/* PERSISTENT STATUS VISIBILITY BOX */}
              <Card className="p-5 border-white/10 space-y-3 font-sans">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>التحقق من حالة الميزات الفعالة حالياً:</span>
                </h4>
                
                <div className="space-y-1.5 text-[11px] pt-1 leading-snug">
                  
                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-white/40">شارة VIP المذهبة:</span>
                    <span className={`font-bold ${
                      localStorage.getItem(`riyada_gold_verified_${activeWorkspace?.id}`) === 'true'
                        ? 'text-[#18C29C]'
                        : 'text-white/20'
                    }`}>
                      {localStorage.getItem(`riyada_gold_verified_${activeWorkspace?.id}`) === 'true' ? 'نشطة ومتوفرة ✓' : 'غير نشطة (اختر باقة التوثيق)'}
                    </span>
                  </div>

                  <div className="flex justify-between border-b border-white/5 pb-1.5">
                    <span className="text-white/40">الأداء البلاتيني للتقارير:</span>
                    <span className={`font-bold ${
                      localStorage.getItem(`riyada_platinum_analytics_${activeWorkspace?.id}`) === 'true'
                        ? 'text-[#18C29C]'
                        : 'text-white/20'
                    }`}>
                      {localStorage.getItem(`riyada_platinum_analytics_${activeWorkspace?.id}`) === 'true' ? 'نشط وقيد العرض ✓' : 'مغلق (ترقية بلاتينيوم)'}
                    </span>
                  </div>

                  <p className="text-[10px] text-white/30 italic">عند الموافقة على أحد الترقيتين، سيتم تحديث النطاقات وتفعيل المميزات فوراً بالمتصفح بشكل دائم.</p>
                </div>
              </Card>

            </div>
          </>
        )}

      </div>

    </div>
  );
}
