import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Search, Package } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { formatDZD } from '../lib/utils';
import { getFavorites, getAllItems, trackInteraction, toggleFavorite } from '../lib/db';
import { TrustBadge } from '../components/TrustBadge';

export default function Saved() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadFavorites = async () => {
    setIsLoading(true);
    try {
      const favs = await getFavorites();
      const allProducts = await getAllItems('products');
      
      const savedProducts = favs.map(f => {
        const prod = allProducts.find(p => p.id === f.id);
        return prod;
      }).filter(Boolean); // remove undefined
      
      setProducts(savedProducts);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  const handleProductClick = (product: any) => {
    trackInteraction(product.id, 'view', product.vendorId);
    navigate(`/product/${product.id}`);
  };

  const handleRemoveFavorite = async (product: any, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await toggleFavorite(product.id);
      loadFavorites(); // refresh
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1 flex items-center gap-2">
            <Heart className="w-6 h-6 text-red-500 fill-current" />
            المنتجات المفضلة
          </h1>
          <p className="text-white/50">إدارة المنتجات والمتاجر التي قمت بحفظها.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary" className="gap-2">
            <Search className="w-4 h-4" />
            بحث في المفضلة
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-12">
          <div className="w-8 h-8 border-4 border-white/10 border-t-brand-500 rounded-full animate-spin"></div>
        </div>
      ) : products.length === 0 ? (
        <Card className="flex flex-col items-center justify-center p-12 text-center bg-white/5 border-dashed border-white/10">
          <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
            <Heart className="w-8 h-8 text-white/30" />
          </div>
          <h3 className="text-lg font-medium text-white mb-2">لا توجد منتجات مفضلة</h3>
          <p className="text-white/50 max-w-md mb-6">احفظ المنتجات التي تعجبك للرجوع إليها لاحقاً.</p>
          <Button onClick={() => navigate('/')}>تصفح المنتجات</Button>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {products.map((product) => (
            <Card 
              key={product.id}
              className="p-0 flex flex-col overflow-hidden cursor-pointer group transition-all duration-300 hover:shadow-2xl hover:shadow-brand-500/10 hover:-translate-y-1"
              onClick={() => handleProductClick(product)}
            >
              <div className="relative h-40 sm:h-48 md:h-56 bg-[#0a0f18] overflow-hidden">
                <button 
                  onClick={(e) => handleRemoveFavorite(product, e)}
                  className="absolute top-2 left-2 z-20 p-1.5 bg-white/10 backdrop-blur-md rounded-full text-red-500 transition-colors"
                >
                  <Heart className="w-4 h-4 fill-current" />
                </button>
                {product.image ? (
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-white/20 transition-transform duration-500 group-hover:scale-105 group-hover:text-white/30">
                    <Package className="w-12 h-12 mb-2 stroke-[1.5]" />
                  </div>
                )}
              </div>
              <div className="p-4 flex flex-col flex-1">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs text-white/50 truncate bg-white/5 px-2 py-0.5 rounded leading-none w-fit">
                    {product.category}
                  </span>
                  {product.verified && <TrustBadge />}
                </div>
                <h3 className="font-medium text-white text-sm line-clamp-2 leading-snug mb-1 group-hover:text-brand-400 transition-colors">
                  {product.name}
                </h3>
                <div className="text-xs text-white/40 truncate mb-4">
                  {product.vendorName}
                </div>
                <div className="mt-auto flex items-end justify-between">
                  <div>
                    <div className="text-xs text-white/40 mb-0.5">السعر</div>
                    <div className="text-lg font-bold text-brand-400 font-mono tracking-tight leading-none">
                      {formatDZD(product.price)}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
