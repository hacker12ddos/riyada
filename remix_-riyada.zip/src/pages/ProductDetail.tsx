import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  MessageCircle, 
  MapPin, 
  ShieldCheck, 
  Share2, 
  Store, 
  CreditCard, 
  Truck, 
  Heart, 
  QrCode,
  FileCheck,
  Upload,
  User,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Loader2,
  ChevronDown,
  ArrowLeftRight,
  DollarSign,
  Clock
} from 'lucide-react';
import { Card } from '../components/ui/Card';
import { TrustBadge } from '../components/TrustBadge';
import { QRCodeModal } from '../components/QRCodeModal';
import { ReportModal } from '../components/ReportModal';
import { Button } from '../components/ui/Button';
import { formatDZD } from '../lib/utils';
import { SEED_DATA } from '../lib/seed';
import { getAllItems, trackInteraction, isFavorite, toggleFavorite, addItem, ALGERIAN_WILAYAS } from '../lib/db';
import { useToast } from '../contexts/ToastContext';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { createNegotiationThread } from '../lib/threads';
import { API } from '../lib/api';

export default function ProductDetail() {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { success, error: toastError } = useToast();
  const { activeWorkspace } = useWorkspace();
  
  const [product, setProduct] = useState<any>(null);
  const [isFav, setIsFav] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showQR, setShowQR] = useState(false);
  const [showReport, setShowReport] = useState(false);

  // Trusted Deal Flow & OrderIntent States
  const [showOrderPanel, setShowOrderPanel] = useState(false);
  const [buyerName, setBuyerName] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [buyerWilaya, setBuyerWilaya] = useState('الجزائر');
  const [buyerAddress, setBuyerAddress] = useState('');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState<'chargily' | 'cib' | 'ccp' | 'cod'>('chargily');
  const [receiptFileB64, setReceiptFileB64] = useState('');
  const [txRef, setTxRef] = useState('');
  const [isPaying, setIsPaying] = useState(false);
  const [chargilyCardNumber, setChargilyCardNumber] = useState('');

  // Internal Negotiation States
  const [commType, setCommType] = useState<'none' | 'offer' | 'deal' | 'negotiate' | 'avail'>('none');
  const [commName, setCommName] = useState('');
  const [commPhone, setCommPhone] = useState('');
  const [commMessage, setCommMessage] = useState('');
  const [commPrice, setCommPrice] = useState('');
  const [isSendingComm, setIsSendingComm] = useState(false);
  const [sentCommSuccess, setSentCommSuccess] = useState(false);

  // Dynamically compute risk score: Base 20. +25 if price > 10000. +35 if unverified seller.
  const calculatePrRiskScore = (price: number, isVerifiedS: boolean) => {
    let score = 20;
    if (price > 10000) score += 25;
    if (!isVerifiedS) score += 35;
    return score;
  };

  useEffect(() => {
    loadProduct();
  }, [productId]);

  const loadProduct = async () => {
    setIsLoading(true);
    try {
      // Record view
      trackInteraction(productId!, 'view');
      
      // Load fav state
      const fav = await isFavorite(productId!);
      setIsFav(fav);

      // find product
      let found = null;
      const dbProducts = await getAllItems('products');
      found = dbProducts.find(p => p.id === productId);
      
      // Fallback if completely not found but somehow navigated
      if (!found) {
        found = {
          id: productId,
          name: 'المنتج غير موجود أو محذوف',
          price: 0,
          category: 'غير محدد',
          description: 'تفاصيل المنتج غير متوفرة في قاعدة البيانات المحلية.',
          vendorName: 'متجر غير معروف',
          wilaya: 'غير محدد'
        };
      }
      
      setProduct(found);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleWhatsApp = () => {
    if (!product) return;
    trackInteraction(product.id, 'whatsapp', product.vendorId);
    
    let message = '';
    const name = product.name;
    const price = formatDZD(product.price);
    
    if (product.category === 'خدمات') {
      message = `السلام عليكم، بخصوص خدمتك "${name}". هل أنت متاح لتقديم هذه الخدمة وهل يمكنني معرفة المزيد من التفاصيل؟\nالرابط: ${window.location.href}`;
    } else if (product.category === 'عقارات') {
      message = `السلام عليكم، مهتم بالعقار המسمى "${name}" بسعر ${price}. هل لا زال متوفراً؟ وهل يمكنني طلب معاينة؟\nالرابط: ${window.location.href}`;
    } else if (product.category === 'مركبات') {
      message = `السلام عليكم، بخصوص المركبة "${name}" بسعر ${price}. هل يمكنني معرفة تفاصيل أكثر وتحديد موعد لرؤيتها؟\nالرابط: ${window.location.href}`;
    } else if (product.category === 'وظائف') {
      message = `السلام عليكم، بخصوص إعلان التوظيف "${name}". هل يمكنني التقدم لهذه الوظيفة؟\nالرابط: ${window.location.href}`;
    } else {
      message = `السلام عليكم، حاب نشري من عندك "${name}" بسعر ${price}. هل متوفر حاليا ً وبشحال التوصيل لولايتي؟\nالرابط: ${window.location.href}`;
    }
    
    window.open(`https://wa.me/213555000000?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleFavorite = async () => {
    if (!product) return;
    const current = await toggleFavorite(product.id);
    setIsFav(current);
  };

  if (isLoading || !product) {
    return (
      <div className="flex justify-center p-12">
        <div className="w-8 h-8 border-4 border-white/10 border-t-brand-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12 max-w-6xl mx-auto">
      {/* Breadcrumb / Back */}
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors"
      >
        <ArrowRight className="w-4 h-4" />
        العودة للنتائج
      </button>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Product Images */}
        <div className="md:col-span-5 lg:col-span-4 space-y-4">
          <div className="aspect-square bg-white/5 border border-white/10 rounded-3xl overflow-hidden relative">
            {product.image ? (
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-white/10 text-9xl">S</span>
              </div>
            )}
            <div className="absolute top-4 right-4 flex flex-col gap-2">
              <button 
                onClick={handleFavorite}
                className={`w-10 h-10 backdrop-blur-md rounded-full flex items-center justify-center transition-colors border border-white/10 ${isFav ? 'bg-white/10 text-red-500' : 'bg-black/40 text-white/70 hover:text-red-400 hover:bg-black/60'}`}
              >
                <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
              </button>
              <button 
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: product.name,
                      text: product.description,
                      url: window.location.href,
                    }).catch(console.error);
                  }
                }}
                className="w-10 h-10 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-black/60 transition-colors border border-white/10"
              >
                <Share2 className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setShowQR(true)}
                className="w-10 h-10 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-black/60 transition-colors border border-white/10"
              >
                <QrCode className="w-4 h-4" />
              </button>
            </div>
          </div>
          {/* Thumbnails */}
          <div className="grid grid-cols-4 gap-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="aspect-square bg-white/5 border border-white/10 rounded-xl cursor-not-allowed opacity-50 flex items-center justify-center">
                 <span className="text-white/20 text-xs">صورة {i}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="md:col-span-7 lg:col-span-5 flex flex-col">
          <span className="text-brand-400 text-sm font-medium mb-2">{product.category}</span>
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-4 leading-tight">{product.name}</h1>
          
          <div className="flex items-center gap-4 mb-6 pb-6 border-b border-white/10">
            <span className="text-3xl font-bold text-white">{product.price === 0 && product.category === 'وظائف' ? 'راتب يُحدد لاحقاً' : formatDZD(product.price)}</span>
            {!['خدمات', 'عقارات', 'وظائف'].includes(product.category) && (
              (product.stock || 0) > 0 ? (
                <span className="bg-emerald-500/10 text-emerald-400 text-xs px-2 py-1 rounded border border-emerald-500/20">متوفر في المخزون</span>
              ) : (
                <span className="bg-red-500/10 text-red-400 text-xs px-2 py-1 rounded border border-red-500/20">نفذت الكمية</span>
              )
            )}
            {product.category === 'خدمات' && (
              <span className="bg-blue-500/10 text-blue-400 text-xs px-2 py-1 rounded border border-blue-500/20">متاح للحجز</span>
            )}
            {product.category === 'وظائف' && (
               <span className="bg-purple-500/10 text-purple-400 text-xs px-2 py-1 rounded border border-purple-500/20">توظيف مفتوح</span>
            )}
          </div>

          <div className="prose prose-invert prose-sm mb-8">
            <h3 className="text-white/80 font-medium mb-2">وصف {['خدمات', 'وظائف'].includes(product.category) ? 'الإعلان' : 'المنتج'}:</h3>
            <p className="text-white/60 leading-relaxed max-w-none break-words whitespace-pre-wrap">
              {product.description || 'لا يوجد وصف متاح.'}
            </p>
            
            {product.dynamicData && Object.keys(product.dynamicData).length > 0 && (
              <div className="mt-6 space-y-3 border-t border-white/10 pt-4">
                <h4 className="text-white/80 font-medium mb-2">معلومات إضافية:</h4>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  {Object.entries(product.dynamicData).map(([key, value]) => {
                    if (!value) return null;
                    const labels: Record<string, string> = {
                      brand: 'العلامة التجارية',
                      condition: 'الحالة',
                      cuisineType: 'نوع المطبخ',
                      preparationTime: 'وقت التحضير',
                      serviceDuration: 'مدة العمل',
                      year: 'سنة الصنع',
                      mileage: 'المسافة المقطوعة',
                      surfaceArea: 'المساحة (م²)',
                      contractType: 'نوع العقد',
                      salaryRange: 'الراتب المتوقع'
                    };
                    const label = labels[key] || key;
                    return (
                      <div key={key} className="bg-white/5 rounded-lg p-3 border border-white/5">
                        <span className="text-white/40 block text-xs mb-1">{label}</span>
                        <span className="text-white/90 font-medium block">{value as string}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Action Area */}
          {product.category === 'خدمات' && (
            <div className="mb-6 bg-[#0E141C] border border-[#18C29C]/20 rounded-2xl p-5 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#18C29C] animate-pulse"></span>
                تقديم طلب عرض سعر مخصص أو حجز الخدمة
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-white/50 block mb-1">طبيعة عرض السعر المطلوبة</label>
                  <select id="pricing-model-select" className="w-full bg-[#070A0F] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:border-[#18C29C]/50 outline-none">
                    <option value="سعر ثابت">سعر ثابت لكامل المشروع</option>
                    <option value="بالساعة">سعر بالساعة لعمل مستمر</option>
                    <option value="استشارة أولية">طلب استشارة أو معاينة أولية</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-white/50 block mb-1">تاريخ البدء أو الميعاد المقترح</label>
                  <input id="booking-date-input" type="date" className="w-full bg-[#070A0F] border border-white/10 rounded-lg px-3 py-2 text-primary text-xs text-white focus:border-[#18C29C]/50 outline-none" style={{colorScheme: 'dark'}} />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-white/50 block mb-1">شرح موجز لمتطلباتك وتفاصيل المشروع</label>
                <textarea id="booking-details-textarea" rows={2} placeholder="اكتب هنا ما تحتاجه تحديداً من الحرفي أو مقدم الخدمة..." className="w-full bg-[#070A0F] border border-white/10 rounded-lg px-3 py-2 text-xs text-white resize-none focus:border-[#18C29C]/50 outline-none" />
              </div>
              <Button 
                onClick={() => {
                  const modelSel = (document.getElementById('pricing-model-select') as HTMLSelectElement)?.value || 'سعر ثابت';
                  const dateVal = (document.getElementById('booking-date-input') as HTMLInputElement)?.value || 'في أقرب وقت';
                  const detailVal = (document.getElementById('booking-details-textarea') as HTMLTextAreaElement)?.value || '';
                  
                  trackInteraction(product.id, 'whatsapp', product.vendorId);
                  
                  const message = `السلام عليكم، أود طلب حجز/عرض سعر لخدمتك بـ ريادة:\n` +
                    `- الخدمة: "${product.name}"\n` +
                    `- نموذج التسعير: ${modelSel}\n` +
                    `- التاريخ المقترح: ${dateVal}\n` +
                    (detailVal ? `- تفاصيل الطلب: ${detailVal}\n` : '') +
                    `- رابط الخدمة: ${window.location.href}`;
                  
                  window.open(`https://wa.me/213555000000?text=${encodeURIComponent(message)}`, '_blank');
                }}
                className="w-full text-xs font-bold gap-2 bg-[#25D366] hover:bg-[#128C7E] text-white py-2 border-0"
              >
                <MessageCircle className="w-4 h-4" />
                إرسال عرض السعر لـ واتساب البائع
              </Button>
            </div>
          )}

          {/* New v10 Trusted Deal Flow Core Payment / Verification Layer */}
          {!['وظائف', 'خدمات', 'عقارات'].includes(product.category) && (
            <div className="mb-6 bg-[#0E141C] border border-[#E0B15A]/30 rounded-3xl p-6 space-y-5 shadow-lg">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#E0B15A]" />
                  <h3 className="text-sm font-bold text-white">نظام ريادة للشراء الآمن والدفع الإلكتروني (v10)</h3>
                </div>
                <span className="bg-[#E0B15A]/10 text-[#E0B15A] text-[9px] px-2 py-0.5 rounded-full border border-[#E0B15A]/20">موصى به</span>
              </div>

              {!showOrderPanel && !createdOrder ? (
                <div className="space-y-3">
                  <p className="text-xs text-white/60 leading-relaxed font-normal">
                    احمِ أموالك من الاحتيال! استخدم نظام الشراء الموثق لتسجيل الطلبية وتتبع شحنها من مخازن البائع بالجزائر مع إمكانية الدفع المسبق الآمن.
                  </p>
                  <Button 
                    onClick={() => setShowOrderPanel(true)}
                    className="w-full bg-gradient-to-r from-[#E0B15A] to-[#C99A45] text-black border-0 font-bold text-xs py-3 rounded-xl hover:opacity-95 flex items-center justify-center gap-2"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    شراء بضمان ريادة الموثق (توليد الطلبية)
                  </Button>
                </div>
              ) : showOrderPanel && !createdOrder ? (
                <div className="space-y-4">
                  <div className="bg-[#070A0F] p-4 rounded-xl border border-white/5 space-y-3">
                    <span className="text-[10px] text-[#E0B15A] uppercase tracking-wider font-extrabold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      مؤشر الأمان ودرجة الخطورة التقديرية (Risk Score)
                    </span>
                    
                    {/* Calculation on fly */}
                    {(() => {
                      const score = calculatePrRiskScore(product.price, !!product.verified);
                      return (
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-white/60">مستوى الخطورة الإجمالي:</span>
                            <span className={`font-mono font-extrabold ${score > 55 ? 'text-red-400' : 'text-emerald-400'}`}>{score} / 100</span>
                          </div>
                          
                          {score > 55 ? (
                            <p className="text-[10px] text-red-300 leading-relaxed">
                              ⚠ تنبيه: بائع غير موثق بالكامل أو قيمة السلعة تفوق 10 آلاف دج. ننصح بالطلب والدفع نقداً عند معاينة السلعة مع شركة الشحن.
                            </p>
                          ) : (
                            <p className="text-[10px] text-emerald-400 leading-relaxed">
                              ✓ مؤشر ممتاز: البائع يتمتع بدرجة موثوقية جيدة. عملية الشراء محمية بالكامل بورقة تتبع رقمية.
                            </p>
                          )}
                        </div>
                      );
                    })()}
                  </div>

                  {/* Customer Checkout form */}
                  <div className="space-y-2.5">
                    <span className="text-xs text-white/50 block">املأ البيانات المناسبة للاستلام:</span>
                    <div className="grid grid-cols-2 gap-2">
                      <input 
                        type="text" 
                        placeholder="الاسم الكامل" 
                        value={buyerName}
                        onChange={e => setBuyerName(e.target.value)}
                        className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#E0B15A]/50"
                      />
                      <input 
                        type="tel" 
                        placeholder="الهاتف" 
                        value={buyerPhone}
                        onChange={e => setBuyerPhone(e.target.value)}
                        className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white text-left font-mono outline-none focus:border-[#E0B15A]/50"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <select 
                        value={buyerWilaya} 
                        onChange={e => setBuyerWilaya(e.target.value)}
                        className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
                      >
                        {ALGERIAN_WILAYAS.map(w => (
                          <option key={w.id} value={w.name}>{w.id} - {w.name}</option>
                        ))}
                      </select>
                      <input 
                        type="text" 
                        placeholder="العنوان السكني بالكامل" 
                        value={buyerAddress}
                        onChange={e => setBuyerAddress(e.target.value)}
                        className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#E0B15A]/50"
                      />
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button 
                        onClick={() => setShowOrderPanel(false)}
                        variant="secondary" 
                        className="flex-1 text-xs"
                      >
                        إلغاء التراجع
                      </Button>
                      <Button 
                        disabled={!buyerName || !buyerPhone || !buyerAddress || isPlacingOrder}
                        onClick={async () => {
                          setIsPlacingOrder(true);
                          try {
                            const newOrder = {
                              id: 'ORD-' + Math.floor(100000 + Math.random() * 900000),
                              workspaceId: product.workspaceId || activeWorkspace?.id || 'default_workspace',
                              customerId: 'CUST-' + Math.floor(1000 + Math.random() * 9000),
                              items: [{ productId: product.id, name: product.name, quantity: 1, price: product.price }],
                              total: product.price + 600,
                              deliveryFee: 600,
                              status: 'initiated', // v10 starter
                              wilaya: buyerWilaya,
                              address: buyerAddress,
                              notes: 'طلب مالي آمن من ريادة',
                              riskScore: calculatePrRiskScore(product.price, !!product.verified),
                            };

                            // Save to DB
                            await addItem('orders', newOrder);

                            // Save customer detail as well
                            const customerDoc = {
                              id: newOrder.customerId,
                              workspaceId: newOrder.workspaceId,
                              name: buyerName,
                              phone: buyerPhone,
                              blacklisted: false,
                              ordersCount: 1,
                              totalSpent: newOrder.total,
                            };
                            await addItem('customers', customerDoc);

                            setCreatedOrder(newOrder);
                            success('تحت الإجراء', 'تم تسجيل طلب الشراء الآمن بنجاح بنظام ريادة!');
                          } catch (err) {
                            console.error(err);
                            toastError('فشل', 'حدث خطأ غير متوقع أثناء توليد الطلب.');
                          } finally {
                            setIsPlacingOrder(false);
                          }
                        }}
                        className="flex-1 bg-[#E0B15A] hover:bg-[#E0B15A]/90 text-black border-0 text-xs font-bold"
                      >
                        {isPlacingOrder ? 'جاري المعالجة...' : 'تأكيد طلب التوريد آلياً'}
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Generated Order Display */}
                  <div className="bg-[#070A0F] p-4 rounded-xl border border-white/5 space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-white/40">رقم طلبية ريادة:</span>
                      <span className="font-mono text-[#E0B15A] font-bold">{createdOrder.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/40">حالة التحقق الحالية:</span>
                      <span className="font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-full border border-sky-500/10">
                        {createdOrder.status === 'initiated' ? 'في انتظار موافقة بائع ريادة' : 
                         createdOrder.status === 'seller_confirmed' ? 'مؤكدة - في مرحلة التحصيل المالي' : 
                         createdOrder.status === 'payment_pending' ? 'جاري التحقق من الحوالة CCP' : 
                         createdOrder.status === 'paid' ? 'مدفوعة ومقيدة بالكامل' : createdOrder.status}
                      </span>
                    </div>
                  </div>

                  {/* Flow Steps simulations */}
                  {createdOrder.status === 'initiated' && (
                    <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-2">
                      <span className="text-[10px] text-white/50 block">محاكاة واجهة البائع (اختصار للتجربة المحلية):</span>
                      <Button 
                        size="sm" 
                        onClick={() => {
                          const updated = { ...createdOrder, status: 'seller_confirmed' };
                          setCreatedOrder(updated);
                          success('تمت الموافقة', 'أكد البائع توفر البضاعة وحجزها في المستودع. توجه للدفع.');
                        }}
                        className="w-full text-[10px] bg-sky-500 hover:bg-sky-600 text-white font-bold h-8 border-0"
                      >
                        الموافقة الفورية وحجز البضاعة &larr;
                      </Button>
                    </div>
                  )}

                  {createdOrder.status === 'seller_confirmed' && (
                    <div className="space-y-3">
                      <span className="text-xs text-white/50 block font-medium">اختر طريقة دفع آمنة بالجزائر:</span>
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                          onClick={() => setPaymentMethod('chargily')}
                          className={`p-2.5 rounded-xl border text-right text-xs font-bold transition-all ${paymentMethod === 'chargily' ? 'border-[#E0B15A] bg-[#E0B15A]/10 text-white' : 'border-white/5 bg-[#070A0F] text-white/60'}`}
                        >
                          💳 بوابة Chargily (CIB/الذهبية)
                        </button>
                        <button 
                          onClick={() => setPaymentMethod('ccp')}
                          className={`p-2.5 rounded-xl border text-right text-xs font-bold transition-all ${paymentMethod === 'ccp' ? 'border-[#E0B15A] bg-[#E0B15A]/10 text-white' : 'border-white/5 bg-[#070A0F] text-white/60'}`}
                        >
                          📬 حوالة بريدية CCP / بريدي موب
                        </button>
                      </div>

                      {paymentMethod === 'chargily' ? (
                        <div className="bg-[#070A0F] p-4 rounded-xl border border-[#E0B15A]/20 space-y-3 text-center">
                          <div className="flex justify-center space-x-1">
                            <span className="bg-[#E0B15A]/10 text-[#E0B15A] px-2 py-0.5 rounded text-[9px] font-bold">بوابة آمنة V2</span>
                            <span className="bg-[#18C29C]/10 text-[#18C29C]/90 px-2 py-0.5 rounded text-[9px] font-bold">الدفع الإلكتروني</span>
                          </div>
                          <p className="text-[10px] text-white/55 leading-relaxed">
                            سيتم توجيهك الآن إلى صفحة الدفع الرسمية والمشفرة لشركة <span className="text-[#E0B15A] font-semibold">Chargily Pay</span> لتسديد حساب المشتريات بشكل آمن تماماً عبر بطاقة الذهبية أو CIB.
                          </p>
                          <Button 
                            disabled={isPaying}
                            onClick={async () => {
                              setIsPaying(true);
                              try {
                                const checkoutSession = await API.payments.createCheckout(
                                  createdOrder.id,
                                  createdOrder.total
                                );
                                
                                // Update status to reflect initiated stage
                                const updated = { 
                                  ...createdOrder, 
                                  status: 'payment_pending', 
                                  paymentStatus: 'PAYMENT_INITIATED', 
                                  paymentMethod: 'chargily' 
                                };
                                setCreatedOrder(updated);
                                
                                success('جاري تحضير البوابة الـV2 الآمنة', 'جاري توجيهك الآن لإنهاء المعاملة وحماية مستحقاتك.');
                                
                                setTimeout(() => {
                                  window.location.href = checkoutSession.checkout_url;
                                }, 1500);
                              } catch (err: any) {
                                toastError('خطأ تقني في بوابة الدفع', err.message || 'تعذر الاتصال بقم خادم معالجة الدفع حالياً.');
                              } finally {
                                setIsPaying(false);
                              }
                            }}
                            className="w-full bg-[#18C29C] hover:bg-[#18C29C]/90 text-black border-0 font-bold text-xs h-9"
                          >
                            {isPaying ? <Loader2 className="w-4 h-4 animate-spin mx-auto text-black" /> : 'الانتقال الآمن لصفحة الدفع المشفرة 💳'}
                          </Button>
                        </div>
                      ) : (
                        <div className="bg-[#070A0F] p-4 rounded-xl border border-white/10 space-y-3">
                          <span className="text-[10px] text-white/50 block">حوالة CCP / بريدي موب المباشرة:</span>
                          <p className="text-[10px] text-white/40 leading-relaxed">
                            أرسل المبلغ المقدر بـ <span className="font-bold text-white">{formatDZD(createdOrder.total)}</span> للحساب البريدي التالي:<br />
                            <span className="font-mono text-white text-xs block bg-white/5 p-1 rounded text-center mt-1">CCP: 0021943821 / المفتاح: 45</span>
                          </p>
                          <div className="space-y-2">
                            <input 
                              type="text" 
                              placeholder="أدخل رقم الوصل البريدي أو مرجع العملية"
                              value={txRef}
                              onChange={e => setTxRef(e.target.value)}
                              className="w-full bg-[#0E141C] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder-white/30 text-center font-mono focus:border-[#E0B15A]"
                            />
                            {/* Simple simulated uploader */}
                            <div className="flex items-center justify-between border border-dashed border-white/10 rounded-xl p-2 bg-[#0E141C]">
                              <span className="text-[10px] text-white/40">إرفاق صورة الوصل البريدي:</span>
                              <label className="cursor-pointer bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded text-[10px] text-white font-medium border border-white/5">
                                <Upload className="w-3 h-3 inline-block me-1" />
                                رفع
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  className="hidden" 
                                  onChange={e => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onloadend = () => {
                                        setReceiptFileB64(reader.result as string);
                                        success('تم الرفع', 'تم فحص وإرفاق وصل CCP بنجاح.');
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  }} 
                                />
                              </label>
                            </div>
                            {receiptFileB64 && (
                              <div className="text-[9px] text-[#18C29C] font-semibold">✓ تم تجهيز الصورة للتحقق بنجاح.</div>
                            )}
                            <Button
                              disabled={!txRef}
                              onClick={() => {
                                const updated = { ...createdOrder, status: 'payment_pending', paymentMethod: 'ccp', transactionReference: txRef, receiptImage: receiptFileB64 };
                                setCreatedOrder(updated);
                                success('تم الإرسال للتحقق', 'تم رفع الوصل بنجاح تمهيداً لتدوين وتأكيد المعاملة.');
                              }}
                              className="w-full text-xs font-bold"
                            >
                              إرسال طلب التحقق من CCP للبائع
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {createdOrder.status === 'payment_pending' && (
                    <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-2 text-center text-xs">
                      <p className="text-white/60">تم إرسال تدوينات CCP للبائع للتحقق والمراجعة اليدوية.</p>
                      <Button 
                        size="sm"
                        onClick={() => {
                          const updated = { ...createdOrder, status: 'paid' };
                          setCreatedOrder(updated);
                          success('تم التوثيق والتحصيل', 'تم قبول دفعة CCP بنجاح واكتملت الدورة الاقتصادية للسلعة.');
                        }}
                        className="w-full bg-[#18C29C] text-black font-bold text-[10px] h-8 border-0 mt-1"
                      >
                         تأكيد تدوين واستلام المبلغ مالي مسبق
                      </Button>
                    </div>
                  )}

                  {createdOrder.status === 'paid' && (
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-3">
                      <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                        <CheckCircle2 className="w-4 h-4" />
                        طلبية آمنة ومدفوعة بالكامل!
                      </div>
                      <p className="text-[10px] text-white/50 leading-relaxed">
                        شكراً لك! ريادة قامت بتوثيق المعاملة مالي ومستندياً. مراجع العملية: {createdOrder.transactionReference}. جاري تجهيز الشحن مع بائع ريادة.
                      </p>
                    </div>
                  )}

                  <Button 
                    variant="secondary" 
                    size="sm"
                    onClick={() => {
                      setCreatedOrder(null);
                      setShowOrderPanel(false);
                    }}
                    className="w-full text-[10px] py-1.5 h-8 text-white/40"
                  >
                    إلغاء وتفريغ المعاملة الحالية
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* New v11 Core Internal Market Communication System */}
          <div className="mb-6 bg-[#0E141C] border border-brand-500/20 rounded-3xl p-6 space-y-4 shadow-lg">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-brand-400" />
                <h3 className="text-sm font-bold text-white">تفاوض وتواصل آمن ومباشر (v11)</h3>
              </div>
              <span className="bg-brand-500/10 text-brand-400 text-[9px] px-2 py-0.5 rounded-full border border-brand-500/20">داخل المنصة</span>
            </div>

            {commType === 'none' ? (
              <div className="space-y-4">
                <p className="text-xs text-white/50 leading-relaxed font-normal">
                  لا حاجة للذهاب لواتساب فوراً! اختر أحد الإجراءات المباشرة للتواصل والحصول على حماية إبرام الصفقات وحفظ عروض الأسعار داخل ريادة.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => {
                      setCommType('negotiate');
                      setCommMessage('أود التفاوض المباشر حول سعر السلعة وتقليص القيمة المناسبة للاستلام.');
                      setCommPrice(Math.round(product.price * 0.9).toString());
                    }}
                    className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl text-center text-xs text-white font-bold transition-all flex flex-col items-center justify-center gap-1.5"
                  >
                    <ArrowLeftRight className="w-4 h-4 text-brand-400" />
                    تفاوض على السعر
                  </button>
                  <button 
                    onClick={() => {
                      setCommType('offer');
                      setCommMessage('يسرني تقديم عرض مالي رسمي لشراء المنتج فوراً.');
                      setCommPrice(product.price.toString());
                    }}
                    className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl text-center text-xs text-white font-bold transition-all flex flex-col items-center justify-center gap-1.5"
                  >
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                    إرسال عرض سعر
                  </button>
                  <button 
                    onClick={() => {
                      setCommType('deal');
                      setCommMessage('أريد طلب حجز رسمي وقفل صفقة متكاملة بانتظار الشحن.');
                    }}
                    className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl text-center text-xs text-white font-bold transition-all flex flex-col items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-sky-400" />
                    طلب حجز صفقة
                  </button>
                  <button 
                    onClick={() => {
                      setCommType('avail');
                      setCommMessage('مرحباً بائع ريادة، هل السلعة متوفرة حالياً للتجهيز الفوري؟');
                    }}
                    className="p-3 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl text-center text-xs text-white font-bold transition-all flex flex-col items-center justify-center gap-1.5"
                  >
                    <Clock className="w-4 h-4 text-purple-400" />
                    استفسار عن التوفر
                  </button>
                </div>
              </div>
            ) : sentCommSuccess ? (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl space-y-3 text-center">
                <CheckCircle2 className="w-8 h-8 text-[#18C29C] mx-auto" />
                <h4 className="text-xs font-bold text-white">تم إرسال المفاوضة والطلب بنجاح!</h4>
                <p className="text-[10px] text-white/50 leading-relaxed max-w-xs mx-auto">
                  تم تسجيل عرضك ومراسلتك في صندوق المحادثات والصفقات للبائع بانتظار رده المباشر وتقديم عروض مقابلة أو الموافقة.
                </p>
                <Button 
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setSentCommSuccess(false);
                    setCommType('none');
                    setCommName('');
                    setCommPhone('');
                    setCommMessage('');
                    setCommPrice('');
                  }}
                  className="w-full text-[10px]"
                >
                  إرسال مراسلة جديدة أخرى
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="bg-[#070A0F] p-3 rounded-xl border border-white/5 text-[11px] text-brand-400 flex justify-between items-center">
                  <span>الإجراء المحدد: {
                    commType === 'negotiate' ? 'تفاوض على السعر' : 
                    commType === 'offer' ? 'إرسال عرض سعر ملزم' :
                    commType === 'deal' ? 'طلب حجز صفقة' : 'استفسار عن تيسير التوفر'
                  }</span>
                  <button onClick={() => setCommType('none')} className="text-white/40 hover:text-white">&times; تراجع</button>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <input 
                      type="text" 
                      placeholder="اسمك الكامل" 
                      value={commName}
                      onChange={e => setCommName(e.target.value)}
                      className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50"
                    />
                    <input 
                      type="tel" 
                      placeholder="رقم الهاتف (لتأكيد الصفقة)" 
                      value={commPhone}
                      onChange={e => setCommPhone(e.target.value)}
                      className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white text-left font-mono outline-none focus:border-brand-500/50"
                    />
                  </div>

                  {['negotiate', 'offer'].includes(commType) && (
                    <div className="space-y-1">
                      <label className="text-[10px] text-white/40">السعر الذي تقترحه (دج):</label>
                      <input 
                        type="number" 
                        placeholder="مثال: 4500" 
                        value={commPrice}
                        onChange={e => setCommPrice(e.target.value)}
                        className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white text-center font-mono outline-none focus:border-brand-500/50"
                      />
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-[10px] text-white/40">رسالتك للبائع:</label>
                    <textarea 
                      rows={2.5}
                      placeholder="اكتب رسالتك أو استفسارك هنا تفصيلاً..."
                      value={commMessage}
                      onChange={e => setCommMessage(e.target.value)}
                      className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-xs text-white resize-none outline-none focus:border-brand-500/50"
                    />
                  </div>

                  <div className="flex gap-2 pt-1">
                    <Button 
                      onClick={() => setCommType('none')}
                      variant="secondary"
                      className="flex-1 text-xs"
                    >
                      إلغاء
                    </Button>
                    <Button 
                      disabled={!commName || !commPhone || !commMessage || isSendingComm}
                      onClick={async () => {
                        setIsSendingComm(true);
                        try {
                          // Write negotiation thread
                          createNegotiationThread(
                            product.id,
                            product.name,
                            product.price,
                            product.image,
                            product.workspaceId || 'default_workspace',
                            commName,
                            commPhone,
                            commMessage,
                            commPrice ? Number(commPrice) : undefined
                          );
                          success('تم الإرسال الرقمي', 'تم تسجيل عرضك للتفاوض في نظام ريادة الداخلي للبائع للتواصل!');
                          setSentCommSuccess(true);
                        } catch (err) {
                          console.error(err);
                          toastError('فشل', 'حدث خطأ غير متوقع أثناء إرسال العرض.');
                        } finally {
                          setIsSendingComm(false);
                        }
                      }}
                      className="flex-1 bg-brand-500 hover:bg-brand-600 text-[#05070a] text-xs font-bold border-0"
                    >
                      {isSendingComm ? 'جاري الإرسال...' : 'تأكيد الإرسال للبائع'}
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-auto space-y-4 bg-white/5 border border-white/10 rounded-2xl p-5">
            <h4 className="text-sm font-bold text-white mb-3">
              {['وظائف', 'خدمات', 'عقارات'].includes(product.category) ? 'للاستفسار أو الطلب، تواصل مباشرة مع المُعلن:' : 'للطلب أو الاستفسار، تواصل مباشرة مع البائع:'}
            </h4>
            
            <Button 
              className="w-full h-12 text-base gap-3 bg-[#25D366] hover:bg-[#128C7E] text-white border-0 shadow-[0_0_20px_rgba(37,211,102,0.3)] hover:scale-[1.02] transition-transform"
              onClick={handleWhatsApp}
            >
              <MessageCircle className="w-5 h-5" />
              {product.category === 'خدمات' ? 'تواصل لحجز من واتساب' : product.category === 'وظائف' ? 'تواصل للتقديم للوظيفة' : product.category === 'عقارات' ? 'تواصل لطلب معاينة' : 'تواصل وتأكيد عبر واتساب'}
            </Button>
            
            <p className="text-xs text-white/40 text-center flex items-center justify-center gap-1 mt-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              معاملتك آمنة. تأكد من تفاصيل التوصيل قبل الدفع.
            </p>

            <button
              onClick={() => setShowReport(true)}
              className="w-full mt-4 text-xs text-red-400 hover:text-red-300 transition-colors flex items-center justify-center gap-1"
            >
              الإبلاغ عن إساءة / منتج مخالف
            </button>
          </div>
        </div>

        {/* Vendor Sidebar */}
        <div className="md:col-span-12 lg:col-span-3 space-y-4">
          <Card className="p-5 flex flex-col items-center text-center bg-gradient-to-b from-white/5 to-transparent">
            <div className="w-16 h-16 bg-brand-500/10 rounded-2xl flex items-center justify-center mb-3 border border-brand-500/20">
              <Store className="w-8 h-8 text-brand-400" />
            </div>
            <h3 className="font-bold text-white flex items-center gap-2 justify-center mb-1">
              {product.vendorName || 'متجر التميز التقني'}
              <TrustBadge />
            </h3>
            <p className="text-xs text-white/50 mb-4 flex items-center justify-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {product.wilaya}
            </p>
            <Button variant="secondary" className="w-full text-sm" onClick={() => navigate('/store/1')}>
              زيارة واجهة المتجر
            </Button>
          </Card>

          <Card className="p-4 space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-white/5 pb-2">معلومات التوصيل</h4>
            <div className="flex items-start gap-3 text-sm">
              <Truck className="w-4 h-4 text-white/40 shrink-0 mt-0.5" />
              <p className="text-white/70 text-xs leading-relaxed">التوصيل متوفر لـ 58 ولاية (يلد يلد، كازيتور).</p>
            </div>
            <div className="flex items-start gap-3 text-sm">
              <CreditCard className="w-4 h-4 text-white/40 shrink-0 mt-0.5" />
              <p className="text-white/70 text-xs leading-relaxed">الدفع عند الاستلام كاش.</p>
            </div>
          </Card>
        </div>
      </div>
      
      <QRCodeModal 
        isOpen={showQR} 
        onClose={() => setShowQR(false)} 
        url={window.location.href} 
        title={product.name} 
      />

      <ReportModal
        isOpen={showReport}
        onClose={() => setShowReport(false)}
        targetId={product.id}
        targetType="product"
      />
    </div>
  );
}
