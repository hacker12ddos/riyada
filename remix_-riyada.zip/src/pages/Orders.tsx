import React, { useState, useEffect } from 'react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Search, Filter, ShoppingCart, Plus, X, User, MapPin, ClipboardList, ShieldAlert, Phone, ThumbsUp, Check, RefreshCw, Upload, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';
import { getItemsByWorkspace, Order, Customer, addItem, getAllItems } from '../lib/db';
import { formatDZD } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from '../contexts/ToastContext';
import { evaluateOrderFraudRisk } from '../lib/security';

export default function Orders() {
  const { activeWorkspace } = useWorkspace();
  const { success, error: toastError } = useToast();
  const [orders, setOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Selection State (CRM + Status update)
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [editedNotes, setEditedNotes] = useState('');
  
  // Payment Coordination States
  const [paymentStatus, setPaymentStatus] = useState<string>('awaiting_payment');
  const [paymentMethod, setPaymentMethod] = useState<string>('cash');
  const [paymentTxId, setPaymentTxId] = useState<string>('');
  const [paymentProofFile, setPaymentProofFile] = useState<string>('');
  const [verifiedBySeller, setVerifiedBySeller] = useState<boolean>(false);
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [wilaya, setWilaya] = useState('الجزائر');
  const [address, setAddress] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  const [notes, setNotes] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (activeWorkspace) {
      loadOrders();
      loadProducts();
    }
  }, [activeWorkspace]);

  const loadProducts = async () => {
    try {
      if (!activeWorkspace) return;
      const items = await getItemsByWorkspace('products', activeWorkspace.id);
      setProducts(items || []);
      if (items && items.length > 0) {
        setSelectedProductId(items[0].id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadOrders = async () => {
    if (!activeWorkspace) return;
    setIsLoading(true);
    try {
      const dbOrders = await getItemsByWorkspace('orders', activeWorkspace.id);
      const dbCustomers = await getItemsByWorkspace('customers', activeWorkspace.id);
      setCustomers(dbCustomers || []);
      
      const enriched = dbOrders.map(order => {
        const customer = dbCustomers.find(c => c.id === order.customerId);
        // Find other orders for this customer to detect repeat buyers
        const pastOrders = dbOrders.filter(o => o.customerId === order.customerId && o.id !== order.id);
        
        return {
          ...order,
          customerName: customer ? customer.name : 'عميل غير مسجل',
          phone: customer ? customer.phone : 'لا يوجد',
          isBlacklisted: customer ? customer.blacklisted : false,
          pastOrdersCount: pastOrders.length,
          itemsCount: Array.isArray(order.items) ? order.items.reduce((sum, item) => sum + item.quantity, 0) : 0
        };
      });
      
      // Sort newest first
      enriched.sort((a, b) => b.createdAt - a.createdAt);
      setOrders(enriched);

      // Keep selection up-to-date
      if (selectedOrder) {
        const updated = enriched.find(o => o.id === selectedOrder.id);
        if (updated) setSelectedOrder(updated);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !selectedProductId) {
      toastError('خطأ', 'يرجى تسجيل متجر وإضافة سلع أولاً لتتمكن من إنشاء طلبات.');
      return;
    }

    setIsSaving(true);
    try {
      const product = products.find(p => p.id === selectedProductId);
      if (!product) throw new Error('Product not found');

      const deliveryFee = wilaya === 'الجزائر' ? 400 : 800;
      const orderTotal = (product.price * quantity) + deliveryFee;

      // 1. Manage/Create the Customer in IndexedDB CRM
      const existingCustomers = await getItemsByWorkspace('customers', activeWorkspace.id);
      let customer = existingCustomers.find(c => c.phone === phone);
      
      if (!customer) {
        customer = {
          id: crypto.randomUUID(),
          workspaceId: activeWorkspace.id,
          name: customerName,
          phone: phone,
          blacklisted: false,
          ordersCount: 1,
          totalSpent: orderTotal,
          createdAt: Date.now()
        };
        await addItem('customers', customer);
      } else {
        // Update customer statistics
        customer.ordersCount += 1;
        customer.totalSpent += orderTotal;
        await addItem('customers', customer);
      }

      // 2. Add Order to IndexedDB
      const newOrderObj: Order = {
        id: 'R-' + Math.floor(100000 + Math.random() * 900000), // Algerian Order Prefix
        workspaceId: activeWorkspace.id,
        customerId: customer.id,
        items: [
          {
            productId: product.id,
            name: product.name,
            quantity: quantity,
            price: product.price
          }
        ],
        total: orderTotal,
        deliveryFee: deliveryFee,
        status: 'pending',
        wilaya: wilaya,
        address: address,
        notes: notes,
        createdAt: Date.now()
      };

      await addItem('orders', newOrderObj);
      success('تم الحفظ', 'تم تسجيل طلبية العميل بنجاح وتحديث قاعدة بيانات العملاء.');
      
      // Reset state & load orders
      setIsModalOpen(false);
      setCustomerName('');
      setPhone('');
      setAddress('');
      setNotes('');
      setQuantity(1);
      
      loadOrders();
    } catch (e) {
      console.error(e);
      toastError('فشل الحفظ', 'حدث خطأ أثناء حفظ الطلبية.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateStatus = async (newStatus: Order['status'] | 'preparing' | 'refused' | 'waiting') => {
    if (!selectedOrder || !activeWorkspace) return;
    setUpdatingStatus(true);
    try {
      const dbOrders = await getItemsByWorkspace('orders', activeWorkspace.id);
      const target = dbOrders.find(o => o.id === selectedOrder.id);
      if (target) {
        target.status = newStatus as any;
        await addItem('orders', target);
        success('تم التحديث', `تم تعديل حالة الطلب بنجاح إلى: ${getStatusText(newStatus)}`);
        await loadOrders();
      }
    } catch (e) {
      console.error(e);
      toastError('خطأ', 'فشل في تحديث حالة الطلب.');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleUpdateNotesAndCRM = async () => {
    if (!selectedOrder || !activeWorkspace) return;
    try {
      // 1. Update Order Notes & Payments
      const dbOrders = await getItemsByWorkspace('orders', activeWorkspace.id);
      const targetO = dbOrders.find(o => o.id === selectedOrder.id);
      if (targetO) {
        targetO.notes = editedNotes;
        targetO.paymentStatus = paymentStatus;
        targetO.paymentMethod = paymentMethod;
        targetO.paymentTxId = paymentTxId;
        targetO.paymentProofFile = paymentProofFile;
        targetO.verifiedBySeller = verifiedBySeller;
        await addItem('orders', targetO);
      }

      success('تم الحفظ', 'تم تحديث البيانات والملاحظات وحالة دفع الطلب بنجاح.');
      await loadOrders();
    } catch (e) {
      console.error(e);
      toastError('خطأ', 'فشل تحديث البيانات.');
    }
  };

  const toggleCustomerBlacklist = async () => {
    if (!selectedOrder || !activeWorkspace) return;
    try {
      const dbCustomers = await getItemsByWorkspace('customers', activeWorkspace.id);
      const targetC = dbCustomers.find(c => c.id === selectedOrder.customerId);
      if (targetC) {
        targetC.blacklisted = !targetC.blacklisted;
        await addItem('customers', targetC);
        success('تم التعديل', targetC.blacklisted ? 'تم إدراج العميل في القائمة السوداء للمتجر.' : 'تم إلغاء حظر العميل.');
        await loadOrders();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-orange-500/10 text-orange-400 border-orange-500/20';
      case 'waiting': return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      case 'confirmed': return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'preparing': return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
      case 'shipped': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'delivered': return 'bg-[#18C29C]/10 text-[#18C29C] border-[#18C29C]/20';
      case 'cancelled': return 'bg-red-500/10 text-red-400 border-red-500/20';
      case 'refused': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      default: return 'bg-white/10 text-white/50 border-white/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'قيد الانتظار';
      case 'waiting': return 'في قائمة الانتظار';
      case 'confirmed': return 'مؤكد من الزبون';
      case 'preparing': return 'قيد التجهيز بمخزنك';
      case 'shipped': return 'في الطريق مع التوصيل';
      case 'delivered': return 'تم التسليم والتحصيل';
      case 'cancelled': return 'ملغى من الشاري';
      case 'refused': return 'مرفوض الاستلام / مرتجع';
      default: return status;
    }
  };

  const activeCustomer = selectedOrder ? customers.find(c => c.id === selectedOrder.customerId) || null : null;
  const customerHistory = selectedOrder ? orders.filter(o => o.customerId === selectedOrder.customerId) : [];
  const fraudResult = selectedOrder ? evaluateOrderFraudRisk(selectedOrder, customerHistory) : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">إدارة طلبيات المتجر ومتابعة الزبائن</h1>
          <p className="text-white/50 text-sm">تتبع حالات التوصيل بالكامل محلياً مع تصنيف الزبائن الأوفياء والتحذير من المرتجع.</p>
        </div>
        <Button className="shrink-0 gap-2 font-medium" onClick={() => setIsModalOpen(true)}>
          <Plus className="w-4 h-4" />
          <span>تسجيل طلبية جديدة</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Table View */}
        <div className={selectedOrder ? "lg:col-span-7" : "lg:col-span-12"}>
          <Card className="p-4 bg-[#0E141C] border border-white/10">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <Input 
                placeholder="البحث برقم الطلب أو العميل..." 
                icon={<Search className="w-4 h-4" />}
                className="md:max-w-xs focus:bg-[#070A0F] bg-[#070A0F]"
              />
              <Button variant="secondary" className="gap-2 shrink-0 md:ms-auto text-xs" onClick={loadOrders}>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>مزامنة وتحديث</span>
              </Button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm text-white/70">
                <thead className="text-xs text-white/30 border-b border-white/5 bg-[#0a0f18]/30">
                  <tr className="h-10">
                    <th className="px-4 py-2 font-medium">رقم الطلب</th>
                    <th className="px-4 py-2 font-medium">العميل</th>
                    <th className="px-4 py-2 font-medium">الولاية</th>
                    <th className="px-4 py-2 font-medium text-left">المبلغ الإجمالي</th>
                    <th className="px-4 py-2 font-medium text-center">الحالة</th>
                  </tr>
                </thead>
                <tbody className="text-xs">
                  {isLoading ? (
                    <tr>
                      <td colSpan={5} className="text-center py-8">جاري التحميل...</td>
                    </tr>
                  ) : orders.map((order, idx) => (
                    <motion.tr 
                      key={order.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.03 }}
                      onClick={() => {
                        setSelectedOrder(order);
                        setEditedNotes(order.notes || '');
                        setPaymentStatus(order.paymentStatus || 'awaiting_payment');
                        setPaymentMethod(order.paymentMethod || 'cash');
                        setPaymentTxId(order.paymentTxId || '');
                        setPaymentProofFile(order.paymentProofFile || '');
                        setVerifiedBySeller(order.verifiedBySeller || false);
                      }}
                      className={`border-b border-white/5 h-16 hover:bg-white/5 cursor-pointer transition-colors ${selectedOrder?.id === order.id ? 'bg-white/5 border-l-2 border-l-[#18C29C]' : ''}`}
                    >
                      <td className="px-4 font-bold text-white font-mono">{order.id}</td>
                      <td className="px-4">
                        <div className="flex flex-col">
                          <span className="font-semibold text-white/95 flex items-center gap-1">
                            {order.customerName}
                            {order.pastOrdersCount > 0 && (
                              <span className="bg-[#E0B15A]/10 text-[#E0B15A] text-[9px] px-1.5 py-0.2 rounded border border-[#E0B15A]/20">
                                زبون وفي ({order.pastOrdersCount + 1})
                              </span>
                            )}
                            {order.isBlacklisted && (
                              <span className="bg-red-500/10 text-red-400 text-[9px] px-1.5 py-0.2 rounded border border-red-500/20">
                                محظور
                              </span>
                            )}
                          </span>
                          <span className="text-[10px] text-white/50 font-mono">{order.phone}</span>
                        </div>
                      </td>
                      <td className="px-4">
                        <span>{order.wilaya}</span>
                      </td>
                      <td className="px-4 font-mono text-[#18C29C] font-bold text-left">
                        {formatDZD(order.total)}
                      </td>
                      <td className="px-4 text-center">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded border text-[10px] ${getStatusColor(order.status)}`}>
                          {getStatusText(order.status)}
                        </span>
                      </td>
                    </motion.tr>
                  ))}
                  {orders.length === 0 && !isLoading && (
                    <tr>
                      <td colSpan={5} className="text-center py-16">
                        <div className="flex flex-col items-center justify-center max-w-md mx-auto">
                          <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center border border-white/10 mb-4 text-white/40">
                            <ClipboardList className="w-6 h-6" />
                          </div>
                          <h4 className="text-white font-medium text-base mb-1">لا توجد طلبات</h4>
                          <p className="text-white/50 text-xs text-center leading-relaxed mb-4">
                            عندما يتواصل معك العملاء لتأكيد الشراء عبر الواتساب أو الهاتف، يمكنك النقر على "تسجيل طلبية جديدة" وتوثيق الطلبيات لتتبع حالات التوصيل والأرباح بشكل منظم.
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Dynamic CRM & States Control Panel */}
        {selectedOrder && (
          <div className="lg:col-span-5">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-[#151C26] border border-white/10 p-5 rounded-2xl space-y-5 sticky top-24"
            >
              <div className="flex justify-between items-start pb-2 border-b border-white/5">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    تفاصيل الطلب: <span className="font-mono text-[#18C29C]">{selectedOrder.id}</span>
                  </h3>
                  <span className="text-[10px] text-white/40 font-mono">
                    {new Date(selectedOrder.createdAt).toLocaleString('ar-DZ')}
                  </span>
                </div>
                <button 
                  onClick={() => setSelectedOrder(null)}
                  className="p-1 rounded bg-white/5 text-white/50 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Status Manager Control */}
              <div className="space-y-2">
                <span className="text-xs text-white/50 block font-medium">حالة الطلبية الفعّالة:</span>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'pending', label: 'قيد الانتظار' },
                    { key: 'waiting', label: 'قائمة انتظار' },
                    { key: 'confirmed', label: 'مؤكد من الزبون' },
                    { key: 'preparing', label: 'تجهيز بمخزنك' },
                    { key: 'shipped', label: 'خرج مع الموصل' },
                    { key: 'delivered', label: 'مستلم ومدفوع' },
                    { key: 'cancelled', label: 'ملغي من الزبون' },
                    { key: 'refused', label: 'مرتجع / مرفوض' }
                  ].map(stateDoc => (
                    <button
                      key={stateDoc.key}
                      onClick={() => handleUpdateStatus(stateDoc.key as any)}
                      disabled={updatingStatus}
                      className={`text-right px-3 py-2 rounded-lg border text-[11px] font-semibold transition-colors flex items-center justify-between ${
                        selectedOrder.status === stateDoc.key 
                          ? 'bg-[#18C29C]/10 text-[#18C29C] border-[#18C29C]'
                          : 'bg-[#0E141C] text-white/70 border-white/5 hover:border-white/10'
                      }`}
                    >
                      <span>{stateDoc.label}</span>
                      {selectedOrder.status === stateDoc.key && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Customer CRM details */}
              <div className="bg-[#0e141c] p-4 rounded-xl border border-white/5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-white/50">بيانات زبون ريادة:</span>
                  <button 
                    onClick={toggleCustomerBlacklist}
                    className={`text-[10px] px-2 py-0.5 rounded border transition-colors ${
                      selectedOrder.isBlacklisted 
                        ? 'bg-red-500/20 text-red-400 border-red-500/30'
                        : 'bg-white/5 text-white/40 border-white/10 hover:text-white'
                    }`}
                  >
                    {selectedOrder.isBlacklisted ? 'إلغاء الحظر' : 'حظر العميل (القائمة السوداء)'}
                  </button>
                </div>

                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-white">{selectedOrder.customerName}</h4>
                  <div className="flex items-center gap-1 text-[11px] font-mono text-white/60">
                    <Phone className="w-3.5 h-3.5 text-white/40" />
                    <span>{selectedOrder.phone}</span>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] text-white/60">
                    <MapPin className="w-3.5 h-3.5 text-white/40" />
                    <span>{selectedOrder.wilaya} — {selectedOrder.address}</span>
                  </div>
                </div>

                {/* Shopping items */}
                <div className="border-t border-white/5 pt-3 mt-2">
                  <span className="text-[10px] text-white/40 block mb-1.5">السلع المطلوبة والمبالغ:</span>
                  {selectedOrder.items?.map((item: any, i: number) => (
                    <div key={i} className="flex justify-between text-xs text-white/80">
                      <span>{item.name} (x{item.quantity})</span>
                      <span className="font-mono">{formatDZD(item.price * item.quantity)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-xs text-white/50 mt-1">
                    <span>مصاريف التوصيل المقدرة</span>
                    <span className="font-mono">{formatDZD(selectedOrder.deliveryFee)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-[#18C29C] border-t border-white/5 pt-2 mt-2">
                    <span>الإجمالي الكلي للتحصيل:</span>
                    <span className="font-mono">{formatDZD(selectedOrder.total)}</span>
                  </div>
                </div>
              </div>

              {/* 2. SECURITY RISK ASSESSMENT (FRAUD DISCOVERY) */}
              {fraudResult && (
                <div className={`p-4 rounded-xl border flex flex-col gap-2 ${
                  fraudResult.riskState === 'High Risk' 
                    ? 'bg-rose-500/10 border-rose-500/20 text-rose-300' 
                    : fraudResult.riskState === 'Suspicious' 
                      ? 'bg-orange-500/10 border-orange-500/20 text-[#18C29C]'
                      : fraudResult.riskState === 'Moderate'
                        ? 'bg-amber-500/10 border-amber-500/20 text-[#E0B15A]'
                        : 'bg-[#18C29C]/10 border-[#18C29C]/20 text-emerald-400'
                }`}>
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      مؤشر الأمان ومكافحة الاحتيال:
                    </span>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full uppercase bg-black/40">
                      {fraudResult.riskState === 'High Risk' ? 'عالي الخطورة ⚠' : fraudResult.riskState === 'Suspicious' ? 'مشبوه' : fraudResult.riskState === 'Moderate' ? 'متوسط الخطورة' : 'آمن وموثوق ✓'}
                    </span>
                  </div>
                  <div className="text-[11px] text-white/70 space-y-1">
                    {fraudResult.factors.map((r: string, idx: number) => (
                      <p key={idx}>• {r}</p>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. PAYMENT COORDINATION PANEL (RIYADA BOUNTY ENGINE) */}
              <div className="bg-[#0e141c] p-4 rounded-xl border border-white/5 space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-500" />
                    <span>تنسيق ومتابعة المدفوعات (عضوي)</span>
                  </h4>
                  <span className="text-[10px] text-white/40">بريد الجزائر / الدفع باليد</span>
                </div>

                <div className="grid grid-cols-2 gap-3.5">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 block">وسيلة الدفع المتفق عليها:</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full bg-[#151C26] border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none"
                    >
                      <option value="cash">الدفع نقداً عند الاستلام (COD)</option>
                      <option value="ccp">حوالة بريد الجزائر (CCP)</option>
                      <option value="baridimob">تطبيق بريدي موب (BaridiMob)</option>
                      <option value="cib">شحن بطاقة ذهبية / بنكية (CIB)</option>
                      <option value="delivery_cash">تسليم يد بيد للموصل</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-white/50 block">حالة التحصيل الفعلي:</label>
                    <select
                      value={paymentStatus}
                      onChange={(e) => setPaymentStatus(e.target.value)}
                      className="w-full bg-[#151C26] border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none"
                    >
                      <option value="awaiting_payment">قيد انتظار التحويل ⏳</option>
                      <option value="payment_submitted">تم إرسال الإشعار من الزبون 📤</option>
                      <option value="seller_reviewing">بانتظار التحقق من كشف الحساب 🔎</option>
                      <option value="payment_accepted">مكتمل ومستلم بالكامل ✓</option>
                      <option value="disputed">مرفوض / خلاف على المبلغ ⚠</option>
                      <option value="canceled">ملغى ✕</option>
                    </select>
                  </div>
                </div>

                {/* Warning banners depending on selected payment type */}
                {(paymentMethod === 'ccp' || paymentMethod === 'baridimob') && (
                  <div className="bg-amber-500/10 border border-amber-500/20 text-amber-200 p-2.5 rounded-lg text-[10px] leading-relaxed flex gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <p>
                      <strong>تحذير هام لبريد الجزائر:</strong> تأكد دائماً يدوياً عبر تطبيق ECCP أو بريدي موب الرسمي. لا ترسل المنتجات استناداً إلى لقطات الشاشة المرفقة فقط، حيث يسهل تزويرها رقمياً!
                    </p>
                  </div>
                )}

                {/* Transaction reference ID with collision detector */}
                <div className="space-y-1.5">
                  <div className="flex justify-between">
                    <label className="text-[10px] text-white/50">رقم الحوالة أو مرجع المعاملة TXID:</label>
                    {paymentTxId && orders.some(o => o.id !== selectedOrder.id && o.paymentTxId === paymentTxId) && (
                      <span className="text-[9px] text-red-400 font-bold">⚠️ الرمز مكرر بمبيعات أخرى!</span>
                    )}
                  </div>
                  <input
                    type="text"
                    value={paymentTxId}
                    onChange={(e) => setPaymentTxId(e.target.value)}
                    placeholder="مثال: 489201982 أو رقم تتبع العملية"
                    className="w-full bg-[#151C26] border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-emerald-500/30 font-mono placeholder:text-white/20"
                  />
                </div>

                {/* Mock proof upload container */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-white/50 block">صورة إشعار الدفع أو الوصل المستلم:</label>
                  <div className="border border-dashed border-white/10 rounded-xl p-3 bg-[#111A24] text-center hover:bg-[#15212E] transition-colors relative">
                    <input
                      type="file"
                      accept="image/*"
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          // Standard base64 local reader
                          const reader = new FileReader();
                          reader.onload = () => {
                            setPaymentProofFile(reader.result as string);
                            success('تم استلام الوصل', 'تم تحميل وحفظ صورة التحويل محلياً بمتصفحك بنجاح.');
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                    {paymentProofFile ? (
                      <div className="space-y-2">
                        <img 
                          src={paymentProofFile} 
                          alt="Payment Receipt" 
                          referrerPolicy="no-referrer"
                          className="max-h-24 mx-auto rounded border border-white/10" 
                        />
                        <button 
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation(); e.preventDefault();
                            setPaymentProofFile('');
                          }}
                          className="text-[9px] text-red-400 hover:underline block mx-auto"
                        >
                          إزالة الملف وحذف الوصل
                        </button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center gap-1">
                        <Upload className="w-5 h-5 text-white/40" />
                        <span className="text-[10px] text-white/60 block">اسحب وأفلت صورة التحويل أو اضغط للتصفح</span>
                        <span className="text-[8px] text-white/30">تحفظ محلياً ومشفرة بالكامل بمتصفحك</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Verification check toggle */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="verifiedBySeller"
                    checked={verifiedBySeller}
                    onChange={(e) => setVerifiedBySeller(e.target.checked)}
                    className="w-3.5 h-3.5 bg-[#151C26] border border-white/10 rounded text-emerald-500 focus:ring-0 focus:ring-offset-0"
                  />
                  <label htmlFor="verifiedBySeller" className="text-[11px] text-white/80 font-bold cursor-pointer flex items-center gap-1 select-none">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>أقر أنني قمت بمطابقة حسابي بنجاح واستلمت المبلغ فعلياً</span>
                  </label>
                </div>
              </div>

              {/* Editable note */}
              <div className="space-y-2">
                <label className="text-xs text-white/50 block font-medium">ملاحظات البائع وتعديلات العنوان:</label>
                <textarea
                  value={editedNotes}
                  onChange={e => setEditedNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-[#0E141C] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#18C29C]/50 resize-none"
                  placeholder="اكتب هنا تعديلات العنوان والوزن وملاحظات الموصل أو الشاحن..."
                />
                <Button 
                  size="sm" 
                  onClick={handleUpdateNotesAndCRM}
                  className="w-full text-xs h-9"
                >
                  حفظ ملاحظات ومطابقات الدفع للطلبية 💾
                </Button>
              </div>

              {/* History CRM panel */}
              {selectedOrder.pastOrdersCount > 0 && (
                <div className="bg-[#0a0f18]/90 p-3 rounded-xl border border-[#E0B15A]/20 space-y-2">
                  <div className="flex items-center gap-2">
                    <ThumbsUp className="w-4 h-4 text-[#E0B15A]" />
                    <span className="text-[11px] font-bold text-[#E0B15A]">زبون وفي وصاحب سوابق شراء في المتجر:</span>
                  </div>
                  <p className="text-[10px] text-white/60 leading-relaxed">
                    هذا العميل لديه {selectedOrder.pastOrdersCount} طلبيات سابقة بمجموع مشتريات مدفوعة. يرجى توفير معاملة خاصة وهدية رمزية لزيادة ولائه.
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </div>

      {/* Manual Order Creation Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-[#0f1520] border border-white/10 p-6 rounded-2xl shadow-2xl w-full max-w-lg overflow-y-auto max-h-[90vh]"
            >
              <button
                onClick={() => setIsModalOpen(false)}
                className="absolute top-4 left-4 text-white/50 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-brand-500/10 rounded-full flex items-center justify-center border border-brand-500/20 text-[#18C29C]">
                  <ClipboardList className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">تسجيل طلبية جديدة للمتجر</h3>
                  <p className="text-xs text-white/50">تحديث سجل المبيعات وحساب العملاء تلقائياً</p>
                </div>
              </div>

              <form onSubmit={handleCreateOrder} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input 
                    label="الاسم الكامل للعميل" 
                    placeholder="مثال: صالح بلقاسم" 
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    required
                  />
                  <Input 
                    label="رقم هاتف العميل" 
                    placeholder="0555 12 34 56" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="font-mono text-left"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-sm font-medium text-white/70">سُلّة المبيعات (المنتج المطلوب)</label>
                    {products.length === 0 ? (
                      <div className="text-xs text-amber-500 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                        الرجاء إضافة منتج إلى المخزون أولاً لتتمكن من تحديده!
                      </div>
                    ) : (
                      <select 
                        required
                        className="glass-input flex h-11 w-full rounded-xl px-4 py-2 text-sm text-white appearance-none bg-[#0a0f18]"
                        value={selectedProductId}
                        onChange={(e) => setSelectedProductId(e.target.value)}
                      >
                        {products.map(p => (
                          <option key={p.id} value={p.id}>{p.name} - {formatDZD(p.price)}</option>
                        ))}
                      </select>
                    )}
                  </div>

                  <Input 
                    type="number" 
                    label="الكمية المطلوبة" 
                    min={1} 
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-sm font-medium text-white/70">ولاية التوصيل</label>
                    <select 
                      className="glass-input flex h-11 w-full rounded-xl px-4 py-2 text-sm text-white appearance-none bg-[#0a0f18]"
                      value={wilaya}
                      onChange={(e) => setWilaya(e.target.value)}
                    >
                      <option value="الجزائر">16 - الجزائر ( العاصمة )</option>
                      <option value="وهران">31 - وهران</option>
                      <option value="قسنطينة">25 - قسنطينة</option>
                      <option value="عنابة">23 - عنابة</option>
                      <option value="سطيف">19 - سطيف</option>
                      <option value="تلمسان">13 - تلمسان</option>
                      <option value="البليدة">09 - البليدة</option>
                    </select>
                  </div>
                  <Input 
                    label="العنوان التفصيلي" 
                    placeholder="البلدية والحي ورقم الباب..." 
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-sm font-medium text-white/70">ملاحظات التوصيل (اختياري)</label>
                  <textarea 
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                    placeholder="أي توجيهات إضافية بخصوص موعد التوصيل أو السعر..."
                    className="w-full bg-[#0a0f18] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors resize-none"
                  />
                </div>

                <div className="pt-4 flex gap-3">
                  <Button type="button" variant="secondary" className="flex-1" onClick={() => setIsModalOpen(false)}>إلغاء</Button>
                  <Button type="submit" className="flex-1 font-semibold" disabled={isSaving || products.length === 0} isLoading={isSaving}>
                     تسجيل الطلبية
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

