import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Upload, Save, HelpCircle, AlertCircle } from 'lucide-react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { addItem } from '../lib/db';
import { ALGERIAN_WILAYAS } from '../lib/db';

interface AddProductFormProps {
  onSaved: () => void;
  onCancel: () => void;
}

const CATEGORIES = [
  'إلكترونيات',
  'ملابس وأزياء',
  'مستحضرات تجميل',
  'طعام ومأكولات',
  'عقارات',
  'مركبات',
  'وظائف',
  'خدمات',
  'أخرى'
];

export default function AddProductForm({ onSaved, onCancel }: AddProductFormProps) {
  const { activeWorkspace } = useWorkspace();
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: 'إلكترونيات',
    description: '',
    stock: '',
    wilaya: activeWorkspace?.settings?.wilaya || 'الجزائر العاصمة',
    
    // Dynamic fields
    brand: '',
    condition: 'جديد',
    cuisineType: '',
    preparationTime: '',
    serviceDuration: '',
    mileage: '',
    year: '',
    surfaceArea: '',
    contractType: '',
    salaryRange: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSave = async () => {
    if (!activeWorkspace) return;
    if (!formData.name || !formData.price) {
      alert('يرجى ملء الحقول الأساسية (الاسم والسعر)');
      return;
    }

    setIsSaving(true);
    try {
      const newProduct = {
        id: crypto.randomUUID(),
        workspaceId: activeWorkspace.id,
        vendorId: activeWorkspace.id,
        vendorName: activeWorkspace.name,
        name: formData.name,
        price: Number(formData.price),
        category: formData.category,
        description: formData.description,
        stock: Number(formData.stock) || 1,
        wilaya: formData.wilaya,
        image: null, // placeholder
        verified: activeWorkspace.id ? true : false,
        sponsored: false,
        dynamicData: {
          brand: formData.brand,
          condition: formData.condition,
          cuisineType: formData.cuisineType,
          preparationTime: formData.preparationTime,
          serviceDuration: formData.serviceDuration,
          mileage: formData.mileage,
          year: formData.year,
          surfaceArea: formData.surfaceArea,
          contractType: formData.contractType,
          salaryRange: formData.salaryRange
        }
      };

      await addItem('products', newProduct);
      onSaved();
    } catch (e) {
      console.error(e);
      alert('حدث خطأ أثناء الحفظ');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="p-6 md:p-8 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold text-white mb-6 border-b border-white/5 pb-4">إضافة منتج جديد</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column: Media & Basic */}
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80">صور المنتج</label>
            <div className="border-2 border-dashed border-white/10 rounded-2xl h-48 flex flex-col items-center justify-center bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group">
              <Upload className="w-8 h-8 text-white/30 group-hover:text-brand-400 mb-2 transition-colors" />
              <span className="text-sm text-white/50">اضغط لرفع الصور (حتى 5 صور)</span>
              <span className="text-xs text-white/30 mt-1">PNG, JPG حتى 5MB</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80">اسم المنتج <span className="text-red-400">*</span></label>
            <Input 
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="مثال: حذاء رياضي نايك أوريجينال" 
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/80">السعر (د.ج) <span className="text-red-400">*</span></label>
              <Input 
                name="price"
                type="number"
                value={formData.price}
                onChange={handleChange}
                placeholder="0.00" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/80">الكمية المتوفرة</label>
              <Input 
                name="stock"
                type="number"
                value={formData.stock}
                onChange={handleChange}
                placeholder="1" 
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80">التصنيف الأساسي <span className="text-red-400">*</span></label>
            <select 
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="w-full bg-[#0a0f18] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors"
            >
              {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
        </div>

        {/* Right Column: Dynamic Fields & Details */}
        <div className="space-y-6">
          
          {/* Dynamic Fields Section */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-4">
            <h3 className="text-sm font-bold text-white/90 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-brand-400" />
              خصائص حسب الصنف ({formData.category})
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(formData.category === 'إلكترونيات' || formData.category === 'ملابس وأزياء' || formData.category === 'مركبات') && (
                <>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">حالة المنتج</label>
                    <select name="condition" value={formData.condition} onChange={handleChange} className="w-full bg-[#0a0f18] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:border-brand-500/50">
                      <option value="جديد">جديد (New)</option>
                      <option value="مستعمل - حالة ممتازة">مستعمل - حالة ممتازة</option>
                      <option value="مستعمل">مستعمل</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">العلامة التجارية / الماركة</label>
                    <Input name="brand" value={formData.brand} onChange={handleChange} placeholder="مثال: Samsung" className="h-9 text-sm" />
                  </div>
                </>
              )}

              {formData.category === 'مركبات' && (
                <>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">سنة الصنع (Year)</label>
                    <Input name="year" type="number" value={formData.year} onChange={handleChange} placeholder="مثال: 2022" className="h-9 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">المسافة المقطوعة (كم)</label>
                    <Input name="mileage" type="number" value={formData.mileage} onChange={handleChange} placeholder="0" className="h-9 text-sm" />
                  </div>
                </>
              )}

              {formData.category === 'عقارات' && (
                <div className="space-y-1">
                  <label className="text-xs text-white/60">المساحة (م²)</label>
                  <Input name="surfaceArea" type="number" value={formData.surfaceArea} onChange={handleChange} placeholder="مثال: 120" className="h-9 text-sm" />
                </div>
              )}

              {formData.category === 'خِدْمات' || formData.category === 'خدمات' && (
                <div className="space-y-1">
                  <label className="text-xs text-white/60">مدة الخدمة المتوقعة</label>
                  <Input name="serviceDuration" value={formData.serviceDuration} onChange={handleChange} placeholder="مثال: يوما عمل" className="h-9 text-sm" />
                </div>
              )}
              
              {formData.category === 'طعام ومأكولات' && (
                <>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">نوع المطبخ</label>
                    <Input name="cuisineType" value={formData.cuisineType} onChange={handleChange} placeholder="مثال: حلويات تقليدية" className="h-9 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">وقت التحضير</label>
                    <Input name="preparationTime" value={formData.preparationTime} onChange={handleChange} placeholder="مثال: 24 ساعة" className="h-9 text-sm" />
                  </div>
                </>
              )}

              {formData.category === 'وظائف' && (
                <>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">نوع العقد</label>
                    <select name="contractType" value={formData.contractType} onChange={handleChange} className="w-full bg-[#0a0f18] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:border-brand-500/50">
                      <option value="">اختر النوع</option>
                      <option value="CDI">CDI (دائم)</option>
                      <option value="CDD">CDD (مؤقت)</option>
                      <option value="Free-lance">عمل حر</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-white/60">الراتب المتوقع</label>
                    <Input name="salaryRange" value={formData.salaryRange} onChange={handleChange} placeholder="مثال: 40000 - 60000 د.ج" className="h-9 text-sm" />
                  </div>
                </>
              )}
            </div>
            
            {formData.category === 'أخرى' && (
              <p className="text-xs text-white/40 italic">لا توجد خصائص إضافية لهذا الصنف.</p>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80">الوصف التفصيلي</label>
            <textarea 
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={4}
              placeholder="اكتب وصفاً جذاباً لمنتجك (اختياري)..."
              className="w-full bg-[#0a0f18] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors resize-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white/80">ولاية التوفر الرئيسية</label>
            <select 
              name="wilaya"
              value={formData.wilaya}
              onChange={handleChange}
              className="w-full bg-[#0a0f18] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors cursor-pointer"
            >
               {ALGERIAN_WILAYAS.map((w, i) => (
                  <option key={w.id} value={w.name}>{w.id} - {w.name}</option>
               ))}
            </select>
          </div>

          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex gap-3">
            <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
            <p className="text-xs text-amber-500/90 leading-relaxed">
              سيتم نشر المنتج فوراً. السلع المخالفة للقانون سيتم حذفها، وقد يؤدي ذلك لحظر المتجر نهائياً من منصة ريادة.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-white/5 flex flex-col-reverse md:flex-row justify-end gap-3">
        <Button variant="secondary" onClick={onCancel} className="w-full md:w-auto" disabled={isSaving}>
          إلغاء
        </Button>
        <Button onClick={handleSave} className="w-full md:w-auto gap-2" disabled={isSaving}>
          <Save className="w-4 h-4" />
          {isSaving ? 'جاري الحفظ...' : 'نشر المنتج الآن'}
        </Button>
      </div>
    </Card>
  );
}
