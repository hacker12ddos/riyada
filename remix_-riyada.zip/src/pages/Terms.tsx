import React from 'react';
import { ShieldCheck, AlertOctagon, Scale, BadgeAlert, FileText } from 'lucide-react';
import { Card } from '../components/ui/Card';

export default function Terms() {
  return (
    <div className="max-w-4xl mx-auto space-y-10 py-6">
      <div className="text-center space-y-3">
        <div className="inline-flex p-3 bg-red-500/10 rounded-2xl border border-red-500/20 text-red-400 mb-2">
          <Scale className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-extrabold text-white">اتفاقية الخدمة والقوانين الحاكمة لريادة</h1>
        <p className="text-xs text-white/50 max-w-xl mx-auto leading-relaxed">
          تنظم هذه الوثيقة الشروط القانونية لاستخدام منصة ريادة بالجزائر، ومسؤوليات الأطراف البائعة والمشترية لضمان معاملة نظيفة وحماية المنظومة من الاحتيال.
        </p>
      </div>

      <div className="space-y-6">
        {/* Section 1 */}
        <div className="space-y-3">
          <h2 className="text-md font-bold text-white flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#18C29C] rounded"></span>
            1. القوانين الصارمة لإدراج السلع والمتاجر (Platform Rules)
          </h2>
          <Card className="p-5 bg-[#0E141C] border border-white/5 text-xs text-white/75 leading-relaxed space-y-2">
            <p>يُمنع منعاً باتاً من أصحاب المتاجر والناشطين في المنصة القيام بالإجراءات التالية:</p>
            <ul className="list-disc list-inside space-y-1 text-white/60 ps-2">
              <li>عرض سلع أو خدمات غير قانونية، أو تخالف التشريعات الحالية المعمول بها في الجمهورية الجزائرية الديمقراطية الشعبية.</li>
              <li>انتحال الهوية أو الأسماء التجارية للغير أو التسجيل ببيانات تواصل غير صحيحة بهدف التضليل.</li>
              <li>التحايل في نقاط التوثيق ورفع فواتير ووصولات تحويل CCP أو بريدي موب مزورة.</li>
              <li>استغلال حسابات وهمية لإشعال عمليات تقييم وهمية أو طلبات حجز بغرض رفع نقاط الثقة تلقائياً.</li>
            </ul>
          </Card>
        </div>

        {/* Section 2 */}
        <div className="space-y-3">
          <h2 className="text-md font-bold text-white flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#18C29C] rounded"></span>
            2. إخلاء مسؤولية المعاملات والتحصيل المالي (Transaction Disclaimer)
          </h2>
          <Card className="p-5 bg-[#0E141C] border border-white/5 text-xs text-white/75 leading-relaxed space-y-2">
            <p className="font-bold text-[#E0B15A]">تنبيه قانوني هام للمشترين:</p>
            <p className="text-white/60">
              ريادة هي منصة وسيطة وتقنية مجردة تعمل بصيغة تشغيل محلي في جهاز المتصفح (Client-side Operating System). تعاملات الدفع أو الاستلام، حجز السلع، تصفية المبالغ، والتحايل البنكي يظل بالكامل تحت مسؤوليتك الشخصية والتفاوض المباشر مع التاجر.
            </p>
            <p className="text-[#18C29C]">ريادة لا تلعب دور الوكيل الضامن لتعامل الشحن في هذا الإصدار، ولا تحتفظ بالودائع ولا تجمع العمولات نهائياً.</p>
          </Card>
        </div>

        {/* Section 3 */}
        <div className="space-y-3">
          <h2 className="text-md font-bold text-white flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#18C29C] rounded"></span>
            3. مسؤولية وجود وحجز السلعة ومؤشرات المخاطرة (Fraud Liability & Risk Engine)
          </h2>
          <Card className="p-5 bg-[#0E141C] border border-white/5 text-xs text-white/75 leading-relaxed space-y-2">
            <p className="text-white/60">
              تقوم خوارزمية ريادة (Risk Engine) بحساب مستويات خطورة تقديرية استناداً لدرجة تحقق هوية البائع والسنوات والآراء السابقة الفعّالة. المؤشرات الظاهرة هي مجرد تقدير خوارزمي للتسهيل وليست شهادة قانونية أو براءة ذمة للبائع.
            </p>
            <p className="text-red-400 font-bold">كل تاجر يثبت تورطه في الترويج لمبيعات وهمية أو الاستحواذ غير المشروع على ودائع مالية سيتعرض حسابه فوراً للحظر الكلي والعميق دون سابق إنذار وبلا أحقية لاسترداد محتوى المتجر.</p>
          </Card>
        </div>

        {/* Section 4 */}
        <div className="space-y-3">
          <h2 className="text-md font-bold text-white flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#18C29C] rounded"></span>
            4. سياسة البيانات والخصوصية المحلية (Local Data Policy)
          </h2>
          <Card className="p-5 bg-[#0E141C] border border-white/5 text-xs text-white/75 leading-relaxed space-y-2">
            <p className="text-white/60">
              لحماية حريتك وخصوصية سلعك، ريادة تحتفظ بكل قاعدة بيانات العمليات والمراسلات وتفاصيل المتجر محلياً داخل جهازك عبر محرك (IndexedDB/LocalStorage). لا يتم خزن أي بيانات حساسة، سجلات مكالمات أو صور وصولات بالخوادم لتتبع الفرد أو مراقبة نشاط السلع التجارية والخدمات الحرة.
            </p>
          </Card>
        </div>
      </div>

      <div className="bg-[#151C26] border border-red-500/20 rounded-2xl p-4 flex gap-3 items-start">
        <BadgeAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
        <p className="text-[10px] text-white/60 leading-relaxed">
          إن استخدامك لريادة يقر بقبولك التام غير المشروط ببنود الاستقلالية للمنصة، وبتحملك المسؤولية التجارية لمبادلاتك المالية. للتبليغ عن النصب أو الحسابات المشبوهة، تواصل فوراً للإبلاغ اليدوي مع مشرفي المجموعات بالولايات.
        </p>
      </div>
    </div>
  );
}
