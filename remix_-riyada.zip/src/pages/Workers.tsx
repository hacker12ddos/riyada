import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { getWorkers, createWorkerProfile, WorkerProfile } from '../lib/economy';
import { ALGERIAN_WILAYAS } from '../lib/db';
import { useToast } from '../contexts/ToastContext';
import { 
  Briefcase, 
  MapPin, 
  User, 
  Star, 
  Search, 
  SlidersHorizontal, 
  Phone, 
  CheckCircle2, 
  Plus, 
  X, 
  Sparkles,
  Award,
  Clock,
  DollarSign
} from 'lucide-react';
import { formatDZD } from '../lib/utils';

export default function Workers() {
  const { success, error } = useToast();
  const [workers, setWorkers] = useState<WorkerProfile[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedWilaya, setSelectedWilaya] = useState('الكل');
  
  // Create profile modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newCategory, setNewCategory] = useState('technical_repair');
  const [newWilaya, setNewWilaya] = useState('الجزائر');
  const [newExp, setNewExp] = useState(2);
  const [newRate, setNewRate] = useState(1000);
  const [newRateType, setNewRateType] = useState<'hourly' | 'daily' | 'task'>('hourly');
  const [newSkills, setNewSkills] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const categories = [
    { id: 'all', name: 'الكل' },
    { id: 'manual_labor', name: '🧱 أعمال يدوية ونقل' },
    { id: 'technical_repair', name: '🔧 صيانة وتقنيات' },
    { id: 'digital_freelance', name: '💻 عمل رقمي وبرمجة' },
    { id: 'academic', name: '🎓 تعليم ودروس الدعم' },
    { id: 'domestic_transport', name: '🚗 خدمات النقل والتوصيل' },
    { id: 'freelancers', name: '🛠 خدمات حرة ومتنوعة' }
  ];

  useEffect(() => {
    setWorkers(getWorkers());
  }, []);

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newPhone || !newSkills || !newDesc) {
      error('خطأ في المدخلات', 'يرجى مراجعة وتعبئة جميع الحقول المطلوبة.');
      return;
    }

    const targetSkills = newSkills.split(',').map(s => s.trim()).filter(Boolean);

    createWorkerProfile({
      name: newName,
      phone: newPhone,
      category: newCategory,
      wilaya: newWilaya,
      experienceYears: Number(newExp),
      rate: Number(newRate),
      rateType: newRateType,
      skills: targetSkills,
      description: newDesc,
      availability: 'available'
    });

    success('تم التسجيل بنجاح', 'أنت الآن جزء من شبكة ريادة للعمال المستقلين والمحترفين!');
    setIsModalOpen(false);
    setWorkers(getWorkers());

    // Reset fields
    setNewName('');
    setNewPhone('');
    setNewSkills('');
    setNewDesc('');
  };

  const getCategoryLabel = (cat: string) => {
    const found = categories.find(c => c.id === cat);
    return found ? found.name.substring(2) : cat;
  };

  const filteredWorkers = workers.filter(w => {
    const matchesSearch = w.name.toLowerCase().includes(search.toLowerCase()) || 
      w.skills.some(skill => skill.toLowerCase().includes(search.toLowerCase())) ||
      w.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || w.category === selectedCategory;
    const matchesWilaya = selectedWilaya === 'الكل' || w.wilaya === selectedWilaya;
    return matchesSearch && matchesCategory && matchesWilaya;
  });

  return (
    <div className="space-y-6">
      {/* Banner & Intro */}
      <div className="bg-gradient-to-r from-[#0E141C] via-[#101925] to-[#0E141C] border border-white/10 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <span className="bg-brand-500/10 text-brand-400 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-brand-500/20">شبكة العمال والحرفيين الجزائريين 👷</span>
          <h1 className="text-xl md:text-2xl font-extrabold text-white">ابحث عن حرفيين، عمال مستقلين، أو مستقلين رقميين</h1>
          <p className="text-white/50 text-xs md:text-sm max-w-2xl">
            اعثر على الكفاءات وعمال الصيانة والعمل اليدوي في ولايتك بكل شفافية، قارن تكاليف الخدمات اليومية وتواصل مباشرة عبر المنصة لحجز الخدمات.
          </p>
        </div>
        <Button 
          onClick={() => setIsModalOpen(true)}
          className="bg-brand-500 hover:bg-brand-600 text-black font-extrabold text-xs px-5 py-3 rounded-xl shadow-lg shrink-0 gap-1.5 flex items-center"
        >
          <Plus className="w-4 h-4" />
          سجل كحرفي / مستقل رقمي 🛠
        </Button>
      </div>

      {/* Control Filter Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center bg-[#0E141C] p-4 rounded-xl border border-white/5">
        <div className="md:col-span-5 relative">
          <input 
            type="text" 
            placeholder="ابحث عن مهارة (مثال: ترصيص، تصميم، توصيل)..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-brand-500/50 pl-10"
          />
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-3.5" />
        </div>

        <div className="md:col-span-3">
          <select 
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-brand-500/50"
          >
            {categories.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div className="md:col-span-3">
          <select 
            value={selectedWilaya}
            onChange={e => setSelectedWilaya(e.target.value)}
            className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-brand-500/50"
          >
            <option value="الكل">كل الولايات</option>
            {ALGERIAN_WILAYAS.map(w => (
              <option key={w.id} value={w.name}>{w.name}</option>
            ))}
          </select>
        </div>

        <div className="md:col-span-1">
          <Button variant="secondary" className="w-full h-10 px-0 flex justify-center items-center">
            <SlidersHorizontal className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Grid of workers list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredWorkers.map(w => (
          <Card key={w.id} className="bg-[#0E141C] border border-white/10 p-5 flex flex-col justify-between hover:border-brand-500/30 transition-all group">
            <div>
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#18C29C]/20 to-transparent border border-[#18C29C]/20 flex items-center justify-center text-white font-extrabold text-sm relative">
                    {w.name.substring(0, 2)}
                    {w.verified && (
                      <span className="absolute -bottom-1 -right-1 bg-brand-500 text-[#05070a] rounded-full p-0.5">
                        <CheckCircle2 className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      {w.name}
                      {w.sponsored && <span className="text-[8px] bg-amber-500/20 text-[#E0B15A] px-1.5 rounded-full">راعي</span>}
                    </h3>
                    <p className="text-[10px] text-white/40">{getCategoryLabel(w.category)}</p>
                  </div>
                </div>

                <div className="text-left">
                  <span className="text-[10px] text-brand-400 bg-brand-400/10 px-2 py-0.5 rounded border border-brand-400/10 block mb-1">
                    {w.availability === 'available' ? '✓ متاح للطلب' : '✕ مشغول'}
                  </span>
                  <div className="flex items-center gap-1 justify-end text-xs text-[#E0B15A] font-bold">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>{w.rating.toFixed(1)}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-1.5 flex-wrap mb-4">
                {w.skills.map((skill, i) => (
                  <span key={i} className="text-[9px] bg-white/5 text-white/70 px-2 py-0.5 rounded-lg border border-white/5 font-medium">
                    {skill}
                  </span>
                ))}
              </div>

              <p className="text-xs text-white/50 leading-relaxed line-clamp-3 mb-4">{w.description}</p>
            </div>

            <div className="border-t border-white/5 pt-4 space-y-4">
              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2 text-white/40">
                  <MapPin className="w-4 h-4 text-brand-400" />
                  <span>ولاية {w.wilaya}</span>
                </div>
                <div className="flex items-center gap-1 font-mono text-white">
                  <DollarSign className="w-3.5 h-3.5 text-[#18C29C]" />
                  <span className="font-bold text-sm">{formatDZD(w.rate)}</span>
                  <span className="text-[10px] text-white/40">/{w.rateType === 'hourly' ? 'ساعة' : w.rateType === 'daily' ? 'يوم' : 'خدمة'}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={() => {
                    const msg = `مرحباً ${w.name}، تواصلت معك عبر منصة ريادة بخصوص طلب عمل: ...`;
                    window.open(`https://wa.me/${w.phone}?text=${encodeURIComponent(msg)}`, '_blank');
                  }}
                  className="flex-1 bg-white/5 border border-white/10 hover:bg-white/10 text-xs text-white"
                >
                  <Phone className="w-3.5 h-3.5 text-brand-400" />
                  اطلب اتصالاً سريعاً
                </Button>
                <Button 
                  onClick={() => {
                    alert(`بيانات التواصل المسجلة رسمياً للحرفي:\nالاسم: ${w.name}\nالهاتف المعتمد: ${w.phone}\nالولايات المتاحة: ${w.wilaya}\nالرجاء إشعارنا في حال عدم استجابة الحرفي بنشاط.`);
                  }}
                  className="bg-brand-500 hover:bg-brand-600 text-black font-extrabold text-xs"
                >
                  حجز المهمة
                </Button>
              </div>
            </div>
          </Card>
        ))}

        {filteredWorkers.length === 0 && (
          <div className="col-span-full py-16 text-center text-white/40 space-y-3">
            <User className="w-12 h-12 mx-auto stroke-1" />
            <h4 className="text-sm font-bold text-white">لا توجد ملفات عمال بهذا البحث حالياً</h4>
            <p className="text-xs text-white/50 leading-relaxed max-w-sm mx-auto">
              تصفح الولايات المجاورة أو سجل كحرفي لتكون أول القائمين بالخدمة في ولايتك!
            </p>
          </div>
        )}
      </div>

      {/* Signup Worker Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-[#0E141C] border border-white/10 w-full max-w-lg p-6 space-y-4 relative">
            <button 
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 left-4 text-white/50 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 border-b border-white/5 pb-3">
              <Sparkles className="w-5 h-5 text-brand-400" />
              <h2 className="text-base font-bold text-white">سجل بيانات ملفك المهني كحرفي أو مستقل في ريادة</h2>
            </div>

            <form onSubmit={handleCreateProfile} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-white/60">الاسم الكامل:</label>
                  <input 
                    type="text" 
                    required
                    placeholder="مثال: يونس بومدين"
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-white/60">رقم الهاتف (لتلقي الزبائن):</label>
                  <input 
                    type="tel" 
                    required
                    placeholder="مثال: 0551000000"
                    value={newPhone}
                    onChange={e => setNewPhone(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white font-mono outline-none focus:border-brand-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-white/60">التخصص الرئيسي:</label>
                  <select 
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  >
                    {categories.filter(c => c.id !== 'all').map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-white/60">ولاية النشاط:</label>
                  <select 
                    value={newWilaya}
                    onChange={e => setNewWilaya(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  >
                    {ALGERIAN_WILAYAS.map(w => (
                      <option key={w.id} value={w.name}>{w.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-white/60">سنوات الخبرة:</label>
                  <input 
                    type="number" 
                    value={newExp}
                    onChange={e => setNewExp(Number(e.target.value))}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500 text-center"
                  />
                </div>
                <div className="space-y-1 col-span-2">
                  <label className="text-white/60">تسعيرة الخدمة المتوقعة (دج):</label>
                  <div className="flex gap-2">
                    <input 
                      type="number" 
                      value={newRate}
                      onChange={e => setNewRate(Number(e.target.value))}
                      className="w-1/2 bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white text-center font-mono outline-none focus:border-brand-500"
                    />
                    <select 
                      value={newRateType}
                      onChange={e => setNewRateType(e.target.value as any)}
                      className="w-1/2 bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                    >
                      <option value="hourly">ساعي</option>
                      <option value="daily">يومي</option>
                      <option value="task">لكل مهمة</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-white/60">المهارات التفصيلية (مفصولة بفاصلة):</label>
                <input 
                  type="text" 
                  required
                  placeholder="تصليح ثلاجات, صيانة كهربائية, تركيب المكيفات"
                  value={newSkills}
                  onChange={e => setNewSkills(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/60">نبذة تعريفية شاملة عن خدماتك وتاريخك المهني:</label>
                <textarea 
                  rows={3}
                  required
                  placeholder="اكتب نبذة مقنعة لتسهيل حجزك من قبل الشركات ومقاولي ريادة..."
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white resize-none outline-none focus:border-brand-500"
                />
              </div>

              <Button 
                type="submit"
                className="w-full bg-[#18C29C] hover:opacity-95 text-black font-extrabold h-11 text-xs"
              >
                تأكيد ونشر ملفي كعامل/حرفي نشط للجميع
              </Button>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}
