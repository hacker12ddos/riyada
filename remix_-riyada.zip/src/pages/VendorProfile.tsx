import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Store, ShieldCheck, MapPin, Phone, MessageCircle, Star, Package, QrCode } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { TrustBadge } from '../components/TrustBadge';
import { QRCodeModal } from '../components/QRCodeModal';
import { ReportModal } from '../components/ReportModal';
import { formatDZD } from '../lib/utils';
import { getAllItems, trackInteraction } from '../lib/db';

export default function VendorProfile() {
  const { storeId } = useParams();
  const navigate = useNavigate();
  const [products, setProducts] = useState<any[]>([]);
  const [vendorData, setVendorData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showQR, setShowQR] = useState(false);
  const [showReport, setShowReport] = useState(false);

  useEffect(() => {
    if (storeId) {
      loadVendorData();
      trackInteraction(storeId, 'view', storeId); // track vendor view
    }
  }, [storeId]);

  const loadVendorData = async () => {
    setIsLoading(true);
    try {
      const allProducts = await getAllItems('products');
      const storeProducts = allProducts.filter(p => p.workspaceId === storeId);
      
      const workspaces = await getAllItems('workspaces');
      const store = workspaces.find((w: any) => w.id === storeId);
      
      if (store) {
        setVendorData(store);
      } else {
        setVendorData({
          id: storeId,
          name: 'بائع في ريادة',
          type: 'متجر محلي',
          settings: { wilaya: 'الجزائر العاصمة' }
        });
      }

      setProducts(storeProducts || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleWhatsApp = () => {
    if (!storeId || !vendorData) return;
    trackInteraction(storeId, 'whatsapp', storeId);
    const vendorPhone = vendorData.settings?.phone || '0555123456';
    const message = `مرحباً، أود الاستفسار عن منتجات متجرك في منصة ريادة.`;
    window.open(`https://wa.me/${vendorPhone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="space-y-8">
      {/* Store Banner & Header */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
        <div className="h-48 md:h-64 bg-gradient-to-br from-[#121826] to-[#05070a] relative flex items-center justify-center overflow-hidden">
          {/* Abstract pattern */}
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-brand-500 via-transparent to-transparent"></div>
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.05) 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
        </div>
        
        <div className="bg-[#0a0f18] px-6 md:px-12 pb-8 pt-20 md:pt-24 relative">
          {/* Store Avatar */}
          <div className="absolute -top-16 md:-top-20 right-6 md:right-12 w-32 h-32 md:w-40 md:h-40 bg-[#05070a] rounded-2xl border-4 border-[#0a0f18] shadow-2xl flex items-center justify-center p-2 z-10">
            <div className="w-full h-full bg-[#1AAE8A]/10 rounded-xl flex items-center justify-center border border-[#1AAE8A]/20">
              <Store className="w-12 h-12 text-[#1AAE8A]" />
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row gap-6 md:items-end justify-between md:ms-44 lg:ms-48">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl md:text-3xl font-bold text-white">{vendorData?.name || 'جاري التحميل...'}</h1>
                <TrustBadge />
              </div>
              <p className="text-white/60 max-w-lg text-sm mb-4 leading-relaxed">
                متجر إلكتروني موثق على منصة ريادة. مختص في مجال {vendorData?.type || 'التجارة الحرة'}.
              </p>
              
              <div className="flex flex-wrap items-center gap-4 text-xs text-white/50">
                <div className="flex items-center gap-1"><MapPin className="w-4 h-4 text-white/30" /> {vendorData?.settings?.wilaya || 'الجزائر العاصمة'}</div>
                <div className="flex items-center gap-1"><Star className="w-4 h-4 text-amber-500" /> نشط في ريادة</div>
                <div className="flex items-center gap-1"><Package className="w-4 h-4 text-white/30" /> {products.length} منتج نشط</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3 shrink-0">
               <Button variant="secondary" className="gap-2 shrink-0 p-2" onClick={() => setShowQR(true)}>
                 <QrCode className="w-5 h-5" />
               </Button>
               <Button variant="secondary" className="gap-2 shrink-0">
                 مشاركة
               </Button>
               <Button 
                 onClick={handleWhatsApp}
                 className="bg-[#25D366] hover:bg-[#128C7E] text-white gap-2 border-0"
               >
                 <MessageCircle className="w-4 h-4" />
                 تواصل عبر واتساب
               </Button>
            </div>
          </div>
        </div>
      </div>

      <QRCodeModal 
        isOpen={showQR} 
        onClose={() => setShowQR(false)} 
        url={window.location.href} 
        title={vendorData?.name || 'متجر ريادة'} 
      />

      <ReportModal
        isOpen={showReport}
        onClose={() => setShowReport(false)}
        targetId={storeId!}
        targetType="vendor"
      />

      {/* Store Navigation (Tabs) */}
      <div className="flex items-center gap-6 border-b border-white/10 px-4 text-sm font-medium overflow-x-auto scrollbar-hide">
        <button className="pb-4 text-brand-400 border-b-2 border-brand-500 shrink-0">منتجات المتجر</button>
        <button className="pb-4 text-white/40 hover:text-white transition-colors shrink-0">عن المتجر</button>
        
        <div className="flex-1"></div>
        <button 
          onClick={() => setShowReport(true)}
          className="pb-4 text-red-400/70 hover:text-red-400 transition-colors shrink-0 text-xs flex items-center gap-1"
        >
          الإبلاغ عن المتجر
        </button>
      </div>

      {/* Products Grid */}
      <div>
        <h2 className="text-lg font-bold text-white mb-6">سلع المتجر المعروضة</h2>
        {isLoading ? (
          <div className="flex justify-center p-12"><div className="w-8 h-8 border-4 border-white/10 border-t-brand-500 rounded-full animate-spin"></div></div>
        ) : (
          <div>
            <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {products.map((product, idx) => (
                <Card key={idx} className="p-0 h-full flex flex-col overflow-hidden cursor-pointer group hover:border-brand-500/30 transition-colors" onClick={() => navigate(`/product/${product.id || idx}`)}>
                  <div className="bg-white/5 aspect-square relative overflow-hidden border-b border-white/5 flex items-center justify-center">
                    {product.image ? (
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    ) : (
                      <Store className="w-12 h-12 text-white/10" />
                    )}
                  </div>
                  <div className="p-3 flex flex-col flex-1">
                    <span className="text-[10px] text-brand-400 mb-1">{product.category || 'إلكترونيات'}</span>
                    <h3 className="font-medium text-white/90 text-sm mb-2">{product.name}</h3>
                    <div className="mt-auto">
                      <span className="font-bold text-white">{formatDZD(product.price)}</span>
                      <button className="w-full mt-3 bg-white/5 hover:bg-white/10 text-white text-xs py-2 rounded transition-colors flex items-center justify-center gap-2">
                        عرض التفاصيل
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            {products.length === 0 && (
              <div className="py-12 bg-[#121822]/50 border border-white/5 rounded-2xl flex flex-col items-center text-center p-6">
                <Store className="w-12 h-12 text-white/10 mb-2" />
                <span className="text-white/50 text-xs">لم يقم هذا البائع بإضافة أي منتجات للمخزون بعد.</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
