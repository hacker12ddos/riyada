import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Users, Search, Filter, Phone, MapPin, UserCheck, ShieldAlert } from 'lucide-react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { useToast } from '../contexts/ToastContext';
import { getItemsByWorkspace, Customer, addItem } from '../lib/db';
import { formatDZD } from '../lib/utils';
import { motion } from 'motion/react';
import { SkeletonRow } from '../components/ui/Skeleton';

export default function Customers() {
  const { activeWorkspace } = useWorkspace();
  const { success, error } = useToast();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (activeWorkspace) {
      loadCustomers(activeWorkspace.id);
    }
  }, [activeWorkspace]);

  const loadCustomers = async (workspaceId: string) => {
    setIsLoading(true);
    try {
      const items = await getItemsByWorkspace('customers', workspaceId);
      setCustomers(items || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const copyPhone = (phone: string) => {
    navigator.clipboard.writeText(phone);
    success('تم النسخ', `تم نسخ رقم الهاتف ${phone}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">العملاء و CRM</h1>
          <p className="text-white/50">إدارة زبائنك، سجل المشتريات، وقائمة المحظورين.</p>
        </div>
        <Button className="shrink-0 gap-2">
          <UserCheck className="w-4 h-4" />
          <span>إضافة عميل جديد</span>
        </Button>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="p-4 border-b border-white/5">
          <div className="flex flex-col md:flex-row gap-4">
            <Input 
              placeholder="البحث بالاسم أو رقم الهاتف..." 
              icon={<Search className="w-4 h-4" />}
              className="md:max-w-md bg-[#0a0f18] focus:bg-[#0a0f18]"
            />
            <Button variant="secondary" className="gap-2 shrink-0 md:ms-auto">
              <Filter className="w-4 h-4" />
              <span>تصفية العملاء</span>
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm text-white/70">
            <thead className="text-xs text-white/30 border-b border-white/5 bg-[#0a0f18]/30">
              <tr className="h-10">
                <th className="px-6 py-2 font-medium">العميل</th>
                <th className="px-6 py-2 font-medium">الهاتف</th>
                <th className="px-6 py-2 font-medium">الطلبات</th>
                <th className="px-6 py-2 font-medium">إجمالي المشتريات</th>
                <th className="px-6 py-2 font-medium text-center">الحالة</th>
              </tr>
            </thead>
            <tbody className="text-xs">
              {isLoading ? (
                <>
                  <SkeletonRow />
                  <SkeletonRow />
                  <SkeletonRow />
                </>
              ) : customers.map((customer, idx) => (
                <motion.tr 
                  key={customer.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="border-b border-white/5 h-16 hover:bg-white/5 transition-colors"
                >
                  <td className="px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-brand-500/10 border border-brand-500/20 flex items-center justify-center text-brand-400 font-bold">
                        {customer.name.charAt(0)}
                      </div>
                      <span className="font-medium text-white/90 text-sm">{customer.name}</span>
                    </div>
                  </td>
                  <td className="px-6 font-mono text-white/80 cursor-pointer hover:text-brand-400 transition-colors" onClick={() => copyPhone(customer.phone)}>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3 h-3 opacity-50" />
                      {customer.phone}
                    </div>
                  </td>
                  <td className="px-6 font-medium">
                    {customer.ordersCount} طلب
                  </td>
                  <td className="px-6 font-mono text-brand-400 font-medium">
                    {formatDZD(customer.totalSpent)}
                  </td>
                  <td className="px-6 text-center">
                    {customer.blacklisted ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-500/10 text-red-500 border border-red-500/20">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        محظور
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/5 text-white/50 border border-white/10">
                        <UserCheck className="w-3.5 h-3.5" />
                        موثوق
                      </span>
                    )}
                  </td>
                </motion.tr>
              ))}
              {customers.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-white/40">
                    لا يوجد عملاء بعد
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
