import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, ShieldCheck, Database, Server, Cpu, 
  Copy, Check, Sparkles, BookOpen, AlertCircle, 
  Zap, Compass, Play, Download, HelpCircle, 
  ChevronRight, ArrowLeftRight, Trash2, Award
} from 'lucide-react';
import { DEPLOYMENT_COMMANDS } from '../lib/commands';
import { MONETIZATION_PACKS } from '../lib/monetization';
import { getDatabaseConnectionStatus } from '../lib/env';
import { useToast } from '../contexts/ToastContext';

export default function SetupWizard() {
  const { showToast } = useToast();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTab, setActiveTab ] = useState<'wizard' | 'commands' | 'database' | 'monetization'>('wizard');
  const [simulatedAiven, setSimulatedAiven] = useState(false);

  // Connection validation
  const realStatus = getDatabaseConnectionStatus();
  const isWired = simulatedAiven || realStatus.isConnected;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast('تم نسخ الأمر إلى الحافظة بنجاح!', 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const sqlSchemaStr = `-- RIYADA v23 schema quick copy
CREATE TABLE IF NOT EXISTS public.workspaces (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  wilaya VARCHAR(100) DEFAULT 'الجزائر',
  verified_badge BOOLEAN DEFAULT FALSE,
  growth_tier VARCHAR(50) DEFAULT 'free'
);`;

  const sqlRlsStr = `-- Enable row level security
ALTER TABLE public.workspaces ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Workspaces are public" ON public.workspaces FOR SELECT USING (true);`;

  return (
    <div className="space-y-8 font-sans text-right pb-16" dir="rtl">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-l from-brand-950/20 via-[#0a0f18] to-[#05070a] p-8 md:p-12">
        <div className="absolute top-0 right-0 -z-10 h-72 w-72 rounded-full bg-brand-500/10 blur-[120px]" />
        
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-brand-500/10 px-3 py-1 border border-brand-500/20 text-xs text-brand-400 font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ريادة v23 — نظام تفريغ ونشر سحابي مجاني</span>
          </div>
          
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            مساعد التهيئة السحابية ونشر المتجر <span className="text-brand-400">بدون تكاليف</span>
          </h1>
          
          <p className="text-sm md:text-base text-white/70 leading-relaxed max-w-2xl">
            هل ترغب في الحصول على خادم آمن وقشرة بيانات سحابية متصلة مجاناً؟ ريادة معدة بالكامل لتتكامل مع خدمات 
            <strong className="text-white mx-1">Cloud Run / Vercel</strong> الممتازة للواجهة ومحرك 
            <strong className="text-white mx-1">Aiven PostgreSQL</strong> للبيانات.
          </p>
        </div>
      </div>

      {/* Database Connection HUD */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-[#0a0f18] p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-3.5 h-3.5 rounded-full ${isWired ? 'bg-brand-500 shadow-[0_0_12px_rgba(26,174,138,0.5)]' : 'bg-rose-500 shadow-[0_0_12px_rgba(239,68,68,0.5)]'} animate-pulse`} />
              <h3 className="font-bold text-sm text-white">حالة الاتصال السحابي</h3>
            </div>
            <span className="text-[10px] font-mono text-white/40 uppercase bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              {isWired ? 'Aiven Connected' : 'IndexedDB Fallback'}
            </span>
          </div>

          <p className="text-xs text-white/70 leading-relaxed">
            {isWired 
              ? 'متصل بقاعدة Aiven PostgreSQL السحابية بنجاح! يتم تشفير وتحديث بيانات السلع والطلبات والعمال فوراُ على الخادم السحابي المحمي.'
              : 'المنصة تعمل حالياً في (الوضع المحلي الآمن)؛ يتم الحفظ داخل متصفحك. لربطه بقاعدة بيانات سحابية حقيقية للجمهور، اتبع خطوات المعالج أدناه.'
            }
          </p>

          <div className="flex flex-wrap gap-2 pt-2">
            <button
              onClick={() => {
                setSimulatedAiven(!simulatedAiven);
                showToast(
                  !simulatedAiven ? 'تم تجربة محاكاة الربط السحابي بنجاح!' : 'تم العودة لوضعية التدفق ومحاكاة الخلايا المحلية.', 
                  'warning'
                );
              }}
              className="px-4 py-2 rounded-xl border border-white/10 hover:bg-white/5 text-white text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-brand-400" />
              <span>{isWired ? 'عزل ومحاكاة الوضع المحلي' : 'محاكاة الاتصال السحابي السريع'}</span>
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-[#0a0f18] p-6 flex flex-col justify-between">
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white/50 tracking-wider">المنفذ والمستضيف المتاح</h4>
            <div className="flex items-center gap-1.5 text-brand-400">
              <Server className="w-4 h-4" />
              <span className="text-sm font-semibold font-mono">https://riyada.vercel.app</span>
            </div>
            <p className="text-[10px] text-white/40 leading-relaxed">
              تصفية الكود الحالية مؤهلة مجاناً لتبديل واستيراد نطاقك الخاص (custom domain) من لوحة تحكم فيرسيل بدون أي رسوم.
            </p>
          </div>

          <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-[11px] text-white/50">
            <span>الاستهلاك المالي: <strong className="text-brand-400">0.00 دج</strong></span>
            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full text-[9px] font-bold">Free Tier</span>
          </div>
        </div>
      </div>

      {/* Tabs Menu */}
      <div className="flex border-b border-white/10 gap-2 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('wizard')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'wizard' ? 'border-brand-500 text-white bg-white/5' : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>خطوات الإطلاق للمبتدئين</span>
        </button>
        <button
          onClick={() => setActiveTab('commands')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'commands' ? 'border-brand-500 text-white bg-white/5' : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>موجه الأوامر السريع (Copy CLI)</span>
        </button>
        <button
          onClick={() => setActiveTab('database')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'database' ? 'border-brand-500 text-white bg-white/5' : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>حقن جداول SQL سوبابيس</span>
        </button>
        <button
          onClick={() => setActiveTab('monetization')}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'monetization' ? 'border-brand-500 text-white bg-white/5' : 'border-transparent text-white/50 hover:text-white'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>لوحة الباقات والنمو التجاري</span>
        </button>
      </div>

      {/* Tabs Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.15 }}
          className="space-y-6"
        >
          {/* Tab 1: Wizard */}
          {activeTab === 'wizard' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Step 1 */}
                <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-3 relative overflow-hidden">
                  <div className="absolute top-2 left-4 text-6xl font-extrabold text-white/5 font-mono select-none">01</div>
                  <div className="w-10 h-10 rounded-xl bg-brand-500/10 border border-brand-500/20 text-brand-400 flex items-center justify-center font-bold text-sm">
                    1
                  </div>
                  <h4 className="font-bold text-sm text-white">إنشاء سوبابيس (Supabase DB)</h4>
                  <p className="text-xs text-white/60 leading-relaxed">
                    توجه لموقع Supabase السحابي مجاناً، افتح مشروعك، وانسخ كود الجداول من تبويب "جداول SQL" بالأعلى ثم اضغط موافقة وبولير.
                  </p>
                </div>

                {/* Step 2 */}
                <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-3 relative overflow-hidden">
                  <div className="absolute top-2 left-4 text-6xl font-extrabold text-white/5 font-mono select-none">02</div>
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <h4 className="font-bold text-sm text-white">الحصول على مفاتيح الربط السريعة</h4>
                  <p className="text-xs text-white/60 leading-relaxed">
                    من إعدادات سوبابيس (Project Settings) انسخ كل من URL و Anon Key لحقنها في ملف الإعدادات للمتجر.
                  </p>
                </div>

                {/* Step 3 */}
                <div className="p-6 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-3 relative overflow-hidden">
                  <div className="absolute top-2 left-4 text-6xl font-extrabold text-white/5 font-mono select-none">03</div>
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-sm">
                    3
                  </div>
                  <h4 className="font-bold text-sm text-white">النشر الفوري على Vercel CLI</h4>
                  <p className="text-xs text-white/60 leading-relaxed">
                    افتح واجهة الأوامر في مجلد مشروعك، قم بكتابة <code className="text-brand-400 font-mono">vercel deploy --prod</code> لترفيع موقعك للزبائن الحقيقيين.
                  </p>
                </div>

              </div>

              {/* What to Click Guide */}
              <div className="p-6 rounded-2xl border border-dashed border-white/10 bg-white/5">
                <h4 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-brand-400" />
                  <span>دليل "ماذا تضغط؟" للمبتدئين للتفوق السحابي</span>
                </h4>
                
                <div className="space-y-3 text-xs text-white/70 leading-relaxed">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px] text-white font-bold shrink-0 mt-0.5">✓</span>
                    <p>
                      لتوليد النشرات، لا تقلق على الدومين؛ فيرسيل يمنحك اسماً مجانياً مشفراً تلقائياً بشهادة أمان SSL.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px] text-white font-bold shrink-0 mt-0.5">✓</span>
                    <p>
                      عند الدخول في سوبابيس، تأكد من وضع خيار <strong>Disable JWT verification</strong> أو الرابط الافتراضي فقط إذا كنت في بيئة تطويرية سريعة.
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px] text-white font-bold shrink-0 mt-0.5">✓</span>
                    <p>
                      لتنقية وعزل الهجوم؛ قاعدة البيانات محمية بجدار الحماية الناري المدمج RLS للحفاظ على سرية الصفقات وصورة السداد المرفوعة.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Commands */}
          {activeTab === 'commands' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {DEPLOYMENT_COMMANDS.map((cmd) => (
                <div key={cmd.id} className="p-5 rounded-2xl border border-white/10 bg-[#0a0f18] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      cmd.category === 'vercel' ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {cmd.category === 'vercel' ? 'فيـرسيل Vercel' : 'سوبابـيس Supabase'}
                    </span>
                    <span className="text-xs font-bold text-white">{cmd.label}</span>
                  </div>

                  <p className="text-[11px] text-white/50 leading-relaxed text-right">{cmd.description}</p>
                  
                  <div className="relative bg-[#05070a] border border-white/5 rounded-xl p-3 flex items-center justify-between gap-4">
                    <code className="text-[11px] font-mono text-[#1AAE8A] break-all text-left block w-full select-all">
                      {cmd.command}
                    </code>
                    <button
                      onClick={() => copyToClipboard(cmd.command, cmd.id)}
                      className="p-1.5 rounded-lg hover:bg-white/5 text-white/50 hover:text-white transition-colors cursor-pointer"
                      title="نسخ الأمر"
                    >
                      {copiedId === cmd.id ? (
                        <Check className="w-4 h-4 text-brand-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tab 3: Database */}
          {activeTab === 'database' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl border border-amber-500/20 bg-amber-500/5 text-xs text-amber-300 flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
                <p className="leading-relaxed">
                  <strong>نصيحة هامة:</strong> انسخ الأكواد البرمجية التالية لوضعها في محرر الاستعلامات (SQL Editor) على حساب Supabase الخاص بك لبناء الجداول وسياسات الأمن (RLS) فوراً.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Schema file */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-white/40 font-mono">schema.sql</span>
                    <button
                      onClick={() => copyToClipboard(sqlSchemaStr, 'sql-schema')}
                      className="text-xs text-brand-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      {copiedId === 'sql-schema' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>نسخ الهيكل SQL</span>
                    </button>
                  </div>
                  <pre className="bg-[#05070a] border border-white/10 rounded-xl p-4 text-[10px] font-mono text-white/75 overflow-x-auto h-64 text-left">
                    {sqlSchemaStr}
                    {`\n\n-- ... تم توليد الجداول لـ workers, jobs, payment_proofs بنجاح`}
                  </pre>
                </div>

                {/* RLS policy file */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-white/40 font-mono">rls.sql</span>
                    <button
                      onClick={() => copyToClipboard(sqlRlsStr, 'sql-rls')}
                      className="text-xs text-brand-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      {copiedId === 'sql-rls' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>نسخ سياسات RLS</span>
                    </button>
                  </div>
                  <pre className="bg-[#05070a] border border-white/10 rounded-xl p-4 text-[10px] font-mono text-white/75 overflow-x-auto h-64 text-left">
                    {sqlRlsStr}
                    {`\n\n-- ... تم تفعيل التأمين على جميع الجداول لمنع تسريب كشوفات CCP`}
                  </pre>
                </div>

              </div>
            </div>
          )}

          {/* Tab 4: Monetization */}
          {activeTab === 'monetization' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl border border-brand-500/20 bg-brand-500/5 text-xs text-brand-400 flex items-start gap-2.5">
                <Zap className="w-5 h-5 text-brand-400 shrink-0" />
                <p className="leading-relaxed">
                  <strong>نظم التحفيز والنمو:</strong> ريادة تدعم تسييل الأرباح ونمو المتاجر. يستطيع البائع الترقية لأي من الحزم التالية بدفعCCP أو بريدي موب بنظام التحقق اليدوي التام.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {MONETIZATION_PACKS.map((pack) => (
                  <div key={pack.id} className="flex flex-col rounded-2xl border border-white/10 bg-[#0a0f18] overflow-hidden p-6 hover:border-brand-500/40 transition-colors">
                    <div className="space-y-2 mb-4 shrink-0">
                      <span className={`text-[9px] font-extrabold px-2.5 py-0.5 rounded-full ${pack.badgeColor}`}>
                        {pack.badge}
                      </span>
                      <h3 className="font-bold text-sm text-white pt-1">{pack.name}</h3>
                      <div className="text-lg font-extrabold text-[#1AAE8A]">
                        {pack.priceDzd.toLocaleString('ar-DZ')} د.ج <span className="text-[10px] text-white/50 font-normal">/ {pack.durationDays} يوم</span>
                      </div>
                    </div>

                    <p className="text-[11px] text-white/60 leading-relaxed mb-4 text-right line-clamp-2">
                      {pack.salesPitch}
                    </p>

                    <div className="space-y-2 border-t border-white/5 pt-4 flex-1">
                      <h4 className="text-[10px] font-bold text-white/40">الامتيازات المكتسبة:</h4>
                      <ul className="space-y-1.5 text-[10px] text-white/70">
                        {pack.benefits.map((benefit, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-brand-400 shrink-0">•</span>
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-4 pt-4 border-t border-white/5 bg-white/2 rounded-xl p-3 text-[9px] text-[#1AAE8A] leading-relaxed">
                      <strong>الخطوة التالية:</strong> {pack.nextSteps}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
