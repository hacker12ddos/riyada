import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Settings2, Bell, Shield, Wallet, Store, MapPin, Download, Upload, QrCode, Trash2 } from 'lucide-react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { useToast } from '../contexts/ToastContext';
import { clearItems } from '../lib/db';
import { saveWorkers, saveJobs, saveApplications } from '../lib/economy';

export default function Settings() {
  const { activeWorkspace } = useWorkspace();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState('general');

  const exportStoreJson = () => {
    const data = JSON.stringify(activeWorkspace, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `riyada_store_${activeWorkspace?.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importStoreJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const data = JSON.parse(text);
        
        // Rough validation
        if (!data.id || !data.name) {
          throw new Error('Invalid store backup format');
        }

        // Just mock success for now since we are in local UI
        alert('تم استيراد بيانات المتجر بنجاح!');
        // Ideally we would add this to indexedDB workspaces and refresh context
        // const { addItem } = await import('../lib/db');
        // await addItem('workspaces', data);

      } catch (err) {
        console.error(err);
        alert('حدث خطأ أثناء قراءة الملف. الرجاء التأكد من أنه ملف صالح.');
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">إعدادات المتجر</h1>
          <p className="text-white/50">تكوين خيارات المتجر، التوصيل، والنسخ الاحتياطي.</p>
        </div>
        <Button>حفظ التغييرات</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="lg:col-span-1 p-4 h-fit border-l-2 border-l-brand-500 rounded-l-none bg-white/5">
          <nav className="flex flex-col gap-2">
            <button 
              onClick={() => setActiveTab('general')}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg w-full text-right transition-colors ${activeTab === 'general' ? 'bg-white/10 text-white' : 'text-white/50 hover:bg-white/5 hover:text-white'}`}
            >
              <Store className="w-5 h-5 opacity-70" />
              <span className="font-medium text-sm">عام</span>
            </button>
            <button 
              onClick={() => setActiveTab('backup')}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg w-full text-right transition-colors ${activeTab === 'backup' ? 'bg-white/10 text-white' : 'text-white/50 hover:bg-white/5 hover:text-white'}`}
            >
              <Download className="w-5 h-5 opacity-70" />
              <span className="font-medium text-sm">النسخ الاحتياطي والمشاركة</span>
            </button>
          </nav>
        </Card>

        {activeTab === 'general' && (
          <Card className="lg:col-span-3 space-y-6">
            <div className="space-y-4 border-b border-white/5 pb-6">
              <h2 className="text-lg font-bold text-white">معلومات المتجر</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input 
                  label="اسم المتجر"
                  defaultValue={activeWorkspace?.name}
                />
                <Input 
                  label="رقم الهاتف الأساسي"
                  defaultValue={activeWorkspace?.phone}
                  dir="ltr"
                />
              </div>
              
              <div className="space-y-1.5">
                <label className="block text-sm font-medium text-white/70">الولاية (المقر الرئيسي)</label>
                <select className="glass-input flex h-11 w-full rounded-xl px-4 py-2 text-sm text-white appearance-none">
                  <option className="bg-[#0a0f18]">{activeWorkspace?.settings?.wilaya || 'الجزائر العاصمة'} - الولاية الحالية</option>
                </select>
              </div>
              
              <div className="space-y-1.5">
                <label className="block text-sm font-medium text-white/70">وصف النشاط</label>
                <textarea 
                  className="glass-input flex min-h-[100px] w-full rounded-xl px-4 py-3 text-sm text-white resize-none"
                  placeholder="وصف مختصر للمتجر..."
                  defaultValue={activeWorkspace?.type === 'retail' ? 'تجارة تجزئة عامة' : 'خدمات عامة'}
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button variant="ghost">إلغاء</Button>
              <Button>تطبيق التغييرات</Button>
            </div>
          </Card>
        )}

        {activeTab === 'backup' && (
          <Card className="lg:col-span-3 space-y-6 p-6 md:p-8">
            <div className="space-y-8">
              <div>
                <h2 className="text-xl font-bold text-white mb-2">تصدير المتجر</h2>
                <p className="text-sm text-white/60 mb-4 max-w-xl">
                  نظراً لأن منصة ريادة تعمل بدون خوادم مركزية (No-Backend)، يمكنك تصدير بيانات متجرك وحفظها كملف احتياطي أو مشاركتها مع أجهزة أخرى.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col items-center text-center hover:border-brand-500/50 transition-colors">
                    <div className="w-16 h-16 bg-brand-500/10 rounded-full flex items-center justify-center mb-4">
                      <Download className="w-8 h-8 text-brand-400" />
                    </div>
                    <h3 className="font-bold text-white mb-2">تصدير JSON</h3>
                    <p className="text-xs text-white/50 mb-4">حفظ المنتجات وبيانات المتجر في ملف</p>
                    <Button onClick={exportStoreJson} className="w-full">تحميل الملف</Button>
                  </div>
                  
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col items-center text-center opacity-50 cursor-not-allowed">
                    <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-4">
                      <QrCode className="w-8 h-8 text-white/40" />
                    </div>
                    <h3 className="font-bold text-white mb-2">رمز الاستجابة السريعة (QR)</h3>
                    <p className="text-xs text-white/50 mb-4">مشاركة المتجر عبر شاشة الهاتف (قريباً)</p>
                    <Button disabled className="w-full">إنشاء QR Share</Button>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-white/5 offset-y-4">
                <h2 className="text-xl font-bold text-white mb-2">استيراد المتجر</h2>
                <p className="text-sm text-white/60 mb-6 max-w-xl">
                  قم بتحميل ملف JSON لاستعادة متجرك أو نقله إلى هذا الجهاز.
                </p>
                <div className="relative border-2 border-dashed border-white/10 rounded-2xl p-8 flex flex-col items-center justify-center bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group">
                  <input 
                    type="file" 
                    accept=".json" 
                    onChange={importStoreJson}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <Upload className="w-8 h-8 text-white/30 group-hover:text-brand-400 mb-2 transition-colors" />
                  <span className="text-sm font-medium text-white mb-1">اضغط لاختيار ملف JSON</span>
                  <span className="text-xs text-white/40">أو اسحب الملف وأفلته هنا</span>
                </div>
              </div>

              {/* Danger Zone */}
              <div className="pt-6 border-t border-[#dc2626]/20 mt-4 text-right">
                <h2 className="text-xl font-bold text-[#f87171] mb-2 flex items-center gap-2 justify-end">
                  <span>منطقة العمليات الحساسة (Danger Zone)</span>
                  <Trash2 className="w-5 h-5 text-[#f87171]" />
                </h2>
                <p className="text-sm text-white/60 mb-6 max-w-xl">
                  تطهير المنصة وحذف كافة عروض السلع والخدمات المودعة، عروض التوظيف المضافة، طلبات التوظيف والعمال المسجلين للبدء فوراً بمتجر فارغ وحقيقي.
                </p>
                <div className="bg-[#ef4444]/5 border border-[#ef4444]/20 rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h3 className="font-bold text-white text-sm">حذف وتطهير البيانات الافتراضية والوهمية</h3>
                    <p className="text-xs text-white/40">سيمسح السلع، الخدمات، العمال والعروض نهائياً من الذاكرة المحلية والـ IndexedDB.</p>
                  </div>
                  <button 
                    onClick={async () => {
                      if (window.confirm("هل أنت متأكد من رغبتك في حذف كافة السلع، الخدمات، عروض التوظيف، والعمال بشكل نهائي؟ لا يمكن التراجع عن هذا الإجراء.")) {
                        try {
                          await clearItems('products');
                          saveWorkers([]);
                          saveJobs([]);
                          saveApplications([]);
                          showToast('تم بنجاح تطهير المتجر وحذف كافة السلع والخدمات والوظائف والعمال!', 'success');
                        } catch (err) {
                          console.error(err);
                          showToast('حدث خطأ أثناء محاولة التطهير.', 'error');
                        }
                      }
                    }}
                    className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4 text-white" />
                    <span>تطهير وحذف كل السلع والوظائف والعمال</span>
                  </button>
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
