import React, { useState, useEffect } from 'react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { useToast } from '../contexts/ToastContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Store, 
  TrendingUp, 
  Zap, 
  Layers, 
  HelpCircle, 
  Activity, 
  Coins, 
  DollarSign, 
  ShoppingBag, 
  FileText, 
  Check, 
  ShieldCheck, 
  Star, 
  FolderPlus, 
  Flame, 
  ArrowLeft,
  RefreshCw,
  Image,
  Award,
  Users,
  Briefcase,
  AlertTriangle,
  Package,
  Wrench,
  Clock,
  ExternalLink,
  Lock,
  ChevronDown,
  Upload,
  Plus
} from 'lucide-react';
import { getItemsByWorkspace, addItem } from '../lib/db';
import { getWorkers, getJobs } from '../lib/economy';
import { formatDZD } from '../lib/utils';

// Monetization Items Schema
interface DFYService {
  id: string;
  name: string;
  price: number;
  description: string;
  icon: any;
  bulletPoints: string[];
}

interface ProductPack {
  id: string;
  name: string;
  price: number;
  isPopular?: boolean;
  bulletPoints: string[];
  description: string;
}

interface BoostOption {
  id: string;
  name: string;
  priceModel: string;
  durations: { label: string; price: number; days: number }[];
  description: string;
  badgeLabel: 'sponsored' | 'boosted' | 'featured' | 'priority';
}

interface Bundle {
  id: string;
  name: string;
  price: number;
  components: string[];
  description: string;
}

interface Subscription {
  id: string;
  name: string;
  price: number;
  interval: string;
  description: string;
  benefits: string[];
}

interface HighIncomeAddon {
  id: string;
  name: string;
  price: number;
  category: 'content' | 'database' | 'theme' | 'analytics';
  description: string;
}

// Simulated Local Database Schema for Transactions
interface MonetizationTx {
  id: string;
  itemName: string;
  amount: number;
  submittedAmount?: number;
  method: 'chargily' | 'baridimob' | 'cash';
  status: 'initiated' | 'awaiting_payment' | 'payment_submitted' | 'under_review' | 'approved' | 'rejected' | 'expired';
  txReference?: string;
  createdAt: number;
  paymentTimestamp?: string;
  associatedId?: string; // product/worker ID
  durationDays?: number;
  receiptFileName?: string;
  receiptFileContent?: string;
  securityFlags?: string[];
}

export default function SellerMonetization() {
  const { activeWorkspace } = useWorkspace();
  const { success, error: toastError } = useToast();

  const [activeTab, setActiveTab] = useState<'dfy' | 'packs' | 'boosts' | 'add-ons' | 'txs'>('dfy');
  const [products, setProducts] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<MonetizationTx[]>([]);

  // Selection & Checkout States
  const [selectedItem, setSelectedItem] = useState<{ name: string; price: number; type: string; id: string } | null>(null);
  const [selectedDurationIndex, setSelectedDurationIndex] = useState<number>(0);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [payMode, setPayMode] = useState<'chargily' | 'baridimob' | 'cash'>('chargily');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [txRefInput, setTxRefInput] = useState('');
  
  // Custom manual payment states (reconciliation fields)
  const [txTimestampInput, setTxTimestampInput] = useState(() => {
    const d = new Date();
    return d.toISOString().slice(0, 16); // e.g., '2026-05-20T22:54'
  });
  const [txAmountInput, setTxAmountInput] = useState('');
  const [receiptFileName, setReceiptFileName] = useState('');
  const [receiptFileContent, setReceiptFileContent] = useState('');
  const [hasReceiptFile, setHasReceiptFile] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  const [showInvoiceSimulator, setShowInvoiceSimulator] = useState(false);
  const [isSimulatingWeb, setIsSimulatingWeb] = useState(false);

  // Load local mock db items
  useEffect(() => {
    if (activeWorkspace) {
      getItemsByWorkspace('products', activeWorkspace.id).then(setProducts);
    }
    const savedTxs = localStorage.getItem(`riyada_monetization_txs_${activeWorkspace?.id || 'global'}`);
    if (savedTxs) {
      try {
        setTransactions(JSON.parse(savedTxs));
      } catch (e) {
        console.error(e);
      }
    }
  }, [activeWorkspace]);

  const saveTxs = (newTxs: MonetizationTx[]) => {
    setTransactions(newTxs);
    localStorage.setItem(`riyada_monetization_txs_${activeWorkspace?.id || 'global'}`, JSON.stringify(newTxs));
  };

  // 1. DONE-FOR-YOU SETUP SERVICES
  const dfyServices: DFYService[] = [
    {
      id: 'dfy_store_setup',
      name: '🛠️ إنشاء وتجهيز المتجر الكامل والرفع',
      price: 2500,
      description: 'نأخذ بياناتك وصورتك ونقوم بإنشاء متجر متكامل بالخيارات الصحيحة لتبدأ البيع فوراً.',
      icon: Store,
      bulletPoints: ['تصميم الشعار وتعديل صورة الخلفية', 'كتابة نبذة ترويجية مقنعة وجذابة للجزائريين', 'تنسيق الفئات والولايات المعتمدة لتوصيل CCP']
    },
    {
      id: 'dfy_listing_optim',
      name: '🚀 المساعد الاحترافي لرفع المعروضات',
      price: 1500,
      description: 'تعبئة وتحسين أول 15 منتج أو خدمة في مخزن متجرك مع تصنيفات دقيقة ووصف آسر زبائن الجزائر.',
      icon: FolderPlus,
      bulletPoints: ['تسمية المنتجات بمرادفات البحث الشائعة', 'مسح الخلفية من الصور لجعلها بيضاء تماماً', 'كتابة صياغات بيع عاطفية تسرع الطلبيات']
    },
    {
      id: 'dfy_poster_design',
      name: '🎨 مولّد ومصمم ملصقات الترويج (DFY Posters)',
      price: 1000,
      description: 'نسلمك 3 تصميمات جاهزة لمنتجاتك مخصصة لمشاركتها في مجموعات الفيسبوك والواتساب لضمان الانتشار العضوي.',
      icon: Image,
      bulletPoints: ['تصاميم بمقاسات Story و Square الملائمة', 'إضافة شعار متجرك والباركود QR الفريد الخاص بريادة', 'عناوين بارزة ملونة محفزة للشراء']
    },
    {
      id: 'dfy_launch_pack',
      name: '⭐️ باقة الانطلاق المتكاملة السريعة',
      price: 4500,
      description: 'كل ما تحتاجه للظفر بأول 50 زبون: إنشاء المتجر + الرموز التعبيرية + 10 سلع محسنة + تصميم بوستر الترويج الفيروسي.',
      icon: Award,
      bulletPoints: ['إنشاء المتجر + شارة التوثيق الذهبية', 'إدراج دقيق للسلع وبوسترات الترويج', 'تمويه معرّفات العمليات لحمايتك من CCP المزيف']
    },
    {
      id: 'dfy_verification_review',
      name: '🛡️ مراجعة وتدقيق التوثيق الرسمي (Identity & Verification Review)',
      price: 1800,
      description: 'جلسة تدقيق أمني ومعالجة هوية رسمية لوثائق بائع ريادة للحصول على شارة التوثيق الأخضر المرموقة وتجنب الحظر CCP.',
      icon: ShieldCheck,
      bulletPoints: ['مطابقة الاسم التجاري ومقارنة معلومات الهواتف للولاية', 'إدراج الختم الأخضر "Identity Verified" بجانب الحساب شرفياً', 'أولوية قصوى ودعم فوري عند النزاعات مع المشترين']
    }
  ];

  // 2. PRODUCTIZED SERVICE PACKS (Good / Better / Best)
  const productPacks: ProductPack[] = [
    {
      id: 'pack_starter',
      name: '📦 الباقة الأساسية (Starter Offer)',
      price: 1200,
      description: 'مثالية للحرفيين والمتاجر المصغرة المستقلة لبناء هوية موثوقة في الجزائر.',
      bulletPoints: ['إعداد وتجهيز المتجر اللامركزي محلياً', 'رفع وتحسين 10 منتجات حصرية', 'توليد البطاقة الترويجية ومسح الباركود QR الفريد']
    },
    {
      id: 'pack_growth',
      name: '⚡ باقة النمو الهائل (Growth Offer - الموصى بها)',
      price: 2800,
      isPopular: true,
      description: 'الخيار الذهبي المفضل للشركات الصغيرة والورش الحرة لضمان تدفق مستمر للطلبات.',
      bulletPoints: ['تجهيز ورفع 30 منتج مع تحسين صور الخلفية', 'فتحة ترويجية VIP مضمونة بالتناوب بالصفحة الرئيسية لولايتك', 'باقة التحليلات المتقدمة لمراقبة الزوار وقمع الشراء']
    },
    {
      id: 'pack_elite',
      name: '👑 باقة الصفوة النخبة (Elite Offer)',
      price: 5200,
      description: 'للمستوردين واصحاب المحلات الكبيرة الذين يريدون فرض سيطرتهم على مخزون الولايات.',
      bulletPoints: ['مساعد شخصي مخصص للتفريغ والرفع غير المحدود لسجل السلع', 'شارة التوثيق المذهبة الحصرية "بائع نخبة معتمد"', 'صياغة 5 قوالب تسويق موسمية لبوسترات واتساب']
    }
  ];

  // 3. BOOST ECONOMY (Homepage, Category, Wilaya, Worker, Job, Search Slots)
  const boostOptions: BoostOption[] = [
    {
      id: 'boost_home',
      name: '🏠 ترقية صدارة الصفحة الرئيسية العامة',
      priceModel: 'دفع مقابل الظهور الرائد (PPI)',
      durations: [
        { label: '24 ساعة الخاطفة', price: 300, days: 1 },
        { label: '72 ساعة النشطة', price: 700, days: 3 },
        { label: '7 أيام الطويلة', price: 1500, days: 7 },
        { label: '14 يوماً الكافية', price: 2500, days: 14 }
      ],
      badgeLabel: 'featured',
      description: 'وضع معروضك أو متجرك في صدارة ريادة ليرتفع حجم مشاهدي المحل فور فتح المنصة.'
    },
    {
      id: 'boost_category',
      name: '👑 السيادة الشاملة على فئة معينة',
      priceModel: 'الدفع لكل نقرة زبون (PPC)',
      durations: [
        { label: '24 ساعة الخاطفة', price: 200, days: 1 },
        { label: '72 ساعة النشطة', price: 450, days: 3 },
        { label: '7 أيام الطويلة', price: 900, days: 7 },
        { label: '14 يوماً الكافية', price: 1600, days: 14 }
      ],
      badgeLabel: 'boosted',
      description: 'عند تصفح المشترين لتصنيف معين (سلع، خدمة حرة الخ) يظهر معروضك دائماً بالقمة متبوعاً بشارة بريق.'
    },
    {
      id: 'boost_wilaya',
      name: '🎯 تسليط الضوء الإقليمي بالولاية (Wilaya Spotlight)',
      priceModel: 'الدفع مقابل Inquiry / الطلب المباشر',
      durations: [
        { label: '24 ساعة الخاطفة', price: 150, days: 1 },
        { label: '72 ساعة النشطة', price: 350, days: 3 },
        { label: '7 أيام الطويلة', price: 800, days: 7 },
        { label: '14 يوماً الكافية', price: 1400, days: 14 }
      ],
      badgeLabel: 'sponsored',
      description: 'أقوى وسيلة ترويج: سلعك ستتصدر بصفة رئيسية لجميع الباحثين المقيمين في ولايتك المختارة لزيادة المبيعات المحلية.'
    },
    {
      id: 'boost_search',
      name: '🔍 المركز الأول الثابت في البحث الشامل',
      priceModel: 'الدفع لكل Lead / محادثة واتساب عازمة',
      durations: [
        { label: '24 ساعة الخاطفة', price: 250, days: 1 },
        { label: '72 ساعة النشطة', price: 550, days: 3 },
        { label: '7 أيام الطويلة', price: 1100, days: 7 },
        { label: '14 يوماً الكافية', price: 2000, days: 14 }
      ],
      badgeLabel: 'priority',
      description: 'الظهور في أول خانة فور بحث العميل عن أي كلمة مفتاحية مقاربة لاسم معروضك لسرعة الشراء.'
    }
  ];

  // 4. BUNDLES & HIGH INCOME ADD-ONS
  const optionalAddons: HighIncomeAddon[] = [
    { id: 'addon_bulk_upload', name: '📦 خدمة الرفع السريع الجماعي (Bulk Upload)', price: 800, category: 'database', description: 'تصدير واستيراد سلع المتجر من جداول اكسل أو متاجر شوبيفاي بنقرة واحدة وتوفير الوقت.' },
    { id: 'addon_image_comp', name: '⚡ ضغط وتصغير الصور ومطابقة الويب', price: 400, category: 'theme', description: 'تقليل حجم صور منتجاتك بـ 80% دون المساس بالجودة وتصحيح العرض بالهواتف الضعيفة.' },
    { id: 'addon_desc_cleanup', name: '✍️ تحسين وصياغة أوصاف مخزونك بالكامل', price: 600, category: 'content', description: 'إعادة مراجعة كتابية ونحوية لمنتجاتك لتبدو كشركة وطنية عريقة ذات ثقة بالجزائر.' },
    { id: 'addon_crm_pack', name: '📊 باقة إدارة علاقات الزبائن المتكررين (CRM)', price: 900, category: 'analytics', description: 'توليد وسائط وإحصائيات متقدمة للعملاء الموالين وتلقي إشعارات الحفز التلقائية لواتساب.' }
  ];

  const bundles: Bundle[] = [
    {
      id: 'bundle_poster_optim',
      name: '🎯 حزمة البوستر الاحترافي وتحسين المعروض',
      price: 1800,
      description: 'نجمع لك خدمتين لرفع كفاءة النشر العضوي بريادة لولاية بومرداس و58 ولاية.',
      components: ['صياغة الأوصاف بدقة تامة', 'تصميم 3 بوسترات جذابة مع QR المتجر']
    },
    {
      id: 'bundle_boost_analytics',
      name: '📈 حزمة الصدارة والتحليلات البلاتينية المعمقة',
      price: 2200,
      description: 'الخيار التحليلي المتين: ترقية بحث الولاية لـ 7 أيام + فتح تبويب تحويل زوار لوحة التحكم.',
      components: ['ترقية الظهور Spot لولاية نشاطك', 'فتح مخطط قمع تتبع الزوار محلياً']
    }
  ];

  // Subscription care plans
  const subscriptionPlans: Subscription[] = [
    {
      id: 'sub_seller_care',
      name: '🛡️ خطة الرعاية المتكاملة للبائع',
      price: 1500,
      interval: 'شهرياً',
      description: 'دعم تقني وتحديث متواصل محلي لحجز سلعك والحماية الشاملة من إيصالات CCP الاحتيالية.',
      benefits: ['الرصد التلقائي لعناوين IP الحوالات المشبوهة', 'تجديد تلقائي لظهور سلعك الميتة دورياً', 'مستشار واتساب للتوجيه وحل المشاكل']
    },
    {
      id: 'sub_promotion_calendar',
      name: '📅 رزنامة الترويج ونمذجة الفعاليات التجارية',
      price: 1200,
      interval: 'شهرياً',
      description: 'خطط ترويج جاهزة تلائم أعياد ومناسبات سوق الجزائر للحفاظ على معدل بيع عالي.',
      benefits: ['تصاميم أسبوعية مخصصة للجمعة السوداء وعاشوراء والأعياد', 'تقارير دورية لأكثر المنتجات طلباً بالولايات المجاورة', 'أولوية الظهور في قسم الراعي المميز للعمال']
    }
  ];

  // Initiate purchase flow
  const handleSelectUpgrade = (item: { name: string; price: number; type: string; id: string }) => {
    setSelectedItem(item);
    // Reset selections and form values
    setSelectedDurationIndex(0);
    setSelectedProductId('');
    setTxRefInput('');
    setTxTimestampInput(new Date().toISOString().slice(0, 16));
    setTxAmountInput('');
    setReceiptFileName('');
    setReceiptFileContent('');
    setHasReceiptFile(false);
    setIsCheckingOut(true);
  };

  const handleCheckoutProcess = () => {
    if (!selectedItem) return;

    let finalPrice = selectedItem.price;
    let durationOfBoost = 0;

    // Adjust price for durations in boosts
    if (selectedItem.type === 'boost') {
      const bOpt = boostOptions.find(b => b.id === selectedItem.id);
      if (bOpt) {
        const dur = bOpt.durations[selectedDurationIndex];
        finalPrice = dur.price;
        durationOfBoost = dur.days;
      }
    }

    if (selectedItem.type === 'boost' && !selectedProductId) {
      toastError('يرجى اختيار السلعة', 'الرجاء اختيار أحد المعروضات من متجرك لربط باقة الترويج بها.');
      return;
    }

    if (payMode === 'chargily') {
      setIsSimulatingWeb(true);
      setTimeout(() => {
        setIsSimulatingWeb(false);
        setShowInvoiceSimulator(true);
      }, 1500);
    } else {
      // Manual/Offline payment
      const trimmedRef = txRefInput.trim();
      if (!trimmedRef) {
        toastError('رمز الحوالة فارغ', 'الرجاء كتابة رقم المعاملة للتحقق المطابق.');
        return;
      }

      if (!txTimestampInput) {
        toastError('تاريخ العملية مطلوب', 'الرجاء تحديد تاريخ ووقت تحويل رصيد الحوالة بدقة.');
        return;
      }

      const inputAmount = Number(txAmountInput);
      if (!txAmountInput || isNaN(inputAmount) || inputAmount <= 0) {
        toastError('المبلغ المصرح به غير صالح', 'الرجاء تحديد القيمة التي تم إرسالها بالدينار (DZD) بدقة.');
        return;
      }

      // 🔍 Security Check Pipeline
      const flags: string[] = [];

      // 1. Detect duplicate proofs
      const txidLower = trimmedRef.toLowerCase();
      const isDuplicate = transactions.some(
        tx => tx.txReference?.trim().toLowerCase() === txidLower && tx.status !== 'rejected'
      );
      if (isDuplicate) {
        flags.push('duplicate_proof');
      }

      // 2. Mismatched amount audit
      if (inputAmount !== finalPrice) {
        flags.push('mismatched_amount');
      }

      // 3. Repeated upload detection (flooding warning)
      const lastUploadsCount = transactions.filter(
        tx => tx.method === payMode && (Date.now() - tx.createdAt < 3 * 60 * 1000)
      ).length;
      if (lastUploadsCount >= 2) {
        flags.push('repeated_upload');
      }

      // Construct and record the transaction with local metadata
      const newTx: MonetizationTx = {
        id: `RYD-TX-${Math.floor(100000 + Math.random() * 900000)}`,
        itemName: selectedItem.name + (durationOfBoost ? ` (${durationOfBoost} أيام)` : ''),
        amount: finalPrice,
        submittedAmount: inputAmount,
        method: payMode,
        status: 'payment_submitted', // marks as pending review
        txReference: trimmedRef,
        createdAt: Date.now(),
        paymentTimestamp: txTimestampInput,
        associatedId: selectedProductId || undefined,
        durationDays: durationOfBoost || undefined,
        receiptFileName: receiptFileName || undefined,
        receiptFileContent: receiptFileContent || undefined,
        securityFlags: flags.length > 0 ? flags : undefined
      };

      saveTxs([newTx, ...transactions]);

      if (flags.includes('duplicate_proof')) {
        toastError(
          'تنبيه أمني مرصود',
          'بصمة أو مرجع هذا الوصل مستعملة مسبقاً! تم حفظ الطلب مع وسمه بـ "تكرار الإيصال" لإخطار لوحة مراجعة المالك.'
        );
      } else if (flags.includes('mismatched_amount')) {
        toastError(
          'مبلغ غير متطابق',
          `المبلغ الذي قمت بمصادقته (${formatDZD(inputAmount)}) لا يطابق كلفة الخدمة المقدرة بـ (${formatDZD(finalPrice)}). تم تسجيل التنبيه أوتوماتيكياً.`
        );
      } else {
        success('تم تقديم إثبات الدفع', 'تم تقديم إشعار الترقية يدوياً بنجاح، ملفك قيد التدقيق الأمني الاسبوعي.');
      }

      setIsCheckingOut(false);
      setSelectedItem(null);
      setActiveTab('txs');
    }
  };

  const handleChargilySimulatorCallback = (outcome: 'approved' | 'rejected') => {
    setShowInvoiceSimulator(false);
    if (!selectedItem) return;

    let finalPrice = selectedItem.price;
    let durationOfBoost = 0;

    if (selectedItem.type === 'boost') {
      const bOpt = boostOptions.find(b => b.id === selectedItem.id);
      if (bOpt) {
        const dur = bOpt.durations[selectedDurationIndex];
        finalPrice = dur.price;
        durationOfBoost = dur.days;
      }
    }

    const newTx: MonetizationTx = {
      id: `RYD-TX-${Math.floor(100000 + Math.random() * 900000)}`,
      itemName: selectedItem.name + (durationOfBoost ? ` (${durationOfBoost} أيام)` : ''),
      amount: finalPrice,
      method: 'chargily',
      status: outcome === 'approved' ? 'payment_submitted' : 'rejected',
      txReference: `CHG-${Math.floor(1000000 + Math.random() * 9000000)}`,
      createdAt: Date.now(),
      associatedId: selectedProductId || undefined,
      durationDays: durationOfBoost || undefined
    };

    saveTxs([newTx, ...transactions]);
    if (outcome === 'approved') {
      success('ترصيد المعاملة لـ Chargily', 'تم الاتصال ببوابة Chargily الجزائرية وتوجيه الإشعار كـ "مقدم وفي انتظار المراجعة والأولوية".');
    } else {
      toastError('تم إلغاء الدفع', 'أغلقت بوابة الدفع الافتراضية.');
    }
    setIsCheckingOut(false);
    setSelectedItem(null);
    setActiveTab('txs');
  };

  // ADMIN CONTROL OVERRIDE FOR HIGHEST PERSISTENT VALUES
  const handleAdminApprove = async (tx: MonetizationTx, action: 'approved' | 'rejected' | 'expired') => {
    const updated = transactions.map(t => {
      if (t.id === tx.id) {
        return { ...t, status: action };
      }
      return t;
    });
    saveTxs(updated);

    if (action === 'approved') {
      success('تم التفعيل رسمياً ✨', `تمت الموافقة والمصادقة على باقة "${tx.itemName}" بنجاح!`);
      
      // Persist features locally
      if (tx.itemName.includes('فئة') || tx.itemName.includes('الصفحة الرئيسية') || tx.itemName.includes('الولاية') || tx.itemName.includes('البحث')) {
        // Boost item
        if (tx.associatedId) {
          try {
            const dbProducts = await getItemsByWorkspace('products', activeWorkspace?.id || '');
            const targetPr = dbProducts.find(p => p.id === tx.associatedId);
            if (targetPr) {
              targetPr.sponsored = true;
              targetPr.dynamicData = {
                ...targetPr.dynamicData,
                boostedAt: Date.now(),
                boostDays: tx.durationDays || 3
              };
              await addItem('products', targetPr);
            }
          } catch (e) {
            console.error(e);
          }
        }
      } else if (tx.itemName.includes('إنشاء وتجهيز') || tx.itemName.includes('باقة الانطلاق') || tx.itemName.includes('النخبة')) {
        localStorage.setItem(`riyada_gold_verified_${activeWorkspace?.id}`, 'true');
      } else if (tx.itemName.includes('التحليلات البلاتينية') || tx.itemName.includes('باقة النمو')) {
        localStorage.setItem(`riyada_platinum_analytics_${activeWorkspace?.id}`, 'true');
      }
    } else {
      toastError('تم رفض الباقة', 'تم تصنيف إشعار CCP الدفع كـ مرفوض / تصفير البيانات.');
    }
  };

  const isGoldUnlocked = localStorage.getItem(`riyada_gold_verified_${activeWorkspace?.id}`) === 'true';

  return (
    <div className="flex flex-col gap-6 h-full pb-8 text-right" dir="rtl">
      
      {/* 1. HERO HEADER AREA */}
      <div className="bg-[#0e141c] border border-brand-500/15 rounded-2xl p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 left-0 bg-brand-500 text-black px-3 py-1 font-black text-[10px] rounded-br-2xl flex items-center gap-1.5 uppercase">
          <Sparkles className="w-3.5 h-3.5" />
          <span>مركز نمو ومصادر دخل ريادة v22</span>
        </div>

        <div className="space-y-2 mt-2">
          <h2 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
            <Coins className="w-6 h-6 text-brand-400" />
            <span>بوابة توليد دخل واستثمارات ريادة (Riyada Growth Hub)</span>
          </h2>
          <p className="text-xs text-white/60 leading-relaxed max-w-4xl">
            نحن نلتزم بالقاعدة الاقتصادية الفضلى: <strong className="text-brand-400">لا نغلق تصفح السلع أو إنشاء المتاجر أو مراسلات واتساب خلف جدران الدفع</strong>. 
            تتم مبيعاتك الأساسية مجاناً بالكامل. ولكن لمضاعفة حجم أعمالك والظفر بزبائن الولايات بسرعة، نقدّم لك باقات done-for-you الاحترافية وترقيات الظهور الآني مع الاحتفاظ وحماية الخصوصية المطلقة.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap gap-2 mt-6 border-t border-white/5 pt-4">
          <button
            onClick={() => { setActiveTab('dfy'); setIsCheckingOut(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'dfy' 
                ? 'bg-[#18C29C] text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>خدمات Done-For-You 🛠️</span>
          </button>
          
          <button
            onClick={() => { setActiveTab('packs'); setIsCheckingOut(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'packs' 
                ? 'bg-[#18C29C] text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>باقات الترقية والنمو الأساسية 📊</span>
          </button>

          <button
            onClick={() => { setActiveTab('boosts'); setIsCheckingOut(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'boosts' 
                ? 'bg-[#18C29C] text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            <span>اقتصاد زيادة المشاهدات والظهور (Boosts) ⚡</span>
          </button>

          <button
            onClick={() => { setActiveTab('add-ons'); setIsCheckingOut(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'add-ons' 
                ? 'bg-[#18C29C] text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <FolderPlus className="w-3.5 h-3.5 text-blue-400" />
            <span>أدوات إضافية وحزم مبيعات ذكية ✨</span>
          </button>

          <button
            onClick={() => { setActiveTab('txs'); setIsCheckingOut(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 relative ${
              activeTab === 'txs' 
                ? 'bg-[#18C29C] text-black shadow-lg shadow-brand-500/10' 
                : 'bg-white/5 hover:bg-white/10 text-white/70'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>حالات الدفع والتحقق 💳</span>
            {transactions.filter(t => t.status === 'payment_submitted').length > 0 && (
              <span className="w-2 h-2 rounded-full bg-orange-500 absolute -top-0.5 -left-0.5 animate-ping"></span>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* LEFT TWO COLUMNS: DISPLAY AREA */}
        <div className="xl:col-span-2 space-y-6">
          
          <AnimatePresence mode="wait">
            
            {/* TAB 1: DONE FOR YOU SETUP SERVICES */}
            {activeTab === 'dfy' && !isCheckingOut && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-5"
              >
                {dfyServices.map((service) => {
                  const SvgIcon = service.icon;
                  return (
                    <Card key={service.id} className="p-5 bg-[#0E141C] border border-white/5 flex flex-col justify-between hover:border-[#18C29C]/30 transition-all gap-4">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 rounded-xl bg-white/5 text-[#18C29C]">
                            <SvgIcon className="w-5 h-5" />
                          </div>
                          <h4 className="text-sm font-bold text-white leading-tight">{service.name}</h4>
                        </div>
                        <p className="text-[11px] text-white/50 leading-relaxed">{service.description}</p>
                        
                        <div className="space-y-1.5 border-t border-white/5 pt-2.5">
                          {service.bulletPoints.map((bp, i) => (
                            <div key={i} className="flex gap-2 items-center text-[10px] text-white/70">
                              <Check className="w-3 h-3 text-[#18C29C] shrink-0" />
                              <span>{bp}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex justify-between items-center border-t border-white/5 pt-3 mt-auto">
                        <div className="flex flex-col">
                          <span className="text-[10px] text-white/40">الدفع لمرة واحدة:</span>
                          <span className="text-xs font-mono font-black text-emerald-400">{formatDZD(service.price)}</span>
                        </div>
                        <Button 
                          onClick={() => handleSelectUpgrade({ id: service.id, name: service.name, price: service.price, type: 'dfy' })}
                          className="bg-brand-500 hover:bg-brand-600 font-bold text-[10px] h-7 px-3 text-black"
                        >
                          طلب الخدمة الآن 🚀
                        </Button>
                      </div>
                    </Card>
                  );
                })}
              </motion.div>
            )}

            {/* TAB 2: POWERED SERVICE PACKS (BASIC/GROWTH/ELITE) */}
            {activeTab === 'packs' && !isCheckingOut && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {productPacks.map((pack) => (
                    <Card 
                      key={pack.id} 
                      className={`p-5 flex flex-col justify-between transition-all gap-5 relative ${
                        pack.isPopular 
                          ? 'bg-[#151c28] border-brand-500 shadow-2xl scale-[1.02]' 
                          : 'bg-[#0E141C] border border-white/5'
                      }`}
                    >
                      {pack.isPopular && (
                        <span className="absolute -top-2.5 right-4 bg-brand-500 text-black text-[9px] px-2 py-0.5 rounded-full font-black uppercase">
                          الأكثر طلباً واختياراً 🔥
                        </span>
                      )}

                      <div className="space-y-3">
                        <h4 className="text-xs font-black text-white">{pack.name}</h4>
                        <p className="text-[10px] text-white/60 leading-relaxed">{pack.description}</p>
                        <div className="space-y-1.5 border-t border-white/5 pt-3">
                          {pack.bulletPoints.map((bullet, i) => (
                            <div key={i} className="flex gap-1.5 items-start text-[10px] text-white/85">
                              <Check className="w-3 h-3 text-[#18C29C] shrink-0 mt-0.5" />
                              <p className="leading-snug">{bullet}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3">
                        <div className="flex justify-between items-center mb-3">
                          <span className="text-[10px] text-white/40">مجموع الرسوم الكلية:</span>
                          <strong className="text-sm font-black text-emerald-400 font-mono">{formatDZD(pack.price)}</strong>
                        </div>
                        <Button 
                          onClick={() => handleSelectUpgrade({ id: pack.id, name: pack.name, price: pack.price, type: 'pack' })}
                          className={`w-full text-[10px] h-8 font-black ${pack.isPopular ? 'bg-brand-500 text-black' : 'bg-white/5 hover:bg-white/10 text-white'}`}
                        >
                          شراء الباقة المبرزة
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>

                {/* Subscriptions section */}
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <h3 className="text-xs font-bold text-[#18C29C] tracking-wide block">📅 اشتراكات الرعاية والتفعيل الإستراتيجي اللامحدود</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {subscriptionPlans.map(sub => (
                      <Card key={sub.id} className="p-5 bg-gradient-to-br from-[#0c1421] to-[#070c14] border border-white/5 gap-4 flex flex-col justify-between">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <h4 className="text-xs font-black text-white">{sub.name}</h4>
                            <span className="text-[10px] text-brand-400 bg-brand-500/10 px-2 rounded-md font-mono">{sub.price} دج / {sub.interval === 'شهرياً' ? 'شهر' : 'سنة'}</span>
                          </div>
                          <p className="text-[10px] text-white/50 leading-relaxed">{sub.description}</p>
                          <div className="space-y-1 pt-2.5">
                            {sub.benefits.map((b, i) => (
                              <div key={i} className="flex gap-2 items-center text-[10px] text-white/70">
                                <Check className="w-3 h-3 text-[#18C29C]" />
                                <span>{b}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <Button 
                          onClick={() => handleSelectUpgrade({ id: sub.id, name: sub.name, price: sub.price, type: 'subscription' })}
                          className="w-full bg-[#18C29C] text-black text-[9px] font-bold h-7.5"
                        >
                          بدء المزامنة والاشتراك محلياً ⭐️
                        </Button>
                      </Card>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 3: BOOST ECONOMY (Homepage, wilaya, searches with various options) */}
            {activeTab === 'boosts' && !isCheckingOut && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {boostOptions.map((opt) => (
                    <Card key={opt.id} className="p-5 bg-[#0E141C] border border-white/5 gap-3 flex flex-col justify-between">
                      <div className="space-y-2 text-right">
                        <div className="flex justify-between items-center">
                          <span className="bg-brand-500/10 text-brand-400 text-[9px] px-2 py-0.5 rounded-md border border-brand-500/10 font-bold uppercase">
                            نوع الحجز: {opt.badgeLabel}
                          </span>
                          <span className="text-[9px] text-[#18C29C] font-mono">{opt.priceModel}</span>
                        </div>
                        <h4 className="text-xs font-black text-white">{opt.name}</h4>
                        <p className="text-[10px] text-white/40 leading-relaxed">{opt.description}</p>

                        <div className="grid grid-cols-2 gap-2 pt-2 text-[10px]">
                          {opt.durations.map((dur, idx) => (
                            <div key={idx} className="bg-black/40 border border-white/5 rounded-lg p-2 flex justify-between items-center text-white/80">
                              <span>{dur.label}</span>
                              <strong className="text-emerald-400 font-mono">{dur.price} دج</strong>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3.5 flex justify-end">
                        <Button 
                          onClick={() => handleSelectUpgrade({ id: opt.id, name: opt.name, price: opt.durations[0].price, type: 'boost' })}
                          className="bg-brand-500 hover:bg-brand-600 text-black font-extrabold text-[10px] h-7.5"
                        >
                          اضبط الترويج المخصص لسلعتك
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </motion.div>
            )}

            {/* TAB 4: BUNDLES & OPTIONAL HIGH INCOME ADD-ONS */}
            {activeTab === 'add-ons' && !isCheckingOut && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6"
              >
                {/* Bundles section */}
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-[#18C29C] block border-b border-white/5 pb-2">📦 حزم المبيعات المشتركة لزيادة متوسط الفاتورة (Bundles)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {bundles.map(b => (
                      <Card key={b.id} className="p-5 bg-gradient-to-br from-[#121620] to-[#0a0d14] border border-white/10 gap-3.5 flex flex-col justify-between">
                        <div className="space-y-2">
                          <h4 className="text-xs font-black text-white">{b.name}</h4>
                          <p className="text-[10px] text-white/40 leading-relaxed">{b.description}</p>
                          <div className="bg-black/30 p-2.5 rounded-lg space-y-1 border border-white/5 text-[9px] text-white/70 font-mono">
                            <span className="text-[8px] text-[#18C29C] font-semibold block uppercase">أجزاء الحزمة المفعلة:</span>
                            {b.components.map((c, i) => (
                              <div key={i}>• {c}</div>
                            ))}
                          </div>
                        </div>
                        <div className="border-t border-white/5 pt-3 flex justify-between items-center mt-auto">
                          <div className="flex flex-col text-right">
                            <span className="text-[8px] text-white/30">سعر الحزمة كلي:</span>
                            <span className="text-xs font-extrabold text-emerald-400 font-mono">{b.price} دج</span>
                          </div>
                          <Button 
                            onClick={() => handleSelectUpgrade({ id: b.id, name: b.name, price: b.price, type: 'bundle' })}
                            className="bg-brand-500 text-black font-extrabold text-[9px] h-7"
                          >
                            اقتناء الحزمة بنصف السعر ⚡
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>

                {/* Individual Addons */}
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <h3 className="text-sm font-bold text-white block">✨ أدوات متجك الإضافية (High-Income Add-ons)</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {optionalAddons.map(add => (
                      <Card key={add.id} className="p-4 bg-[#0E141C] border border-white/5 gap-3 flex flex-col justify-between hover:border-white/10 transition-colors">
                        <div className="space-y-1">
                          <div className="flex justify-between items-center text-[10px]">
                            <span className="font-bold text-white">{add.name}</span>
                            <span className="font-bold text-[#18C29C] font-mono">{add.price} دج</span>
                          </div>
                          <p className="text-[10px] text-white/50 leading-relaxed">{add.description}</p>
                        </div>
                        <Button 
                          onClick={() => handleSelectUpgrade({ id: add.id, name: add.name, price: add.price, type: 'addon' })}
                          className="w-full bg-white/5 hover:bg-white/10 text-white/90 text-[9px] h-6.5 font-bold"
                        >
                          تفعيل الأداة الآن للمخزن
                        </Button>
                      </Card>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 5: PLATFORM TRANSACTIONS & DEMO MANUAL ADMIN OVERRIDES */}
            {activeTab === 'txs' && !isCheckingOut && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6"
              >
                <Card className="p-6 border-white/10 space-y-4">
                  <div className="border-b border-white/5 pb-2 flex justify-between items-center">
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Activity className="w-4 h-4 text-[#18C29C]" />
                        <span>منظومة تتبع وتدقيق التحويلات والترقيات بمتصفحك</span>
                      </h4>
                      <p className="text-[10px] text-white/40">تظهر هنا المدفوعات التي باشرتها. يمكنك تصفحها ومحاكاة الموافقة عليها يدوياً لتجربة تأثيراتها فوراً.</p>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-right text-[11px] font-mono">
                      <thead className="text-[10px] text-white/40 border-b border-white/5">
                        <tr className="h-10">
                          <th className="py-2 pr-3">مُعرّف المطلب</th>
                          <th className="py-2">الترقية والمحتوى المطلوب</th>
                          <th className="py-2">تفاصيل إثبات الدفع والوصل</th>
                          <th className="py-2">المبلغ المطلوب مقابل المرسل</th>
                          <th className="py-2">التحليل الأمني والتدقيق</th>
                          <th className="py-2">حالة التسوية</th>
                          <th className="py-2 text-center pl-3">أدوات مراجعة المالك (الأدمن)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((tx) => {
                          const hasMismatched = tx.securityFlags?.includes('mismatched_amount');
                          const hasDuplicate = tx.securityFlags?.includes('duplicate_proof');
                          const hasRepeated = tx.securityFlags?.includes('repeated_upload');

                          return (
                            <tr key={tx.id} className="border-b border-white/5 h-16 hover:bg-white/5 transition-colors">
                              <td className="font-bold text-white whitespace-nowrap pr-3">{tx.id}</td>
                              <td className="font-sans">
                                <span className="font-bold text-white block leading-tight">{tx.itemName}</span>
                                <span className="text-[9px] text-white/40 block mt-0.5">
                                  أنشأ: {new Date(tx.createdAt).toLocaleDateString('ar-DZ')}
                                </span>
                              </td>
                              <td className="font-sans">
                                <div className="space-y-0.5">
                                  {tx.txReference ? (
                                    <div className="flex items-center gap-1">
                                      <span className="text-[9.5px] bg-[#18C29C]/10 text-[#18C29C] px-1.5 py-0.5 rounded font-mono font-bold">
                                        TXID: {tx.txReference}
                                      </span>
                                    </div>
                                  ) : (
                                    <span className="text-white/30 italic text-[10px]">لا يوجد رمز مرجعي</span>
                                  )}
                                  
                                  {tx.paymentTimestamp && (
                                    <span className="text-[9px] text-amber-400 block font-mono">
                                      ⏰ للحوالة: {tx.paymentTimestamp.replace('T', ' ')}
                                    </span>
                                  )}
                                  
                                  {tx.receiptFileName && (
                                    <span className="text-[9px] text-blue-400 font-mono block">
                                      📁 إيصال: {tx.receiptFileName}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="whitespace-nowrap font-mono">
                                <div className="space-y-0.5 text-right">
                                  <div className="text-[10px] text-white/50">المطلوب: {formatDZD(tx.amount)}</div>
                                  {tx.submittedAmount !== undefined ? (
                                    <div className={`text-[10px] font-bold ${hasMismatched ? 'text-rose-400' : 'text-emerald-400'}`}>
                                      المُرسل: {formatDZD(tx.submittedAmount)}
                                    </div>
                                  ) : (
                                    <div className="text-[9px] text-white/30 italic">تسجيل آلي</div>
                                  )}
                                </div>
                              </td>
                              <td className="font-sans">
                                {tx.securityFlags && tx.securityFlags.length > 0 ? (
                                  <div className="flex flex-col gap-1">
                                    {hasDuplicate && (
                                      <span className="inline-flex items-center gap-1 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded px-1.5 py-0.5 text-[8.5px] font-bold animate-pulse">
                                        ⚠️ وصل مكرر (Duplicate TXID)
                                      </span>
                                    )}
                                    {hasMismatched && (
                                      <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded px-1.5 py-0.5 text-[8.5px] font-bold">
                                        ⚠️ مبلغ غير متطابق
                                      </span>
                                    )}
                                    {hasRepeated && (
                                      <span className="inline-flex items-center gap-1 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded px-1.5 py-0.5 text-[8.5px] font-bold">
                                        ⚠️ إغراق تحميلات (Spam Flow)
                                      </span>
                                    )}
                                  </div>
                                ) : (
                                  <div className="text-[#18C29C] text-[9.5px] font-bold flex items-center gap-1">
                                    <span>✓ تدقيق سليم</span>
                                  </div>
                                )}
                              </td>
                              <td>
                                <span className={`inline-flex px-2 py-0.5 rounded text-[9px] font-bold leading-none ${
                                  tx.status === 'approved' 
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                                    : tx.status === 'rejected' 
                                      ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                                      : tx.status === 'payment_submitted'
                                        ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                                        : 'bg-white/5 text-white/40'
                                }`}>
                                  {tx.status === 'approved' ? 'مقبول وفُعّل ✨' : tx.status === 'rejected' ? 'مرفوض ✕' : tx.status === 'payment_submitted' ? 'معلق للمراجعة 🔎' : tx.status}
                                </span>
                              </td>
                              <td className="whitespace-nowrap text-center pl-3">
                                {tx.status === 'payment_submitted' ? (
                                  <div className="flex gap-1.5 justify-center">
                                    <button 
                                      onClick={() => handleAdminApprove(tx, 'approved')}
                                      className="bg-emerald-500 text-black px-2 py-1 rounded text-[9px] font-bold uppercase transition-all hover:bg-emerald-600"
                                    >
                                      تأكيد وموافقة ✓
                                    </button>
                                    <button 
                                      onClick={() => handleAdminApprove(tx, 'rejected')}
                                      className="bg-rose-500/10 text-rose-400 px-2 py-1 rounded text-[9px] font-bold hover:bg-rose-500/20"
                                    >
                                      رفض المطلب ✕
                                    </button>
                                  </div>
                                ) : (
                                  <span className="text-[9.5px] text-white/40 italic font-sans block">تمت التسوية الأسبوعية</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                        {transactions.length === 0 && (
                          <tr>
                            <td colSpan={7} className="text-center py-8 text-white/30 font-sans">
                              لا يوجد أي طلبات ترقية مسجلة بعد. اختر خدمة من التبويبات أعلاه لتقديم إثبات تفعيلها.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </Card>
              </motion.div>
            )}

            {/* CHECKOUT MODAL STYLE WRAPPER (Interactive State-Machine) */}
            {isCheckingOut && selectedItem && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="space-y-6"
              >
                <Card className="p-6 border-white/10 space-y-4">
                  <div className="flex items-center gap-2 border-b border-white/5 pb-2 justify-between">
                    <button 
                      onClick={() => setIsCheckingOut(false)}
                      className="text-xs text-white/50 hover:text-white flex items-center gap-1 bg-white/5 px-2.5 py-1 rounded-md"
                    >
                      <ArrowLeft className="w-4 h-4 rotate-180" />
                      <span>إلغاء والعودة للقائمة</span>
                    </button>
                    <span className="text-[10px] text-white/40 uppercase font-mono font-bold">بوابة تحصيل ريادة v22</span>
                  </div>

                  {/* Summary row */}
                  <div className="bg-[#121620] p-4 rounded-xl border border-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="text-right">
                      <span className="text-[10px] text-white/40 block">الخدمة / الترقية المختارة:</span>
                      <strong className="text-xs md:text-sm text-white">{selectedItem.name}</strong>
                    </div>
                    <div className="text-left shrink-0">
                      <span className="text-[10px] text-white/40 block">الكلفة الإجمالية:</span>
                      <span className="text-sm font-mono font-black text-brand-400">
                        {selectedItem.type === 'boost' 
                          ? formatDZD(boostOptions.find(b => b.id === selectedItem.id)?.durations[selectedDurationIndex].price || selectedItem.price)
                          : formatDZD(selectedItem.price)}
                      </span>
                    </div>
                  </div>

                  {/* Boost Selection configs */}
                  {selectedItem.type === 'boost' && (
                    <div className="space-y-4 p-4 rounded-xl bg-[#0a0d15] border border-white/5">
                      
                      {/* Product select tag */}
                      <div className="space-y-1.5 text-right">
                        <label className="text-[11px] text-white/70 block font-bold">🎯 حدد السلعة أو المنشور الذي تريد ربط ترويج الطرد به:</label>
                        <select
                          required
                          value={selectedProductId}
                          onChange={(e) => setSelectedProductId(e.target.value)}
                          className="w-full bg-[#121620] border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none"
                        >
                          <option value="">-- اضغط لتحديد أحد سلع مخزنك --</option>
                          {products.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} ({formatDZD(p.price)})
                            </option>
                          ))}
                        </select>
                        <p className="text-[9px] text-[#18C29C] italic">تتطلب المزامنة ترويج معروضات مسجلة سلفاً في متجرك.</p>
                      </div>

                      {/* Duration selector */}
                      <div className="space-y-2 text-right">
                        <label className="text-[11px] text-white/70 block font-bold">⏱️ حدد المدة الزمنية المفترضة للترقية بـ 58 ولاية:</label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {boostOptions.find(b => b.id === selectedItem.id)?.durations.map((dur, idx) => (
                            <div 
                              key={idx}
                              onClick={() => setSelectedDurationIndex(idx)}
                              className={`p-2.5 rounded-lg border text-center cursor-pointer transition-all ${
                                selectedDurationIndex === idx 
                                  ? 'bg-brand-500/10 border-brand-500 text-white' 
                                  : 'bg-black/20 border-white/5 text-white/50 hover:bg-white/5'
                              }`}
                            >
                              <span className="text-[9px] font-bold block">{dur.label}</span>
                              <strong className="text-[11px] text-emerald-400 font-mono block mt-1">{dur.price} دج</strong>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>
                  )}

                  {/* Payment option selectors */}
                  <div className="space-y-3 pt-2 text-right">
                    <label className="text-xs font-bold text-white block">💳 حدد طريقة إرسال الرسوم والربط الهيكلي ريادة:</label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-sans">
                      
                      <div 
                        onClick={() => setPayMode('chargily')}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col gap-1 ${
                          payMode === 'chargily' 
                            ? 'bg-brand-500/5 border-brand-500 text-white' 
                            : 'bg-black/20 border-white/5 text-white/50 hover:bg-white/5'
                        }`}
                      >
                        <div className="flex justify-between items-center text-[10px]">
                          <strong className="text-white">بوابة Chargily</strong>
                          <span className="bg-[#18C29C] text-black px-1.5 rounded text-[8px] font-bold">آلي وآمن</span>
                        </div>
                        <p className="text-[9px] text-white/40 leading-relaxed mt-1">
                          ادفع بالبطاقة الذهبية أو CIB مباشرة عبر بوابة Chargily الجزائرية الرائدة. كلياً مدمجة بخصوصية قصوى.
                        </p>
                      </div>

                      <div 
                        onClick={() => setPayMode('baridimob')}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col gap-1 ${
                          payMode === 'baridimob' 
                            ? 'bg-brand-500/5 border-brand-500 text-white' 
                            : 'bg-black/20 border-white/5 text-white/50 hover:bg-white/5'
                        }`}
                      >
                        <div className="flex justify-between items-center text-[10px]">
                          <strong className="text-white">بريدي موب CCP يدوي</strong>
                          <span className="bg-blue-500 text-white px-1.5 rounded text-[8px] font-bold">حوالة ذاتية</span>
                        </div>
                        <p className="text-[9px] text-white/40 leading-relaxed mt-1">
                          قم بإجراء الحوالة CCP يدوياً لحسابنا، ثم ألصق رقم المعاملة TXID أو صورة الوصل بنظام ريادة للتأكيد الفوري من الإدارة.
                        </p>
                      </div>

                      <div 
                        onClick={() => setPayMode('cash')}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col gap-1 ${
                          payMode === 'cash' 
                            ? 'bg-brand-500/5 border-brand-500 text-white' 
                            : 'bg-black/20 border-white/5 text-white/50 hover:bg-white/5'
                        }`}
                      >
                        <div className="flex justify-between items-center text-[10px]">
                          <strong className="text-white">كاش مع المندوب</strong>
                          <span className="bg-amber-500 text-black px-1.5 rounded text-[8px] font-bold">ميداني</span>
                        </div>
                        <p className="text-[9px] text-white/40 leading-relaxed mt-1">
                          تنسيق مقابلة يدا بيد لخدمات done-for-you الإقليمية في ولايات النشاط بالجزائر. الرسوم تسلّم مع إنجاز المهام.
                        </p>
                      </div>

                    </div>
                  </div>

                  {/* Manual CCP info shown if baridimob selected */}
                  {payMode === 'baridimob' && (
                    <div className="space-y-4 pt-3 border-t border-white/5 text-right bg-black/25 p-4 rounded-xl">
                      <div className="space-y-2 font-sans text-xs">
                        <div className="flex justify-between items-center border-b border-white/5 pb-1">
                          <span className="text-[10px] text-amber-400 font-bold uppercase block">🏦 معلومات الحساب البريدي (مُعمّاة تماماً للسرية):</span>
                          <span className="text-[8px] bg-white/5 text-white/50 px-1.5 py-0.5 rounded">Reconciliation: Weekly</span>
                        </div>
                        
                        <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[9.5px] p-2.5 rounded-lg leading-relaxed mb-1">
                          🔒 <strong>حماية الهوية المصرفية:</strong> يلتزم نظام ريادة v22 بعدم الكشف العلني عن الهوية المصرفية لمالك المنصة للعموم؛ لحمايته من الاستهداف والتصيد المالي. الحسابات المصرح بها هنا معمّاة جزئياً دون التأثير على إمكانية التحويل عبر تطبيق باريدي موب.
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] text-white/80 font-mono mt-1">
                          <div className="bg-black/40 p-2 rounded-lg border border-white/5">
                            <span className="text-[8.5px] text-white/40 block font-sans">الاسم المستعار للمستلم:</span>
                            <strong className="text-white">طاقم ريادة (Riyada Platform Devs)</strong>
                          </div>
                          <div className="bg-black/40 p-2 rounded-lg border border-white/5">
                            <span className="text-[8.5px] text-white/40 block font-sans">رقم الحساب CCP (معمّى):</span>
                            <strong className="text-white">00249**** مفتاح 32</strong>
                          </div>
                          <div className="col-span-1 sm:col-span-2 bg-black/40 p-2 rounded-lg border border-white/5">
                            <span className="text-[8.5px] text-white/40 block font-sans">معرف RIP الذهبي (معمّى):</span>
                            <strong className="text-white">00799999002492****032</strong>
                          </div>
                        </div>

                        <div className="text-[9px] text-[#18C29C] font-semibold bg-brand-500/5 p-2 rounded border border-brand-500/10 leading-snug font-sans">
                          📆 <strong>مواعيد التسوية اليدوية:</strong> تجري مطابقة إيصالات CCP والموافقة عليها يدوياً كل نهاية أسبوع (الجمعة والسبت) من قِبل مدققي ريادة.
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                        <div className="space-y-1">
                          <label className="text-[10px] text-white/50 font-bold block">1. رمز الحوالة الفريد (TXID / Reference) * :</label>
                          <input
                            type="text"
                            required
                            placeholder="مثال: 0092182012"
                            value={txRefInput}
                            onChange={(e) => setTxRefInput(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2 font-mono text-center focus:outline-none focus:border-brand-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] text-white/50 font-bold block">2. تاريخ ووقت إجراء التحويل * :</label>
                          <input
                            type="datetime-local"
                            required
                            value={txTimestampInput}
                            onChange={(e) => setTxTimestampInput(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-1.5 text-center focus:outline-none focus:border-brand-500"
                          />
                        </div>

                        <div className="space-y-1 sm:col-span-2">
                          <label className="text-[10px] text-white/50 font-bold block">3. القيمة المالية المحولة بالدينار الجزائري (DZD) * :</label>
                          <div className="relative">
                            <input
                              type="number"
                              required
                              placeholder="مثال: 1800"
                              value={txAmountInput}
                              onChange={(e) => setTxAmountInput(e.target.value)}
                              className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2 pl-12 text-center font-mono focus:outline-none focus:border-brand-500"
                            />
                            <span className="absolute left-3 top-2 text-[10px] text-emerald-400 font-bold font-sans">دج / DZD</span>
                          </div>
                          <span className="text-[9px] text-white/30 block">ملاحظة أمنية: يجب أن يتطابق هذا الحقل تماماً مع كلفة الباقة لتجنب الرفض الماتش المالي.</span>
                        </div>
                      </div>

                      {/* Drag & Drop Receipt Simulator */}
                      <div className="space-y-1.5 text-right pt-1">
                        <label className="text-[10px] text-white/50 font-bold block">4. إرفاق صورة إيصال الدفع / لقطة الشاشة (مخزن محلياً فقط) * :</label>
                        <div 
                          onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                          onDragLeave={() => setIsDragOver(false)}
                          onDrop={(e) => {
                            e.preventDefault();
                            setIsDragOver(false);
                            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                              const file = e.dataTransfer.files[0];
                              setReceiptFileName(file.name);
                              setHasReceiptFile(true);
                            }
                          }}
                          className={`border-2 border-dashed rounded-xl p-4 text-center transition-all cursor-pointer ${
                            isDragOver 
                              ? 'border-[#18C29C] bg-brand-500/5' 
                              : hasReceiptFile 
                                ? 'border-emerald-500 bg-emerald-500/5' 
                                : 'border-white/10 bg-black/15 hover:border-white/20'
                          }`}
                        >
                          <input 
                            type="file" 
                            id="receiptFile"
                            className="hidden" 
                            onChange={(e) => {
                              if (e.target.files && e.target.files[0]) {
                                setReceiptFileName(e.target.files[0].name);
                                setHasReceiptFile(true);
                              }
                            }}
                          />
                          <label htmlFor="receiptFile" className="cursor-pointer space-y-1 block">
                            <Upload className="w-5 h-5 mx-auto text-[#18C29C]" />
                            {hasReceiptFile ? (
                              <div className="space-y-0.5">
                                <span className="text-xs font-mono font-bold text-[#18C29C] block">{receiptFileName}</span>
                                <span className="text-[9px] text-white/40 block">✓ تم تحميل إيصال الدفع بنجاح محلياً</span>
                              </div>
                            ) : (
                              <div className="space-y-0.5">
                                <span className="text-[10px] text-white/70 block font-bold">اسحب صورة الإيصال أو الوصل من بريدي موب هنا</span>
                                <span className="text-[9px] text-white/40 block">أو اضغط لتصفح الملفات من جهازك</span>
                              </div>
                            )}
                          </label>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Cash Handover simulation details */}
                  {payMode === 'cash' && (
                    <div className="space-y-4 pt-3 border-t border-white/5 text-right bg-black/25 p-4 rounded-xl">
                      <div className="bg-amber-500/10 border border-amber-500/20 text-amber-200 text-[10px] p-3 rounded-lg leading-relaxed text-right">
                        💡 <strong>تنسيق الكاش:</strong> سيقوم منسق الولاية والتسيير الميداني بالاتصال بك هاتفياً عبر الرقم المسجل بملفك الشخصي لاستكمال تفعيل شارات Done-for-you والرفع. الرسوم تسلّم مع إنجاز مهام الترويج الموضعية بالجزائر.
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                        <div className="space-y-1">
                          <label className="text-[10px] text-white/50 font-bold block">رقم وتسمية سند الكوبون (Coupon Slip / Voucher Ref) * :</label>
                          <input
                            type="text"
                            required
                            placeholder="مثال: CASH-ALGLOC-829"
                            value={txRefInput}
                            onChange={(e) => setTxRefInput(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2 font-mono text-center focus:outline-none focus:border-brand-500"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] text-white/50 font-bold block">ميعاد التسليم المتفق عليه * :</label>
                          <input
                            type="datetime-local"
                            required
                            value={txTimestampInput}
                            onChange={(e) => setTxTimestampInput(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-1.5 text-center focus:outline-none focus:border-brand-500"
                          />
                        </div>

                        <div className="space-y-1 sm:col-span-2">
                          <label className="text-[10px] text-white/50 font-bold block">القيمة المالية الكلية المتفق عليها يداً بيد (DZD) * :</label>
                          <div className="relative">
                            <input
                              type="number"
                              required
                              placeholder="مثال: 4500"
                              value={txAmountInput}
                              onChange={(e) => setTxAmountInput(e.target.value)}
                              className="w-full bg-black/40 border border-white/10 text-xs text-white rounded-lg p-2 pl-12 text-center font-mono focus:outline-none"
                            />
                            <span className="absolute left-3 top-2 text-[10px] text-emerald-400 font-bold font-sans">دج / DZD</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="pt-3 flex justify-end">
                    <Button 
                      onClick={handleCheckoutProcess}
                      className="w-full sm:w-56 text-xs font-bold bg-[#18C29C] hover:bg-[#129A7B] text-black h-9 flex items-center justify-center gap-1"
                    >
                      <span>تأكيد المطلب وإيداع الإثبات 🔗</span>
                    </Button>
                  </div>
                </Card>
              </motion.div>
            )}

          </AnimatePresence>

        </div>

        {/* RIGHT SIDE PANEL: TRUST SCORE CARD, ACTIVE EXPLOITS AND LAUNCH STATS */}
        <div className="space-y-6">
          
          {/* Unlocked badges */}
          <Card className="p-5 border-white/10 bg-gradient-to-br from-[#111925] to-[#070b13] space-y-4">
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5 border-b border-white/5 pb-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>هوية المتجر ومستوى تحقيق الدخل</span>
            </h3>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center relative">
                <Store className="w-6 h-6 text-brand-400" />
                {isGoldUnlocked && (
                  <span className="absolute -bottom-1 -right-1 bg-brand-500 text-black rounded-full p-0.5" title="موثق ذهبي">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </span>
                )}
              </div>
              <div className="space-y-0.5 text-right">
                <h4 className="text-xs font-bold text-white">{activeWorkspace?.name || 'متجر ريادة'}</h4>
                <span className="text-[10px] text-white/40 block">الهوية الوطنية: {isGoldUnlocked ? 'بائع ذهبي معتمد' : 'بائع أساسي محلي'}</span>
              </div>
            </div>

            <div className="space-y-3 font-sans pt-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-white/40">شارة VIP الذهبية:</span>
                <span className={isGoldUnlocked ? 'text-[#18C29C] font-bold' : 'text-white/30'}>{isGoldUnlocked ? 'مفعلة ✓' : 'غير نشطة'}</span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                <div className={`h-full bg-gradient-to-r from-blue-400 to-emerald-400`} style={{ width: isGoldUnlocked ? '100%' : '20%' }}></div>
              </div>
              <p className="text-[9px] text-white/40 leading-relaxed">تمنح شارة البيع الذهبية ثقة بـ 250% لزبائن الولاية لسهولة تصفح CCP وبريدي موب دون قلق.</p>
            </div>
          </Card>

          {/* Quick instructions on Revenue layering */}
          <Card className="p-5 border-white/10 space-y-3.5 text-right">
            <h4 className="text-xs font-bold text-[#18C29C] flex items-center gap-1">
              <Plus className="w-4 h-4" />
              <span>أدوات توليد الدخل v22</span>
            </h4>
            <p className="text-[10px] text-white/50 leading-relaxed">
              ريادة v22 تتبع نموذج <strong>الاستثمار في جلب الأثر</strong>. البائع المستقل لا يدفع مقابل مجرد استخدام قائمة السلع، بل يشتري ميزات Done-for-you (DFY) مثل كشط الصور وتطهير الأوصاف وتوليد بوسترات السوشل ميديا الرائدة للترصيد المحلي.
            </p>
            <div className="bg-[#121620] p-3 rounded-lg border border-white/5 space-y-1 text-[9px] text-[#18C29C]">
              <div>• Basic = low-friction entry (حر بالكامل)</div>
              <div>• Growth = best value (باقة مبيعات مبرزة)</div>
              <div>• Elite = premium power users (مستوى السيطرة)</div>
            </div>
          </Card>

        </div>
      </div>

      {/* CHARGILY INVOICE MODAL SIMULATOR */}
      <AnimatePresence>
        {showInvoiceSimulator && selectedItem && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" dir="ltr">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white text-gray-900 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl font-sans"
            >
              {/* Header Box */}
              <div className="bg-[#1e1e2d] text-white p-6 relative">
                <div className="flex justify-between items-center mb-4">
                  <div className="bg-emerald-400 text-black px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase">
                    SANDBOX GATEWAY
                  </div>
                  <strong className="text-xs tracking-wider opacity-60">CHARGILY PAY</strong>
                </div>
                <h3 className="text-sm font-black text-white/80">Secured Invoice payment</h3>
                <span className="block text-2xl font-black text-white font-mono mt-2">
                  {selectedItem.type === 'boost' 
                    ? formatDZD(boostOptions.find(b => b.id === selectedItem.id)?.durations[selectedDurationIndex].price || selectedItem.price)
                    : formatDZD(selectedItem.price)}
                </span>
                <span className="text-[10px] text-white/40 block mt-1">To: RIYADA Algérie (CCP Platform Provider)</span>
              </div>

              {/* Form simulated fields */}
              <div className="p-6 space-y-5 text-left text-xs">
                
                <div className="space-y-1">
                  <label className="text-gray-500 font-semibold block text-[10px] uppercase">Simulation Buyer Card (CIB / Dahabia):</label>
                  <input 
                    type="text" 
                    readOnly 
                    value="6072 0451 **** 9820" 
                    className="w-full bg-gray-50 border border-gray-200 text-gray-800 text-xs font-mono rounded-xl p-3"
                  />
                  <span className="text-[9px] text-[#18C29C] block font-semibold">✓ Test sandbox card loaded automatically</span>
                </div>

                <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 text-blue-800 text-[10px] leading-relaxed">
                  You are now simulating an interactive API redirect handshake through Chargily Pay. No real bank accounts are debited.
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => handleChargilySimulatorCallback('approved')}
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-black py-3 rounded-xl transition-all"
                  >
                    APPROVE PAYMENT ✓
                  </button>
                  <button 
                    onClick={() => handleChargilySimulatorCallback('rejected')}
                    className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 rounded-xl transition-all"
                  >
                    CANCEL TRANSACTION
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* WEBBING SIMULATION OVERLAY */}
      <AnimatePresence>
        {isSimulatingWeb && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="flex flex-col items-center gap-4 text-center">
              <RefreshCw className="w-12 h-12 text-[#18C29C] animate-spin" />
              <div className="space-y-1.5">
                <h4 className="text-sm font-bold text-white">تحويل آمن وبوابة ثنائية الاتصال (API Redirect)...</h4>
                <p className="text-xs text-white/40">يقوم نظام ريادة v22 بعزل هويتك وتعويم المعاملة البنكية لمنع كشط الإثباتات.</p>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
