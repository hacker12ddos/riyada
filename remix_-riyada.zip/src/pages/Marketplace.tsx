import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ShoppingCart, Star, MapPin, Store, MessageCircle, Heart, ShieldCheck, TrendingUp, Filter } from 'lucide-react';
import { TrustBadge } from '../components/TrustBadge';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { formatDZD } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { getAllItems, trackInteraction, ALGERIAN_WILAYAS } from '../lib/db';
import { SEED_DATA } from '../lib/seed';
import { calculateProductsScore } from '../lib/scoring';
import { getWorkers, getJobs } from '../lib/economy';
import { Briefcase, Pickaxe, Users, Sparkles, AlertCircle } from 'lucide-react';

export default function MarketplaceFeed() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [allProducts, setAllProducts] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [workersCount, setWorkersCount] = useState(0);
  const [jobsCount, setJobsCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedWilaya, setSelectedWilaya] = useState(searchParams.get('wilaya') || 'الكل');

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    filterProducts();
  }, [allProducts, searchParams, selectedWilaya]);

  const [favorites, setFavorites] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    try {
      const dbFavs = await getAllItems('favorites');
      const favMap: Record<string, boolean> = {};
      dbFavs.forEach((f: any) => { favMap[f.id] = true; });
      setFavorites(favMap);
    } catch (e) {
      console.error(e);
    }
  };

  const handleFavoriteClick = async (product: any, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const { toggleFavorite } = await import('../lib/db');
      const isFav = await toggleFavorite(product.id);
      setFavorites(prev => ({ ...prev, [product.id]: isFav }));
    } catch (e) {
      console.error(e);
    }
  };

  const loadProducts = async () => {
    setIsLoading(true);
    try {
      const dbProducts = await getAllItems('products');
      
      let initialList = [];
      if (dbProducts && dbProducts.length > 0) {
        initialList = dbProducts.map(p => ({
          ...p,
          vendorName: p.vendorName || 'متجر ريادة',
          wilaya: p.wilaya || 'الجزائر العاصمة',
          verified: p.verified ?? true,
          sponsored: p.sponsored ?? false
        }));
      }
      
      // Calculate real trending scores based on local interactions
      const scoredProducts = await calculateProductsScore(initialList);
      setAllProducts(scoredProducts);
      setWorkersCount(getWorkers().length);
      setJobsCount(getJobs().length);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const filterProducts = () => {
    let filtered = [...allProducts];
    const q = searchParams.get('q');
    const cat = searchParams.get('category');
    const w = searchParams.get('wilaya') || selectedWilaya;
    const sort = searchParams.get('sort') || 'trending';
    
    if (q) {
      const qLower = q.toLowerCase();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(qLower) || 
        (p.category && p.category.toLowerCase().includes(qLower)) ||
        (p.vendorName && p.vendorName.toLowerCase().includes(qLower))
      );
    }
    
    if (cat) {
      filtered = filtered.filter(p => p.category === cat || p.category?.includes(cat) || p.name.includes(cat));
    }

    if (w && w !== 'الكل') {
      filtered = filtered.filter(p => p.wilaya === w);
    }
    
    if (sort === 'newest') {
      filtered.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } else if (sort === 'cheapest') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sort === 'verified') {
      filtered.sort((a, b) => (b.verified ? 1 : 0) - (a.verified ? 1 : 0));
    } else {
      // sort by trendingScore (default and fallback)
      filtered.sort((a, b) => (b.trendingScore || 0) - (a.trendingScore || 0));
    }
    
    // Always put sponsored at the top
    filtered.sort((a, b) => (b.sponsored ? 1 : 0) - (a.sponsored ? 1 : 0));
    
    setProducts(filtered);
  };

  const handleProductClick = (product: any) => {
    trackInteraction(product.id, 'view', product.vendorId);
    navigate(`/product/${product.id}`);
  };

  const handleWhatsAppClick = (product: any, e: React.MouseEvent) => {
    e.stopPropagation();
    trackInteraction(product.id, 'whatsapp', product.vendorId);
    const message = `مرحباً، أريد الاستفسار عن المنتج: ${product.name} (السعر: ${formatDZD(product.price)})\nهل هو متوفر؟`;
    const url = `https://wa.me/213555000000?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-8">
      {/* Redefined ALGERIA DIGITAL ECONOMY DASHBOARD Hero Section */}
      <div className="bg-gradient-to-r from-[#121822] via-[#1c2738] to-[#121822] rounded-3xl p-6 md:p-8 border border-white/10 flex flex-col justify-between gap-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-[-30%] right-[-15%] w-96 h-96 bg-[#1AAE8A]/5 rounded-full blur-3xl"></div>
        <div className="relative z-10 flex-1 space-y-3">
          <div className="flex items-center gap-2">
            <span className="bg-[#1AAE8A]/10 text-[#1AAE8A] text-[10px] px-3 py-1 rounded-full font-bold border border-[#1AAE8A]/20">
              منظومة العمل والتجارة الحرة بـ 58 ولاية 🇩🇿
            </span>
            <span className="bg-amber-500/10 text-[#E0B15A] text-[10px] px-2.5 py-1 rounded-full font-bold border border-amber-500/15">v13 التحديث الاقتصادي</span>
          </div>
          <h2 className="text-2xl md:text-4xl font-black text-white leading-tight">سوق العمل والتبادل التجاري الجزائري — ريادة</h2>
          <p className="text-white/60 text-xs md:text-sm max-w-2xl leading-relaxed">
            منظومة رقمية تآزرية تجمع التجارة والسلع، عروض الخدمات الحرة والمقاولات المصغرة، وإعلانات حجز وتوظيف عمال الخدمات في الجزائر بالكامل محلياً وبدون خوادم وسيطة ومجاناً.
          </p>

          {/* Unified search bar */}
          <div className="pt-2 max-w-xl">
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                const q = new FormData(e.currentTarget).get('search-query');
                if (q) {
                  navigate(`/marketplace?q=${encodeURIComponent(q as string)}`);
                }
              }}
              className="flex gap-2"
            >
              <input 
                type="text" 
                name="search-query"
                placeholder="البحث الشامل بـ ريادة (مثال: توصيل، تجهيز سلع، ترصيص)..."
                className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-[#1AAE8A] placeholder:text-white/30"
              />
              <Button type="submit" className="bg-[#1AAE8A] text-black font-extrabold text-xs px-4">
                البحث الاقتصادي
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* CORE ECONOMY NAV GRID OR 4 PRIMARY PILLARS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div 
          onClick={() => {
            searchParams.delete('category');
            navigate(`/marketplace?${searchParams.toString()}`);
          }}
          className="bg-gradient-to-tr from-[#151C26] to-[#0E141C] border border-white/5 hover:border-[#18C29C]/30 rounded-2xl p-4 cursor-pointer transition-all space-y-3 group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xl">🛍️</span>
            <span className="bg-[#18C29C]/10 text-[#18C29C] text-[9px] px-2 py-0.5 rounded border border-[#18C29C]/15">معروض السلع</span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-[#18C29C]">سوق السلع والمخزون</h3>
            <p className="text-[10px] text-white/40">تصفح المنتجات المنزلية والإلكترونيات الحرة</p>
          </div>
          <div className="text-xs font-mono text-[#18C29C] font-semibold flex items-center justify-between">
            <span>السلع والمنتجات:</span>
            <span>{allProducts.length} عنصر</span>
          </div>
        </div>

        <div 
          onClick={() => {
            searchParams.set('category', 'خدمات');
            navigate(`/marketplace?${searchParams.toString()}`);
          }}
          className="bg-gradient-to-tr from-[#151C26] to-[#0E141C] border border-white/5 hover:border-blue-400/30 rounded-2xl p-4 cursor-pointer transition-all space-y-3 group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xl">🛠️</span>
            <span className="bg-blue-400/10 text-blue-400 text-[9px] px-2 py-0.5 rounded border border-blue-400/15">الخدمات</span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-blue-400">عروض ومحترفي الخدمات</h3>
            <p className="text-[10px] text-white/40">خدمات صيانة، تدريس، برمجيات ونقل مباشر</p>
          </div>
          <div className="text-xs font-mono text-blue-400 font-semibold flex items-center justify-between">
            <span>الخدمات المتاحة:</span>
            <span>{allProducts.filter(p => p.category === 'خدمات').length} خدمة نشطة</span>
          </div>
        </div>

        <div 
          onClick={() => navigate('/jobs')}
          className="bg-gradient-to-tr from-[#151C26] to-[#0E141C] border border-white/5 hover:border-emerald-400/30 rounded-2xl p-4 cursor-pointer transition-all space-y-3 group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xl">💼</span>
            <span className="bg-emerald-400/10 text-emerald-400 text-[9px] px-2 py-0.5 rounded border border-emerald-400/15">إعلانات التوظيف</span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-emerald-400">سوق فر ص العمل الشاغرة</h3>
            <p className="text-[10px] text-white/40">مطلوب عمال شحن ومبيعات وديليفري فوريين</p>
          </div>
          <div className="text-xs font-mono text-emerald-400 font-semibold flex items-center justify-between">
            <span>الفرص المعروضة للحجز:</span>
            <span>{jobsCount} وظيفة</span>
          </div>
        </div>

        <div 
          onClick={() => navigate('/workers')}
          className="bg-gradient-to-tr from-[#151C26] to-[#0E141C] border border-white/5 hover:border-amber-400/30 rounded-2xl p-4 cursor-pointer transition-all space-y-3 group"
        >
          <div className="flex justify-between items-start">
            <span className="text-xl">👷</span>
            <span className="bg-amber-400/10 text-amber-400 text-[9px] px-2 py-0.5 rounded border border-amber-400/15">الحرفيون والعمال</span>
          </div>
          <div>
            <h3 className="text-sm font-bold text-white group-hover:text-amber-400">شبكة العمال والحرفيين</h3>
            <p className="text-[10px] text-white/40">ترصيص، نقل سلع، مستقلين رقميين بنطاقك</p>
          </div>
          <div className="text-xs font-mono text-amber-400 font-semibold flex items-center justify-between">
            <span>الملفات المهنية النشطة:</span>
            <span>{workersCount} عامل مستعد</span>
          </div>
        </div>
      </div>

      {/* QUICK ACTION PANEL */}
      <div className="bg-[#0E141C] border border-white/5 rounded-2xl p-4">
        <span className="text-[10px] text-white/40 block mb-3 font-semibold">⚡️ لوحة الإجراءات السريعة (تواصل وحجز فوري):</span>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <button 
            onClick={() => navigate('/onboarding')}
            className="p-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all border border-white/5 text-center"
          >
            🛒 اعرض سلعة للبيع
          </button>
          <button 
            onClick={() => navigate('/onboarding')}
            className="p-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all border border-white/5 text-center"
          >
            🛠️ اعرض خدمة كشركة
          </button>
          <button 
            onClick={() => navigate('/jobs')}
            className="p-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all border border-white/5 text-center"
          >
            💼 انشر وظيفة شاغرة
          </button>
          <button 
            onClick={() => navigate('/workers')}
            className="p-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all border border-white/5 text-center"
          >
            👷 سجل كحرفي مستقل
          </button>
          <button 
            onClick={() => navigate('/workers')}
            className="p-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold transition-all border border-white/5 text-center col-span-2 md:col-span-1"
          >
            🔍 ابحث عن العمال بقربك
          </button>
        </div>
      </div>

      {/* TRUST & SAFETY BANNER UNDER HERO */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 bg-gradient-to-r from-[#151C26] to-[#0E141C] border border-amber-500/20 rounded-xl p-4 flex items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="bg-amber-500/10 text-amber-400 text-[9px] font-bold px-2 py-0.5 rounded border border-amber-500/15 uppercase tracking-wide">الظهور الاحترافي ورفع المبيعات</span>
            <h4 className="text-white text-xs font-bold">باقة ريادة جولد لترقية الظهور والانتشار</h4>
            <p className="text-[10px] text-white/50 leading-relaxed max-w-md">احصل على صدارة النتائج وإشارة الراعي البرونزية لمنتجاتك وخدماتك لجذب الآلاف بجميع الولايات.</p>
          </div>
          <div className="text-left shrink-0">
            <span className="text-[10px] text-amber-400 font-bold block">متاح الحجز فوراً</span>
            <span className="text-[9px] text-white/30 truncate block">بوابة سداد الذهب للتحويلات</span>
          </div>
        </div>

        <div className="bg-[#0E141C] border border-blue-500/20 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-blue-400 text-[10px] font-bold uppercase tracking-wide">البيئة والتوثيق الأمني</span>
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
          </div>
          <h4 className="text-white text-xs font-bold mt-1">تراخيص المتاجر والتحقق</h4>
          <p className="text-[10px] text-white/50 leading-snug">تفعيل شروط CCP اليدوية ومطابقة الحوالات الرقمية لحماية أموال البائعين والحرفيين من النصب المالي.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          {searchParams.get('category') ? `المنتجات في: ${searchParams.get('category')}` : searchParams.get('q') ? `نتائج البحث عن: ${searchParams.get('q')}` : 'اكتشف المنتجات'}
          <span className="text-xs font-normal text-white/40 bg-white/5 px-2 py-0.5 rounded-full">{products.length} منتج نشط</span>
        </h2>
        <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-hide shrink-0 max-w-full">
          {['الكل', 'إلكترونيات', 'ملابس وأزياء', 'طعام ومأكولات', 'عقارات', 'مركبات', 'خدمات', 'وظائف'].map(cat => (
            <button 
              key={cat}
              onClick={() => {
                if (cat === 'الكل') {
                  searchParams.delete('category');
                  navigate(`/marketplace?${searchParams.toString()}`);
                } else {
                  searchParams.set('category', cat);
                  navigate(`/marketplace?${searchParams.toString()}`);
                }
              }}
              className={`text-xs px-3 py-1.5 rounded-full whitespace-nowrap transition-colors ${
                (searchParams.get('category') === cat) || (!searchParams.get('category') && cat === 'الكل')
                  ? 'bg-brand-500 text-[#05070a] font-bold' 
                  : 'bg-white/5 text-white/70 hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
          <div className="w-[1px] h-4 bg-white/10 mx-1"></div>
          
          <div className="relative shrink-0 hidden sm:block">
            <select 
              className="appearance-none bg-white/5 border border-white/10 text-white text-xs rounded-lg px-8 py-1.5 outline-none focus:border-brand-500/50 h-8 cursor-pointer pr-8 pl-4"
              value={searchParams.get('sort') || 'trending'}
              onChange={(e) => {
                searchParams.set('sort', e.target.value);
                navigate(`/marketplace?${searchParams.toString()}`);
              }}
            >
              <option value="trending" className="bg-[#0a0f18]">الأكثر تداولاً</option>
              <option value="newest" className="bg-[#0a0f18]">الأحدث</option>
              <option value="cheapest" className="bg-[#0a0f18]">الأرخص</option>
              <option value="verified" className="bg-[#0a0f18]">متاجر موثقة</option>
            </select>
          </div>

          <div className="relative shrink-0 hidden sm:block">
            <select 
              value={selectedWilaya}
              onChange={(e) => {
                const w = e.target.value;
                setSelectedWilaya(w);
                if (w === 'الكل') {
                  searchParams.delete('wilaya');
                } else {
                  searchParams.set('wilaya', w);
                }
                navigate(`/marketplace?${searchParams.toString()}`);
              }}
              className="appearance-none bg-white/5 border border-white/10 text-white text-xs rounded-lg px-8 py-1.5 outline-none focus:border-brand-500/50 h-8 cursor-pointer pr-8"
            >
              <option value="الكل" className="bg-[#0a0f18]">كل الولايات</option>
              {ALGERIAN_WILAYAS.map(w => (
                <option key={w.id} value={w.name} className="bg-[#0a0f18]">{w.name}</option>
              ))}
            </select>
            <MapPin className="w-3.5 h-3.5 absolute right-2.5 top-2 text-white/50 pointer-events-none" />
          </div>

          <Button variant="secondary" size="sm" className="flex text-xs h-8 shrink-0 px-2 sm:px-3">
            <Filter className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">تصفية متقدمة</span>
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-12">
          <div className="w-8 h-8 border-4 border-white/10 border-t-brand-500 rounded-full animate-spin"></div>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {products.map((product, idx) => (
            <motion.div
              key={product.id || idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: (idx % 10) * 0.05 }}
              onClick={() => handleProductClick(product)}
            >
              <Card className={`p-0 h-full flex flex-col overflow-hidden cursor-pointer group transition-all duration-300 hover:shadow-2xl hover:shadow-brand-500/10 hover:-translate-y-1 ${product.sponsored ? 'border-amber-500/30 ring-1 ring-amber-500/20' : ''}`}>
                {/* Product Image area */}
                <div className="bg-white/5 aspect-square relative overflow-hidden border-b border-white/5">
                  {product.sponsored ? (
                    <div className="absolute top-2 right-2 z-20 bg-amber-500/90 backdrop-blur text-[#05070a] text-[10px] font-bold px-2 py-0.5 rounded shadow-lg flex items-center gap-1">
                      إعلان ممول
                    </div>
                  ) : (product.trendingScore > 10 && idx < 10) ? (
                    <div className="absolute top-2 right-2 z-20 bg-rose-500/90 backdrop-blur text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-lg flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" /> دارج
                    </div>
                  ) : null}
                  <button 
                    onClick={(e) => handleFavoriteClick(product, e)}
                    className={`absolute top-2 left-2 z-20 p-1.5 backdrop-blur-md rounded-full transition-colors ${favorites[product.id] ? 'text-red-500 bg-white/10 opacity-100' : 'text-white/70 bg-black/40 hover:text-red-400 hover:bg-black/60 opacity-0 group-hover:opacity-100'}`}
                  >
                    <Heart className={`w-4 h-4 ${favorites[product.id] ? 'fill-current' : ''}`} />
                  </button>
                  {product.image ? (
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white/10">
                      <ShoppingCart className="w-12 h-12" />
                    </div>
                  )}
                </div>

                {/* Product Details */}
                <div className="p-3 flex flex-col flex-1">
                  <span className="text-[10px] text-brand-400 mb-1">{product.category}</span>
                  <h3 className="font-medium text-white/90 text-sm mb-1 line-clamp-2 leading-snug group-hover:text-brand-400 transition-colors">
                    {product.name}
                  </h3>
                  
                  <div className="mt-auto pt-3">
                    <div className="flex items-center gap-1 mb-2">
                      <Store className="w-3 h-3 text-white/40" />
                      <span className="text-xs text-white/60 truncate" onClick={(e) => { e.stopPropagation(); navigate(`/store/${product.vendorId || '1'}`); }}>{product.vendorName}</span>
                      {product.verified && <ShieldCheck className="w-3 h-3 text-brand-400 shrink-0" />}
                    </div>
                    
                    <div className="flex items-center justify-between gap-2 mt-2">
                      <div className="flex flex-col">
                        <span className="font-bold text-white tracking-wide">{formatDZD(product.price)}</span>
                        <div className="flex items-center gap-1 text-[10px] text-white/40">
                          <MapPin className="w-3 h-3" />
                          {product.wilaya}
                        </div>
                      </div>
                      
                      <button 
                        onClick={(e) => handleWhatsAppClick(product, e)}
                        className="bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] p-2 rounded-lg transition-colors shrink-0 border border-[#25D366]/20"
                        title="تواصل عبر الواتساب"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {!isLoading && products.length === 0 && (
        <div className="py-20 flex flex-col items-center justify-center text-center max-w-md mx-auto">
          <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-full flex items-center justify-center mb-4 text-white/30">
            <ShoppingCart className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">لا توجد معروضات متاحة حالياً</h3>
          <p className="text-white/50 text-xs leading-relaxed mb-6">
            قاعدة البيانات اللامركزية للمنتجات فارغة حالياً. ريادة تعمل وتخزن سلع البائعين محلياً على أجهزتهم؛ كن أول بائع جزائري يسجل متجره ويعرض بضائعه مجاناً وبدون وسطاء!
          </p>
          <Button onClick={() => navigate('/onboarding')} className="bg-[#1AAE8A] hover:bg-[#158C6F] text-[#05070a] font-bold text-xs px-6 py-2.5 rounded-xl">
            أنشئ متجرك وابدأ البيع الآن
          </Button>
        </div>
      )}
    </div>
  );
}
