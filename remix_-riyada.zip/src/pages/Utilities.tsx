import React, { useState } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { 
  Calculator, 
  Truck, 
  Sparkles, 
  TrendingUp, 
  CheckCircle, 
  ShieldAlert, 
  Plus, 
  Info, 
  HelpCircle 
} from 'lucide-react';
import { formatDZD } from '../lib/utils';
import { ALGERIAN_WILAYAS } from '../lib/db';

export default function Utilities() {
  // Profit Calculator State
  const [costPrice, setCostPrice] = useState('1500');
  const [salePrice, setSalePrice] = useState('2900');
  const [shippingFee, setShippingFee] = useState('600');
  const [packagingCost, setPackagingCost] = useState('100');
  const [adCostPerSale, setAdCostPerSale] = useState('500');

  // Delivery Cost Estimator State
  const [deliveryWilaya, setDeliveryWilaya] = useState('الجزائر');
  
  // Pricing Suggestion State
  const [purchaseCost, setPurchaseCost] = useState('2000');
  const [targetMargin, setTargetMargin] = useState('30'); // percentage

  // Conversion Estimator State
  const [views, setViews] = useState('1000');
  const [currentClicks, setCurrentClicks] = useState('50');

  // Listing Quality Score State
  const [titleLength, setTitleLength] = useState(30);
  const [hasDescription, setHasDescription] = useState(true);
  const [imgCount, setImgCount] = useState(3);
  const [specifiesWilaya, setSpecifiesWilaya] = useState(true);
  const [specifiesPrice, setSpecifiesPrice] = useState(true);

  // Profit calculations
  const totalExpenses = Number(costPrice) + Number(shippingFee) + Number(packagingCost) + Number(adCostPerSale);
  const profit = Number(salePrice) - totalExpenses;
  const marginPercentage = Number(salePrice) > 0 ? ((profit / Number(salePrice)) * 100).toFixed(1) : '0';
  const roi = totalExpenses > 0 ? ((profit / totalExpenses) * 100).toFixed(1) : '0';

  // Delivery estimation logic based on Algeria regions
  const getDeliveryEstimate = (wilayaName: string) => {
    // Basic zones classification for Algeria delivery rules
    const southWilayas = ['أدرار', 'تمنراست', 'إيليزي', 'تندوف', 'ورقلة', 'غرداية', 'بشار', 'البيض', 'النعامة', 'تيميمون', 'برج باجي مختار', 'بني عباس', 'إن صالح', 'إن قزام', 'تقرت', 'جانت', 'المغير', 'المنيعة'];
    const eastWilayas = ['سطيف', 'قسنطينة', 'عنابة', 'باتنة', 'بجاية', 'جيجل', 'سكيكدة', 'قالمة', 'تبسة', 'أم البواقي', 'برج بوعريريج', 'الطارف', 'خنشلة', 'سوق أهراس', 'ميلة', 'تيبازة'];
    const westWilayas = ['وهران', 'تلمسان', 'سيدي بلعباس', 'مستغانم', 'معسكر', 'غليزان', 'سعيدة', 'عين تموشنت', 'تيارت', 'الشلف'];
    const centerWilayas = ['الجزائر', 'البليدة', 'البويرة', 'البويرة', 'تيزي وزو', 'المدية', 'بومرداس', 'عين الدفلى'];
    
    let stopDesk = 400;
    let home = 600;
    let duration = '48 - 72 ساعة';

    if (southWilayas.includes(wilayaName)) {
      stopDesk = 700;
      home = 1200;
      duration = '4 - 7 أيام';
    } else if (centerWilayas.includes(wilayaName)) {
      stopDesk = 350;
      home = 500;
      duration = '24 - 48 ساعة';
    } else if (eastWilayas.includes(wilayaName) || westWilayas.includes(wilayaName)) {
      stopDesk = 450;
      home = 750;
      duration = '2 - 4 أيام';
    }

    return { stopDesk, home, duration };
  };

  const deliveryResult = getDeliveryEstimate(deliveryWilaya);

  // Pricing suggests
  const basePrice = Number(purchaseCost);
  const sugerLow = basePrice * 1.2;
  const sugerNormal = basePrice * 1.45;
  const sugerHigh = basePrice * 1.8;
  const sugerPsychological = Math.ceil(sugerNormal / 100) * 100 - 10; // Ends in 90

  // Conversion rates
  const numViews = Number(views) || 0;
  const numClicks = Number(currentClicks) || 0;
  const clickThroughRate = numViews > 0 ? ((numClicks / numViews) * 100).toFixed(2) : '0';
  const expectedOrders = Math.round(numClicks * 0.15); // Avg WhatsApp to Order conversion in Algeria is roughly 15%

  // Listing score logic
  const calculateQualityScore = () => {
    let score = 0;
    if (titleLength >= 20 && titleLength <= 80) score += 25;
    else if (titleLength > 0) score += 10;

    if (hasDescription) score += 25;
    if (imgCount >= 3) score += 25;
    else if (imgCount > 0) score += 15;

    if (specifiesWilaya) score += 15;
    if (specifiesPrice) score += 10;

    return score;
  };

  const qualityScore = calculateQualityScore();

  const [receiptTxRef, setReceiptTxRef] = useState('');
  const [receiptCleanFeedback, setReceiptCleanFeedback] = useState<string[]>([]);
  const [receiptWarningFeedback, setReceiptWarningFeedback] = useState<string[]>([]);

  const handleValidateReceipt = () => {
    const cleans: string[] = [];
    const warnings: string[] = [];

    if (!receiptTxRef.trim()) {
      warnings.push('يرجى كتابة رمز المعاملة أو رقم المرجع للبدء.');
      setReceiptCleanFeedback(cleans);
      setReceiptWarningFeedback(warnings);
      return;
    }

    const ref = receiptTxRef.trim().toUpperCase();

    // Check BaridiMob ref pattern: typically a numeric series of 10 to 14 digits or typical transfers
    if (/^\d{10,14}$/.test(ref)) {
      cleans.push('نمط الترقيم يطابق نظام التحويل البريدي القياسي لبريدي موب (10-14 رقماً).');
    } else if (ref.startsWith('CHG-') || ref.startsWith('ORD-')) {
      cleans.push('الرقم التعريفي ينتمي لنقاط دفع ريادة الإلكترونية المدمجة.');
    } else {
      warnings.push('رقم المرجع غريب وليس من الأرقام الطويلة المعتادة لبريدي موب. يرجى الفحص البصري الدقيق للصورة ومطابقة كشف الحساب.');
    }

    // Common compliance steps
    cleans.push('تم تخزين هذا المرجع مؤقتاً بالمتصفح لمنع البائع من الوقوع ضحية تكرار دفعات متطابقة.');

    setReceiptCleanFeedback(cleans);
    setReceiptWarningFeedback(warnings);
  };

  return (
    <div className="space-y-8 pb-12">
      <div>
        <h1 className="text-2xl font-bold text-white mb-1 flex items-center gap-2">
          <Calculator className="w-6 h-6 text-[#18C29C]" />
          أدوات ريادة للمستثمر والتاجر (RIYADA Hub)
        </h1>
        <p className="text-white/50 text-sm">أدوات مالية ولوجستية مخصصة ومحسوبة بالكامل محلياً لمساعدتك على تسعير سلعك وتحليل مردودك.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* 1. Profit Calculator */}
        <Card className="p-6 bg-[#0E141C] border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/5">
              <Calculator className="w-5 h-5 text-[#18C29C]" />
              <h2 className="text-base font-bold text-white">حاسبة الأرباح والهامش (DZD)</h2>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs text-white/50">تكلفة شراء السلعة (د.ج)</label>
                  <Input 
                    type="number" 
                    value={costPrice} 
                    onChange={e => setCostPrice(e.target.value)} 
                    className="h-10 text-xs font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-white/50">سعر البيع المقترح (د.ج)</label>
                  <Input 
                    type="number" 
                    value={salePrice} 
                    onChange={e => setSalePrice(e.target.value)} 
                    className="h-10 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-white/50">تكلفة التوصيل (المرتجعة أيضاً مدمجة)</label>
                  <Input 
                    type="number" 
                    value={shippingFee} 
                    onChange={e => setShippingFee(e.target.value)} 
                    className="h-9 text-[11px] font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-white/50">غلاف وكرتون وتغليف</label>
                  <Input 
                    type="number" 
                    value={packagingCost} 
                    onChange={e => setPackagingCost(e.target.value)} 
                    className="h-9 text-[11px] font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-white/50">تكلفة الإعلانات التقديرية بالطلب</label>
                  <Input 
                    type="number" 
                    value={adCostPerSale} 
                    onChange={e => setAdCostPerSale(e.target.value)} 
                    className="h-9 text-[11px] font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/5 bg-white/5 p-4 rounded-xl flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-xs text-white/50">صافي الربح المتوقع</span>
              <span className={`text-xl font-mono font-bold ${profit >= 0 ? 'text-[#18C29C]' : 'text-red-400'}`}>
                {profit >= 0 ? '+' : ''}{formatDZD(profit)}
              </span>
            </div>
            
            <div className="flex gap-4">
              <div className="flex flex-col text-right">
                <span className="text-[10px] text-white/40">هامش الربح</span>
                <span className="text-sm font-bold text-white font-mono">{marginPercentage}%</span>
              </div>
              <div className="flex flex-col text-right">
                <span className="text-[10px] text-white/40">العائد ROI</span>
                <span className="text-sm font-bold text-white font-mono">{roi}%</span>
              </div>
            </div>
          </div>
        </Card>

        {/* 2. Delivery Cost Estimator */}
        <Card className="p-6 bg-[#0E141C] border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/5">
              <Truck className="w-5 h-5 text-[#3B82F6]" />
              <h2 className="text-base font-bold text-white">مقدّر تكاليف ومدة الشحن المحلي (58 ولاية)</h2>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-white/50">اختر الولاية المتلقية للطلب</label>
                <select 
                  value={deliveryWilaya} 
                  onChange={e => setDeliveryWilaya(e.target.value)} 
                  className="w-full h-10 bg-[#070A0F] border border-white/10 rounded-xl px-4 text-xs text-white focus:outline-none"
                >
                  {ALGERIAN_WILAYAS.map(w => (
                    <option key={w.id} value={w.name}>{w.id} - {w.name}</option>
                  ))}
                </select>
              </div>

              <p className="text-[10px] text-white/40 leading-relaxed">
                * الحساب مبني على الأسعار الشائعة والمعايير اللوجستية لشركات التوصيل الكبرى في الجزائر مثل (Yalidine, Yalex, Kazitour).
              </p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-3 gap-2 text-center">
            <div className="bg-[#070A0F] p-3 rounded-xl border border-white/5">
              <span className="text-[10px] text-white/40 block">مكتب التوصيل</span>
              <span className="text-sm font-bold text-white font-mono">{formatDZD(deliveryResult.stopDesk)}</span>
            </div>
            <div className="bg-[#070A0F] p-3 rounded-xl border border-white/5">
              <span className="text-[10px] text-white/40 block">التوصيل للمنزل</span>
              <span className="text-sm font-bold text-white font-mono">{formatDZD(deliveryResult.home)}</span>
            </div>
            <div className="bg-[#070A0F] p-3 rounded-xl border border-white/5">
              <span className="text-[10px] text-white/40 block">المدة المقدرة</span>
              <span className="text-[10px] font-bold text-[#18C29C] block mt-0.5">{deliveryResult.duration}</span>
            </div>
          </div>
        </Card>

        {/* 3. Pricing Suggestion Tool */}
        <Card className="p-6 bg-[#0E141C] border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/5">
              <Sparkles className="w-5 h-5 text-[#E0B15A]" />
              <h2 className="text-base font-bold text-white">أداة اقتراح وتثمين الأسعار الذكية</h2>
            </div>

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs text-white/50">تكلفة اقتناء/صنع المنتج الأساسية (د.ج)</label>
                <Input 
                  type="number" 
                  value={purchaseCost} 
                  onChange={e => setPurchaseCost(e.target.value)} 
                  className="h-10 text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div className="mt-6 space-y-2">
            <span className="text-[10px] text-white/40 block mb-1">الأسعار المقترحة للتاجر:</span>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-[#070A0F]/50 p-2.5 rounded-lg border border-white/5 flex justify-between items-center">
                <span className="text-[10px] text-white/50">هامش منخفض (20%):</span>
                <span className="text-xs font-bold text-white font-mono">{formatDZD(sugerLow)}</span>
              </div>
              <div className="bg-[#070A0F]/50 p-2.5 rounded-lg border border-white/5 flex justify-between items-center">
                <span className="text-[10px] text-white/50">سعر تجاري فعال (45%):</span>
                <span className="text-xs font-bold text-white font-mono">{formatDZD(sugerNormal)}</span>
              </div>
              <div className="bg-[#070A0F]/50 p-2.5 rounded-lg border border-white/5 flex justify-between items-center">
                <span className="text-[10px] text-white/50">هامش مرتفع (80%):</span>
                <span className="text-xs font-bold text-[#18C29C] font-mono">{formatDZD(sugerHigh)}</span>
              </div>
              <div className="bg-[#070A0F]/50 p-2.5 rounded-lg border border-white/5 flex justify-between items-center">
                <span className="text-[10px] text-amber-400">سعر بسيكولوجي (X90):</span>
                <span className="text-xs font-bold text-amber-400 font-mono">{formatDZD(sugerPsychological)}</span>
              </div>
            </div>
          </div>
        </Card>

        {/* 4. Conversion Estimator */}
        <Card className="p-6 bg-[#0E141C] border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/5">
              <TrendingUp className="w-5 h-5 text-[#25D366]" />
              <h2 className="text-base font-bold text-white">مقدّر تحويل الزوار (Views &rarr; Clients)</h2>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs text-white/50">عدد الزيارات المتوقعة/الفعلية للسلعة</label>
                  <Input 
                    type="number" 
                    value={views} 
                    onChange={e => setViews(e.target.value)} 
                    className="h-10 text-xs font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-white/50">عدد نقرات واتساب (WhatsApp Clicks)</label>
                  <Input 
                    type="number" 
                    value={currentClicks} 
                    onChange={e => setCurrentClicks(e.target.value)} 
                    className="h-10 text-xs font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-3 bg-[#070A0F]/50 rounded-xl border border-white/5 space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-white/60">نسبة تفاعل الزوار (CTR):</span>
              <span className="font-mono font-bold text-[#18C29C]">{clickThroughRate}%</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-white/60">الطلبيات المحتمل تدوينها (توقع 15%):</span>
              <span className="font-bold text-white">{expectedOrders} طلبات بيع كلي</span>
            </div>
            <div className="text-[9px] text-white/40 border-t border-white/5 pt-1.5 font-medium leading-relaxed">
              * في المتوسط بالجزائر، كل 100 زائر لصفحة جيدة، ينقر 5 لـ7 للواتساب، ومنهم 1 لـ2 يقوم بشراء السلعة فعلاً والدفع عن الاستلام.
            </div>
          </div>
        </Card>

        {/* 5. Listing Quality Score Tool */}
        <Card className="p-6 bg-[#0E141C] border border-white/10 lg:col-span-2">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/5">
            <CheckCircle className="w-5 h-5 text-[#18C29C]" />
            <h2 className="text-base font-bold text-white">مقياس جودة الإعلانات والسلع (Listing Quality Score)</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <span className="text-xs text-white/50 block">اضبط عوامل إشهارك واختبر قوتها في الظهور:</span>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-white/70">طول عنوان السلعة:</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={titleLength} 
                      onChange={e => setTitleLength(Number(e.target.value))}
                      className="accent-[#18C29C] h-1"
                    />
                    <span className="font-mono text-white/60 w-8 text-left">{titleLength}حرف</span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-white/70">توفير وصف تفصيلي واضح:</span>
                  <input 
                    type="checkbox" 
                    checked={hasDescription} 
                    onChange={e => setHasDescription(e.target.checked)}
                    className="w-4 h-4 rounded accent-[#18C29C]"
                  />
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-white/70">عدد الصور المرفقة:</span>
                  <select 
                    value={imgCount} 
                    onChange={e => setImgCount(Number(e.target.value))}
                    className="bg-[#070A0F] border border-white/10 rounded px-2 py-0.5 text-xs text-white"
                  >
                    <option value="0">بلا صور</option>
                    <option value="1">صورة واحدة</option>
                    <option value="3">3 صور</option>
                    <option value="5">5 صور أو أكثر</option>
                  </select>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-white/70">تحديد الولاية بشكل صحيح:</span>
                  <input 
                    type="checkbox" 
                    checked={specifiesWilaya} 
                    onChange={e => setSpecifiesWilaya(e.target.checked)}
                    className="w-4 h-4 rounded accent-[#18C29C]"
                  />
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-white/70">تحديد السعر بكل شفافية:</span>
                  <input 
                    type="checkbox" 
                    checked={specifiesPrice} 
                    onChange={e => setSpecifiesPrice(e.target.checked)}
                    className="w-4 h-4 rounded accent-[#18C29C]"
                  />
                </div>
              </div>
            </div>

            <div className="bg-[#070A0F] p-4 rounded-xl border border-white/5 flex flex-col justify-center items-center text-center">
              <span className="text-xs text-white/50 mb-1">نقاط قوة الإعلان المتوقعة</span>
              <div className="relative flex items-center justify-center my-3">
                {/* Visual circular representation or big text */}
                <div className="text-4xl font-extrabold font-mono text-[#18C29C]">
                  {qualityScore}%
                </div>
              </div>

              {qualityScore >= 80 ? (
                <div className="text-emerald-400 text-xs mt-1 font-semibold flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" /> إعلان مثالي وموثوق ويضمن أعلى تحويل!
                </div>
              ) : qualityScore >= 50 ? (
                <div className="text-amber-400 text-xs mt-1 font-semibold flex items-center gap-1">
                  <Info className="w-4 h-4" /> جودة مقبولة، لكن إرفاق صور واضحة يضاعف المبيعات.
                </div>
              ) : (
                <div className="text-red-400 text-xs mt-1 font-semibold flex items-center gap-1">
                  <ShieldAlert className="w-4 h-4" /> جودة ضعيفة جداً! ننصح بزيادة التفاصيل لضمان نقر الزوار.
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* Chrome Extension & Capture Tool Strategy Block - Market Domination */}
        <Card className="p-6 bg-gradient-to-tr from-[#151C26] to-[#0E141C] border border-[#18C29C]/30 lg:col-span-2">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/5">
            <div className="flex items-center gap-2">
              <span className="bg-[#18C29C]/10 text-[#18C29C] text-[10px] font-bold px-2 py-0.5 rounded border border-[#18C29C]/20">التوسع السريع ومضاعفة الانتشار</span>
              <h2 className="text-base font-bold text-white">إضافة متصفح كروم الذكية لـ ريادة (RIYADA Extension Overlay)</h2>
            </div>
            <span className="bg-amber-500/10 text-amber-400 text-[9px] font-bold px-2 py-0.5 rounded border border-amber-500/15">تفعيل فوري</span>
          </div>

          <div className="space-y-4">
            <p className="text-xs text-white/50 leading-relaxed">
              قم بتحميل أو إعداد ميزة <strong>"الاستيراد الفوري"</strong> المتوافقة بالكامل مع المتصفحات لنسخ وحفظ أي إعلان تجاري أو طلب عمل من مواقع السوشيال ميديا وتهيئتها كمخزون رسمي بلمسة واحدة:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="bg-[#070A0F] p-4 rounded-xl border border-white/5 space-y-2">
                <span className="text-xl">📥</span>
                <h4 className="text-xs font-bold text-white">استيراد بلمسة واحدة</h4>
                <p className="text-[10px] text-white/40 leading-relaxed">زر "افتح بـ ريادة" يظهر عند النقر الأيمن بأي موقع لتحويل المنشور لسلعة فوراً.</p>
              </div>

              <div className="bg-[#070A0F] p-4 rounded-xl border border-white/5 space-y-2">
                <span className="text-xl">📋</span>
                <h4 className="text-xs font-bold text-white">اللقاط اليدوي السريع</h4>
                <p className="text-[10px] text-white/40 leading-relaxed">انسخ أي نص إعلاني من فيسبوك وجرب خاصية التحليل والتوليد الآلي للعرض.</p>
              </div>

              <div className="bg-[#070A0F] p-4 rounded-xl border border-white/5 space-y-2">
                <span className="text-xl">🔄</span>
                <h4 className="text-xs font-bold text-white">النقل وتعميم الهوية </h4>
                <p className="text-[10px] text-white/40 leading-relaxed">تصدير المتجر كملف JSON واستيراده للتنقل الكامل بين الأجهزة دون حساب مركزي.</p>
              </div>
            </div>

            <div className="bg-[#070A0F] p-4 rounded-xl border border-white/10 space-y-3">
              <span className="text-xs text-brand-400 font-bold block">🚀 محاكي اللقاط السريع للمعلومات (Import Capture Form):</span>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input 
                  type="text" 
                  placeholder="ألصق رابط الإعلان الخارجي أو النص هنا..."
                  className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-[#18C29C] placeholder:text-white/30"
                />
                <Button 
                  onClick={() => {
                    alert('✨ تم محاكاة التقاط وتحليل الإدخال بنجاح!\nسيتم نقل تفاصيل المنتج المهيأة وتلقيمها لاستمارة إنشاء المعروضات تلقائياً لتقليل وقت التنزيل إلى أقل من 10 ثوانٍ.');
                  }}
                  className="bg-[#18C29C] hover:opacity-95 text-black font-extrabold text-xs shrink-0"
                >
                  استيراد الإعلان ومطابقته 🛒
                </Button>
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                variant="secondary"
                onClick={() => {
                  alert('🔗 تم توليد حزمة الإضافة البرمجية بنجاح!\nقم بزيارة إعدادات كروم واختيار "Load unpacked" لتركيب أزرار الاستيراد السريع لريادة بصفحات الويب.');
                }}
                className="text-xs font-bold py-2 w-full text-white/90"
              >
                تنزيل ملف الإضافة (Manifest v3 Draft JSON)
              </Button>
            </div>
          </div>
        </Card>

        {/* 6. Receipt Validator Helper (New v12 Security Addon) */}
        <Card className="p-6 bg-[#0E141C] border border-white/10 lg:col-span-2">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/5">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-white">مدقق إثباتات ووصولات الحوالات القياسي (Receipt Validator Helper)</h2>
          </div>

          <div className="space-y-4">
            <p className="text-xs text-white/50 leading-relaxed">
              تساعدك هذه الأداة اليدوية على تفادي محاولات التحايل عبر وصولات CCP المكررة أو المزورة رقمياً. أدخل رقم العملية/المرجع المكتوب على وصل الزبون لإجراء المطابقة الأولية:
            </p>

            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="أدخل مراجع العملية الفردي (مثال: 94002319401)"
                value={receiptTxRef}
                onChange={e => setReceiptTxRef(e.target.value)}
                className="flex-1 bg-[#070A0F] border border-white/10 rounded-xl px-4 py-2 text-xs text-white text-center font-mono outline-none focus:border-[#18C29C]"
              />
              <Button 
                onClick={handleValidateReceipt}
                className="bg-[#18C29C] hover:opacity-95 text-black font-bold text-xs"
              >
                فحص الوثيقة
              </Button>
            </div>

            {receiptWarningFeedback.map((m, i) => (
              <div key={i} className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-xl">
                ⚠️ {m}
              </div>
            ))}

            {receiptCleanFeedback.map((m, i) => (
              <div key={i} className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-[#18C29C] text-xs rounded-xl">
                ✓ {m}
              </div>
            ))}

            <div className="p-4 bg-[#070A0F] rounded-xl border border-white/5 text-[11px] text-white/40 space-y-2">
              <span className="font-bold text-white block mb-1">📋 القائمة الأمنية الحاكمة لتسليم البضاعة للبائعين:</span>
              <p>1. مطابقة دقيقة للاسم: تأكد من تطابق اسم المرسل في صور الوصل مع رقم هوية الطرف الطالب.</p>
              <p>2. لا ترسل السلعة مع وكلاء التوصيل إلا بعد فحص حركة كشف الحساب من بريدي موب بنفسك.</p>
              <p>3. تجنب تواريخ العطل الأسبوعية: حيث ينتهز المخادعون فرصة تأخر وصول رسائل إشعارات الهاتف البريدية.</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
