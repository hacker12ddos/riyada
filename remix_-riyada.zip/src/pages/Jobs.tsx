import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { getJobs, createJobPost, applyToJob, JobPost } from '../lib/economy';
import { ALGERIAN_WILAYAS } from '../lib/db';
import { useToast } from '../contexts/ToastContext';
import { 
  Briefcase, 
  MapPin, 
  Search, 
  Plus, 
  X, 
  Clock, 
  Sparkles, 
  Users, 
  Phone, 
  DollarSign, 
  AlertTriangle 
} from 'lucide-react';
import { formatDZD } from '../lib/utils';

export default function Jobs() {
  const { success, error } = useToast();
  const [jobs, setJobs] = useState<JobPost[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedWilaya, setSelectedWilaya] = useState('الكل');

  // New job modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newEmployer, setNewEmployer] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newCategory, setNewCategory] = useState('manual_labor');
  const [newWilaya, setNewWilaya] = useState('الجزائر');
  const [newSalaryMin, setNewSalaryMin] = useState(3000);
  const [newSalaryMax, setNewSalaryMax] = useState(5000);
  const [newContractType, setNewContractType] = useState<'daily' | 'weekly' | 'monthly' | 'task'>('daily');
  const [newRequirements, setNewRequirements] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newUrgency, setNewUrgency] = useState<'normal' | 'urgent' | 'immediate'>('normal');

  // Application modal
  const [applyingJob, setApplyingJob] = useState<JobPost | null>(null);
  const [appWorkerName, setAppWorkerName] = useState('');
  const [appWorkerPhone, setAppWorkerPhone] = useState('');
  const [appProposalText, setAppProposalText] = useState('');
  const [appProposedRate, setAppProposedRate] = useState('');

  const categories = [
    { id: 'all', name: 'الكل' },
    { id: 'manual_labor', name: '🧱 أعمال يدوية وتعبئة' },
    { id: 'technical_repair', name: '🔧 صيانة وتقنيات' },
    { id: 'digital_freelance', name: '💻 مستقل رقمي وخدمات حرة' },
    { id: 'delivery_drivers', name: '🚗 خدمات نقل طرود وسائقين' },
    { id: 'administration', name: '💼 إدارة مبيعات واستقبال' }
  ];

  useEffect(() => {
    setJobs(getJobs());
  }, []);

  const handlePostJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newEmployer || !newPhone || !newRequirements || !newDesc) {
      error('خطأ في المدخلات', 'يرجى تعبئة جميع الحقول لبدء الإشهار عن الوظيفة.');
      return;
    }

    const reqs = newRequirements.split(',').map(r => r.trim()).filter(Boolean);

    createJobPost({
      title: newTitle,
      employerName: newEmployer,
      employerPhone: newPhone,
      category: newCategory,
      wilaya: newWilaya,
      salaryMin: Number(newSalaryMin),
      salaryMax: Number(newSalaryMax),
      contractType: newContractType,
      requirements: reqs,
      description: newDesc,
      urgency: newUrgency
    });

    success('تم نشر فرصة العمل', 'تم إدراج فرصة العمل بنجاح في سوق ريادة المهني!');
    setIsModalOpen(false);
    setJobs(getJobs());

    // Reset Form
    setNewTitle('');
    setNewEmployer('');
    setNewPhone('');
    setNewRequirements('');
    setNewDesc('');
  };

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyingJob) return;
    if (!appWorkerName || !appWorkerPhone || !appProposalText) {
      error('خطأ', 'يرجى إدخال اسمك ورقم هاتفك مع رسالة عرضك التقريبية لتقديم الطلب.');
      return;
    }

    applyToJob(applyingJob.id, {
      jobId: applyingJob.id,
      workerId: `WKR-${Math.floor(100000 + Math.random() * 900000)}`,
      workerName: appWorkerName,
      workerPhone: appWorkerPhone,
      proposalText: appProposalText,
      proposedRate: Number(appProposedRate) || applyingJob.salaryMin
    });

    success('تم تقديم الطلب بنجاح', `تم إخطار المعلن بمؤهلاتك وتفاصيل عرضك عبر صندوق صفقات ريادة!`);
    setApplyingJob(null);
    setJobs(getJobs());

    // Reset App Form
    setAppWorkerName('');
    setAppWorkerPhone('');
    setAppProposalText('');
    setAppProposedRate('');
  };

  const filteredJobs = jobs.filter(j => {
    const matchesSearch = j.title.toLowerCase().includes(search.toLowerCase()) || 
      j.description.toLowerCase().includes(search.toLowerCase()) ||
      j.employerName.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || j.category === selectedCategory;
    const matchesWilaya = selectedWilaya === 'الكل' || j.wilaya === selectedWilaya;
    return matchesSearch && matchesCategory && matchesWilaya;
  });

  const getContractLabel = (type: string) => {
    switch (type) {
      case 'daily': return 'يومي';
      case 'weekly': return 'أسبوعي';
      case 'monthly': return 'شهري';
      case 'task': return 'عمل حر بالمشروع';
      default: return type;
    }
  };

  return (
    <div className="space-y-6">
      {/* Upper Banner Section */}
      <div className="bg-gradient-to-r from-[#0E141C] via-[#101925] to-[#0E141C] border border-white/10 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <span className="bg-[#18C29C]/10 text-[#18C29C] text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-[#18C29C]/20">سوق العمل والوظائف للجزائريين 💼</span>
          <h1 className="text-xl md:text-2xl font-extrabold text-white">وظّف مهارات محلية موثوقة لمشروعك أو متجرك</h1>
          <p className="text-white/50 text-xs md:text-sm max-w-2xl">
            أعلن مجاناً عن حاجتك لعمال توصيل، عمال تعبئة وتجهيز طرود، مسوقين، أو مطوري أعمال لمتجرك على ريادة.
          </p>
        </div>
        <Button 
          onClick={() => setIsModalOpen(true)}
          className="bg-[#18C29C] hover:opacity-95 text-black font-extrabold text-xs px-5 py-3 rounded-xl shadow-lg shrink-0 gap-1.5 flex items-center"
        >
          <Plus className="w-4 h-4" />
          ابدأ بالإعلان عن وظيفة شاغرة 📢
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center bg-[#0E141C] p-4 rounded-xl border border-white/5">
        <div className="md:col-span-5 relative">
          <input 
            type="text" 
            placeholder="ابحث عن وظائف (مثال: شحن طرود، مبيعات، تصميم)..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-brand-500/50 pl-10"
          />
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-3.5" />
        </div>

        <div className="md:col-span-3">
          <select 
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-brand-500/50"
          >
            {categories.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div className="md:col-span-4">
          <select 
            value={selectedWilaya}
            onChange={e => setSelectedWilaya(e.target.value)}
            className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-brand-500/50"
          >
            <option value="الكل">كل الولايات</option>
            {ALGERIAN_WILAYAS.map(w => (
              <option key={w.id} value={w.name}>{w.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {filteredJobs.map(j => (
          <Card key={j.id} className="bg-[#0E141C] border border-white/10 p-5 flex flex-col justify-between hover:border-brand-500/20 transition-all">
            <div className="space-y-3.5">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-[#18C29C] transition-colors mb-1">{j.title}</h3>
                  <p className="text-[11px] text-[#18C29C] font-semibold">{j.employerName}</p>
                </div>
                {j.urgency === 'immediate' ? (
                  <span className="bg-red-500/10 text-red-400 text-[9px] font-bold px-2 py-0.5 rounded border border-red-500/25 flex items-center gap-1 animate-pulse">
                    <AlertTriangle className="w-3 h-3" /> عاجل فوراً
                  </span>
                ) : j.urgency === 'urgent' ? (
                  <span className="bg-amber-500/10 text-amber-400 text-[9px] font-bold px-2 py-0.5 rounded border border-amber-500/25">عاجل</span>
                ) : (
                  <span className="bg-white/5 text-white/50 text-[9px] font-bold px-2 py-0.5 rounded border border-white/5">نشط</span>
                )}
              </div>

              <p className="text-xs text-white/50 leading-relaxed line-clamp-3">{j.description}</p>

              {/* Requirements tags and checklist */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] text-white/40 block">المتطلبات الأساسية للوظيفة والشروط:</span>
                <div className="flex flex-wrap gap-1.5">
                  {j.requirements.map((req, i) => (
                    <span key={i} className="text-[9px] bg-[#18C29C]/5 text-[#18C29C] px-2.5 py-1 rounded border border-[#18C29C]/10 font-bold">
                      • {req}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-t border-white/5 pt-4 mt-5 flex justify-between items-center text-xs">
              <div className="flex flex-col gap-1 text-[11px] text-white/50">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-white/40" />
                  <span>الولاية الحاكمة: <strong>{j.wilaya}</strong></span>
                </div>
                <div className="flex items-center gap-1.5 font-mono">
                  <Clock className="w-3.5 h-3.5 text-white/40" />
                  <span>نظام العقد: {getContractLabel(j.contractType)}</span>
                </div>
              </div>

              <div className="text-left space-y-2">
                <div className="font-mono text-white text-right">
                  <span className="text-[10px] text-white/40 block">الراتب المتوقع:</span>
                  <strong className="text-sm font-bold text-[#18C29C]">{formatDZD(j.salaryMin)}</strong>
                  {j.salaryMax > j.salaryMin && <span> - <strong className="text-sm font-bold text-[#18C29C]">{formatDZD(j.salaryMax)}</strong></span>}
                </div>

                <div className="flex gap-2">
                  <Button 
                    size="sm"
                    onClick={() => {
                      const msg = `مرحباً ${j.employerName}، قرأت إعلانك الشاغر بخصوص: "${j.title}" عبر ريادة...`;
                      window.open(`https://wa.me/${j.employerPhone}?text=${encodeURIComponent(msg)}`, '_blank');
                    }}
                    className="bg-white/5 hover:bg-white/10 border border-white/10 text-white text-[10px] h-8 px-2.5"
                  >
                    <Phone className="w-3 h-3 text-brand-400" />
                    مراسلة فورية
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => setApplyingJob(j)}
                    className="bg-[#18C29C] hover:opacity-95 text-black font-extrabold text-[10px] h-8 px-4"
                  >
                    تقديم طلب للوظيفة
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}

        {filteredJobs.length === 0 && (
          <div className="col-span-full py-16 text-center text-white/40 space-y-3">
            <Briefcase className="w-12 h-12 mx-auto stroke-1" />
            <h4 className="text-sm font-bold text-white">لا توجد فرصة عمل بهذا البحث حالياً</h4>
            <p className="text-xs text-white/50 leading-relaxed max-w-sm mx-auto">
              تصفح التخصصات الأخرى أو شارك سلتك وخدماتك للتوظيف!
            </p>
          </div>
        )}
      </div>

      {/* New Job Post Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-[#0E141C] border border-white/10 w-full max-w-lg p-6 space-y-4 relative">
            <button 
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 left-4 text-white/50 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 border-b border-white/5 pb-3">
              <Sparkles className="w-5 h-5 text-brand-400" />
              <h2 className="text-base font-bold text-white">أعلن عن فرصة عمل شاغرة لمكتبك أو متجرك في ريادة</h2>
            </div>

            <form onSubmit={handlePostJob} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-white/60">عنوان الوظيفة بوضوح:</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: مطلوب عامل ديليفري وتوصيل في باب الزوار بسيارته الخاصة"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-white/60">اسم صاحب العمل/المتجر:</label>
                  <input 
                    type="text" 
                    required
                    placeholder="مثال: بقالة الريف السعيد"
                    value={newEmployer}
                    onChange={e => setNewEmployer(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-white/60">رقم الهاتف للتواصل السريع:</label>
                  <input 
                    type="tel" 
                    required
                    placeholder="مثال: 0551029384"
                    value={newPhone}
                    onChange={e => setNewPhone(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white font-mono outline-none focus:border-brand-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-white/60">تصنيف العمل:</label>
                  <select 
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  >
                    {categories.filter(c => c.id !== 'all').map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-white/60">ولاية العمل الفعلية:</label>
                  <select 
                    value={newWilaya}
                    onChange={e => setNewWilaya(e.target.value)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  >
                    {ALGERIAN_WILAYAS.map(w => (
                      <option key={w.id} value={w.name}>{w.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-white/60">نظام العقد:</label>
                  <select 
                    value={newContractType}
                    onChange={e => setNewContractType(e.target.value as any)}
                    className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                  >
                    <option value="daily">يومي</option>
                    <option value="weekly">أسبوعي</option>
                    <option value="monthly">شهري</option>
                    <option value="task">مشروع مستقل</option>
                  </select>
                </div>
                <div className="space-y-1 col-span-2">
                  <label className="text-white/60">الراتب / اليومية المتوقعة (دج):</label>
                  <div className="flex gap-2">
                    <input 
                      type="number" 
                      placeholder="الحد الأدنى"
                      value={newSalaryMin}
                      onChange={e => setNewSalaryMin(Number(e.target.value))}
                      className="w-1/2 bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white text-center font-mono outline-none focus:border-brand-500"
                    />
                    <input 
                      type="number" 
                      placeholder="الأعلى (اختياري)"
                      value={newSalaryMax}
                      onChange={e => setNewSalaryMax(Number(e.target.value))}
                      className="w-1/2 bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white text-center font-mono outline-none focus:border-brand-500"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-white/60">سرعة الطلب والضرورية:</label>
                <select 
                  value={newUrgency}
                  onChange={e => setNewUrgency(e.target.value as any)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                >
                  <option value="normal">عادي</option>
                  <option value="urgent">عاجل</option>
                  <option value="immediate">مستعجل فوراً للبدء الغد</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-white/60">المؤهلات والشروط بفاصلة لسهولة القراءة:</label>
                <input 
                  type="text" 
                  required
                  placeholder="سرعة الفهم, القاطنين في زرالدة, التفرغ التام"
                  value={newRequirements}
                  onChange={e => setNewRequirements(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/60">تفاصيل الوصف والمهام المطلوبة من العامل:</label>
                <textarea 
                  rows={3}
                  required
                  placeholder="اكتب المهام اليومية، أوقات العمل، وعناوين التوصيل المرتقبة..."
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white resize-none outline-none focus:border-brand-500"
                />
              </div>

              <Button 
                type="submit"
                className="w-full bg-[#18C29C] hover:opacity-95 text-black font-extrabold h-11 text-xs"
              >
                تأكيد ونشر العرض الشاغر للجميع
              </Button>
            </form>
          </Card>
        </div>
      )}

      {/* Applying For Job Modal */}
      {applyingJob && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-[#0E141C] border border-white/10 w-full max-w-md p-6 space-y-4 relative">
            <button 
              onClick={() => setApplyingJob(null)}
              className="absolute top-4 left-4 text-white/50 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 border-b border-white/5 pb-2">
              <Briefcase className="w-5 h-5 text-brand-400" />
              <h2 className="text-sm font-bold text-white">تفاوض وقدم طلبك للوظيفة الشاغرة</h2>
            </div>

            <p className="text-[11px] text-white/50">الوظيفة: <strong className="text-white">{applyingJob.title}</strong></p>

            <form onSubmit={handleApplySubmit} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="text-white/60">اسمك الموقر:</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: جمال بن يحيى"
                  value={appWorkerName}
                  onChange={e => setAppWorkerName(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-brand-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/60">رقم هاتفك المحمول:</label>
                <input 
                  type="tel" 
                  required
                  placeholder="مثال: 0772000000"
                  value={appWorkerPhone}
                  onChange={e => setAppWorkerPhone(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white font-mono outline-none focus:border-brand-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/60">تسعيرتك المقترحة المقبولة (DZD):</label>
                <input 
                  type="number" 
                  placeholder={`الراتب المفترض: ${applyingJob.salaryMin} دج`}
                  value={appProposedRate}
                  onChange={e => setAppProposedRate(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white text-center font-mono outline-none focus:border-brand-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-white/60">مسودة مهاراتك ورسالتك للمعلّن لتسهيل اختيارك:</label>
                <textarea 
                  rows={3.5}
                  required
                  placeholder="أنا جاد في تلبية النداء وأمتلك وسائل تنقل وخبرة سنتين..."
                  value={appProposalText}
                  onChange={e => setAppProposalText(e.target.value)}
                  className="w-full bg-[#070A0F] border border-white/10 rounded-xl px-3 py-2 text-white resize-none outline-none focus:border-brand-500"
                />
              </div>

              <Button 
                type="submit"
                className="w-full bg-[#18C29C] text-black font-extrabold h-11 text-xs"
              >
                تأكيد وبدء التفاوض والمراسلة
              </Button>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
}
