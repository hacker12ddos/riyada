import React, { useState } from 'react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card } from '../components/ui/Card';
import { Store, Phone, MapPin, Briefcase } from 'lucide-react';
import { ALGERIAN_WILAYAS } from '../lib/db';
import { motion } from 'motion/react';

export default function Onboarding() {
  const { createNewWorkspace } = useWorkspace();
  const [formData, setFormData] = useState({
    name: '',
    type: 'retail',
    phone: '',
    wilaya: '16'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await createNewWorkspace({
      name: formData.name,
      type: formData.type,
      phone: formData.phone,
      settings: {
        wilaya: formData.wilaya,
        deliveryFees: {}
      }
    });
    // Context will automatically update active workspace, navigating away
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-[#05070a]">
      {/* Background gradients */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-brand-600/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[120px]" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-10"
      >
        <Card className="glass relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-400 to-cyan-500" />
          
          <div className="text-center mb-8 pt-4">
            <div className="w-16 h-16 bg-brand-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-brand-500/30 shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              <Store className="w-8 h-8 text-brand-400" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">مرحباً بك في ريادة</h1>
            <p className="text-white/50 text-sm">أنشئ مساحة العمل الخاصة بمتجرك للبدء في منظومة الاقتصاد الرقمي الجزائري</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <Input
              label="اسم المتجر / العمل"
              placeholder="مثال: متجر الأناقة"
              icon={<Store className="w-4 h-4" />}
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
            
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">مجال العمل</label>
              <div className="relative">
                <select
                  className="glass-input flex h-11 w-full rounded-xl px-4 py-2 text-sm text-white appearance-none ps-10"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  <option value="retail" className="bg-[#0a0f18]">بيع بالتجزئة (ملابس، إلكترونيات)</option>
                  <option value="food" className="bg-[#0a0f18]">مطعم / مقهى</option>
                  <option value="services" className="bg-[#0a0f18]">خدمات</option>
                  <option value="realestate" className="bg-[#0a0f18]">عقارات</option>
                </select>
                <Briefcase className="w-4 h-4 text-white/50 absolute top-3.5 right-3" />
              </div>
            </div>

            <Input
              label="رقم الهاتف الأساسي"
              placeholder="0555 12 34 56"
              icon={<Phone className="w-4 h-4" />}
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              required
            />

            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-white/70">الولاية (المقر)</label>
              <div className="relative">
                <select
                  className="glass-input flex h-11 w-full rounded-xl px-4 py-2 text-sm text-white appearance-none ps-10"
                  value={formData.wilaya}
                  onChange={(e) => setFormData({ ...formData, wilaya: e.target.value })}
                >
                  {ALGERIAN_WILAYAS.map(w => (
                    <option key={w.id} value={w.name} className="bg-[#0a0f18]">{w.id} - {w.name}</option>
                  ))}
                </select>
                <MapPin className="w-4 h-4 text-white/50 absolute top-3.5 right-3" />
              </div>
            </div>

            <Button type="submit" className="w-full mt-4" size="lg" isLoading={isSubmitting}>
              إنشاء مساحة العمل
            </Button>
          </form>
        </Card>
      </motion.div>
    </div>
  );
}
