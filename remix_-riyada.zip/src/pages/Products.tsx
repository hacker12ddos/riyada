import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Package, Plus, Search, Filter, Edit, Trash2, ArrowRight } from 'lucide-react';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { getItemsByWorkspace, Product, addItem } from '../lib/db';
import { SEED_DATA } from '../lib/seed';
import { formatDZD } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import AddProductForm from './AddProductForm';

export default function Products() {
  const { activeWorkspace } = useWorkspace();
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (activeWorkspace) {
      loadProducts(activeWorkspace.id);
    }
  }, [activeWorkspace]);

  const loadProducts = async (workspaceId: string) => {
    setIsLoading(true);
    try {
      const items = await getItemsByWorkspace('products', workspaceId);
      setProducts(items || []);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleProductAdded = async () => {
    if (activeWorkspace) {
      await loadProducts(activeWorkspace.id);
    }
    setIsAdding(false);
  };

  if (isAdding) {
    return (
      <div className="space-y-6">
        <button 
          onClick={() => setIsAdding(false)}
          className="flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors"
        >
          <ArrowRight className="w-4 h-4" />
          العودة للمخزون
        </button>
        <AddProductForm onSaved={handleProductAdded} onCancel={() => setIsAdding(false)} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">المنتجات والمخزون</h1>
          <p className="text-white/50">إدارة منتجاتك، تتبع المخزون والأسعار.</p>
        </div>
        <Button className="shrink-0 gap-2" onClick={() => setIsAdding(true)}>
          <Plus className="w-4 h-4" />
          <span>إضافة منتج جديد</span>
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <Input 
            placeholder="البحث عن منتج..." 
            icon={<Search className="w-4 h-4" />}
            className="md:max-w-xs"
          />
          <Button variant="secondary" className="gap-2 shrink-0 md:ms-auto">
            <Filter className="w-4 h-4" />
            <span>تصفية</span>
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm text-white/70">
            <thead className="text-xs text-white/30 border-b border-white/5">
              <tr className="h-10">
                <th className="px-4 py-2 font-medium">المنتج</th>
                <th className="px-4 py-2 font-medium">الصنف</th>
                <th className="px-4 py-2 font-medium">السعر</th>
                <th className="px-4 py-2 font-medium">المخزون</th>
                <th className="px-4 py-2 font-medium text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="text-xs">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="text-center py-8">جاري التحميل...</td>
                </tr>
              ) : products.map((product, idx) => (
                <motion.tr 
                  key={product.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="border-b border-white/5 h-14 hover:bg-white/5 transition-colors"
                >
                  <td className="px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center">
                        {product.image ? (
                           <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                        ) : (
                          <Package className="w-4 h-4 text-white/30" />
                        )}
                      </div>
                      <span className="font-medium text-white">{product.name}</span>
                    </div>
                  </td>
                  <td className="px-4 text-white/60">
                    <span className="bg-white/5 px-2 py-1 rounded border border-white/5">{product.category}</span>
                  </td>
                  <td className="px-4 text-left font-mono text-brand-400">
                    {formatDZD(product.price)}
                  </td>
                  <td className="px-4 text-center">
                    <span className={product.stock < 10 ? 'text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30' : 'text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30'}>
                      {product.stock} قطعة
                    </span>
                  </td>
                  <td className="px-4">
                    <div className="flex justify-center gap-2">
                      <button className="text-[10px] bg-brand-500/10 text-brand-400 px-3 py-1.5 rounded-lg border border-brand-500/20 hover:bg-brand-500/20 transition-all">
                        تعديل
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
              {products.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={5} className="text-center py-16">
                    <div className="flex flex-col items-center justify-center max-w-sm mx-auto">
                      <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center border border-white/10 mb-4 text-white/40">
                        <Package className="w-6 h-6" />
                      </div>
                      <h4 className="text-white font-medium text-base mb-1">المخزون فارغ</h4>
                      <p className="text-white/50 text-xs text-center leading-relaxed mb-4">
                        لم تقم بنشر أي سلع أو خدمات في متجرك حتى الآن. اضغط على أزرار الإضافة لنشر منتج جديد في السوق الجزائري.
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
