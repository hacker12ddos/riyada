import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { useToast } from '../contexts/ToastContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Chrome, 
  Settings, 
  ExternalLink, 
  Plus, 
  Copy, 
  Check, 
  Image as ImageIcon, 
  QrCode, 
  Globe, 
  Sparkles, 
  Download, 
  Upload, 
  Database, 
  TrendingUp, 
  Play, 
  Briefcase, 
  User, 
  ShoppingBag, 
  Scissors, 
  ArrowRight,
  Shield,
  HelpCircle,
  FileText
} from 'lucide-react';
import { formatDZD } from '../lib/utils';
import { ALGERIAN_WILAYAS, getItemsByWorkspace, addItem } from '../lib/db';
import { QRCodeSVG } from 'qrcode.react';

interface ExtDraft {
  title: string;
  price: number;
  wilaya: string;
  category: string;
  description: string;
  sourceUrl: string;
}

export default function ExtensionEcosystem() {
  const { activeWorkspace } = useWorkspace();
  const { success, error } = useToast();

  const [activeTab, setActiveTab] = useState<'extension' | 'toolbar' | 'pwa'>('extension');
  const [extUrl, setExtUrl] = useState('https://www.facebook.com/marketplace/item/849201938/');
  const [isScraping, setIsScraping] = useState(false);
  const [scrapedDraft, setScrapedDraft] = useState<ExtDraft | null>(null);
  const [hasCopiedText, setHasCopiedText] = useState(false);
  const [generatedPoster, setGeneratedPoster] = useState<any | null>(null);
  const [showPosterModal, setShowPosterModal] = useState(false);

  // Price Checker Simulation state
  const [priceItemName, setPriceItemName] = useState('كنديسيونار LG 12000 BTU');
  const [priceWilaya, setPriceWilaya] = useState('الجزائر');
  const [checkedPriceResults, setCheckedPriceResults] = useState<any | null>(null);

  // Backup & Export Storage Simulation state
  const [backupKey, setBackupKey] = useState('');
  const [importString, setImportString] = useState('');

  // 1. COMPANION EXTENSION: URL SCRAPING SIMULATOR
  const handleSimulateUrlScrape = () => {
    if (!extUrl.trim()) {
      error('رابط غير صالح', 'الرجاء إدخال عنوان URL حقيقي للمطابقة.');
      return;
    }
    setIsScraping(true);
    setScrapedDraft(null);

    setTimeout(() => {
      setIsScraping(false);
      // Generate simulated extracted metadata based on keyword inside URL or generic
      let inferredCategory = 'electronics';
      let title = 'هاتف ذكي سامسونج غالاكسي S23 الترا';
      let price = 145000;
      let wilaya = 'الجزائر';
      let description = 'هاتف مستعمل بحالة ممتازة جداً (باط بات)، مع الشاحن والتوصيل متوفر 58 ولاية بضمان يمتد لشهر.';

      if (extUrl.includes('furniture') || extUrl.includes('chair') || extUrl.includes('table')) {
        inferredCategory = 'furniture';
        title = 'طاولة صالون عصرية خشب زان متين';
        price = 18000;
        wilaya = 'البليدة';
        description = 'طاولة خشبية مميزة للصالونات والمجالس، جودة عالية جداً وتوصيل مجاني لولاية البليدة والجزائر.';
      } else if (extUrl.includes('job') || extUrl.includes('work')) {
        inferredCategory = 'jobs';
        title = 'مطلوب سائق توصيل للمحلات التجارية';
        price = 45000;
        wilaya = 'قسنطينة';
        description = 'نبحث عن سائق نفعي مع سيارته لنقل الطلبيات، تعاقد مغري ودفعات CCP أسبوعية.';
      }

      setScrapedDraft({
        title,
        price,
        wilaya,
        category: inferredCategory,
        description,
        sourceUrl: extUrl
      });
      success('تم كشط وتدقيق المسودة يدوياً', 'تلقى الإضافة بنجاح المحتوى وباشرت عزل البيانات لسلامة النزاهة.');
    }, 1200);
  };

  const handleSaveToRiyadaDraft = async () => {
    if (!scrapedDraft || !activeWorkspace) return;

    try {
      const newProduct = {
        id: `EXT-${Math.floor(100000 + Math.random() * 900000)}`,
        workspaceId: activeWorkspace.id,
        name: scrapedDraft.title,
        price: scrapedDraft.price,
        category: scrapedDraft.category === 'jobs' ? 'services' : scrapedDraft.category,
        stock: 5,
        description: `${scrapedDraft.description}\n\n[تم الاستيراد التلقائي عبر ملحق ريادة من: ${scrapedDraft.sourceUrl}]`,
        wilaya: scrapedDraft.wilaya,
        createdAt: Date.now()
      };

      await addItem('products', newProduct);
      success('تم الحفظ كمسودة نشطة!', 'تم نقل المنشور بنجاح إلى ريادة وتخصيص هوية المتجر.');
      setScrapedDraft(null);
    } catch (e) {
      error('خطأ في التأكيد', 'لا يمكن حفظ البيانات لـ IndexedDB.');
    }
  };

  const handleCopyListingText = () => {
    if (!scrapedDraft) return;
    const shareText = `🔗 معروض مستورد عبر ريادة [RIYADA]:\n🌟 الاسم: ${scrapedDraft.title}\n💰 السعر: ${scrapedDraft.price} دج\n📍 الولاية: ولاية ${scrapedDraft.wilaya}\n📝 تفاصيل: ${scrapedDraft.description}\n🗺️ تصفح عبر متجر ريادة v22 الخاص بنا!`;
    navigator.clipboard.writeText(shareText);
    setHasCopiedText(true);
    success('نسخ فوري بنجاح ✅', 'تم إعداد ونسخ النص لغرض التوعية ومجتمعات واتساب الجزائر المعتمدة.');
    setTimeout(() => setHasCopiedText(false), 2000);
  };

  const handleGeneratePosterAndQR = () => {
    if (!scrapedDraft) return;
    setGeneratedPoster({
      title: scrapedDraft.title,
      price: scrapedDraft.price,
      wilaya: scrapedDraft.wilaya,
      qrValue: `https://riyada.dz/shop/${activeWorkspace?.id || 'sim'}/item/${scrapedDraft.title.substring(0,6)}`
    });
    setShowPosterModal(true);
  };

  // 2. TOOLBAR PRICE MATCHING ENGINE
  const handleCheckAlgPrice = () => {
    if (!priceItemName.trim()) return;

    setIsScraping(true);
    setTimeout(() => {
      setIsScraping(false);
      // Simulated index lookup
      const basePrice = Math.floor(25000 + Math.random() * 85000);
      setCheckedPriceResults({
        itemName: priceItemName,
        averageWilayaPrice: basePrice,
        minObserved: Math.floor(basePrice * 0.9),
        maxObserved: Math.floor(basePrice * 1.15),
        wilaya: priceWilaya,
        demandScore: Math.floor(40 + Math.random() * 55), // demand out of 100
        alertMsg: Math.random() > 0.5 ? '⚠️ فارق الأسعار مرتفع بالولاية، ننصح بتحسين الكلفة للتميز.' : '💎 سعر متوازن ومطابق لمتوسط بيع CCP اليوم.'
      });
      success('تم حساب مؤشر السوق', 'تم احتساب مؤشر العرض والطلب ومطابقة البيانات لولاية ' + priceWilaya);
    }, 900);
  };

  // 3. BACKUP & EXPORTS
  const handleExportStateString = () => {
    const backupBlock = {
      workspaceId: activeWorkspace?.id,
      timestamp: Date.now(),
      platform: 'RIYADA v22 OS',
      payload: {
        productsCount: 14,
        settings: activeWorkspace?.settings || {}
      }
    };
    const str = btoa(JSON.stringify(backupBlock));
    setBackupKey(str);
    navigator.clipboard.writeText(str);
    success('تم توليد وتصدير شفرة التشفير محلياً!', 'تستطيع الآن تخزين هذه السلسلة في مستند نصي خارجي آمن.');
  };

  const handleImportStateString = () => {
    if(!importString.trim()) {
      error('شفرة فارغة', 'أدخل شفرة التشفير المستوردة.');
      return;
    }
    try {
      const decoded = JSON.parse(atob(importString.trim()));
      if (decoded.platform && decoded.platform.includes('RIYADA')) {
        success('استيراد مطابق وناجح للمخزن ⚡', `تم تنزيل واستعادة إعدادات محتويات المتجر وبيانات ولاية ${decoded.payload.settings.wilaya || 'غير محددة'} بنجاح.`);
        setImportString('');
      } else {
        error('تنسيق غير معرّف', 'لا تطابق شفرة التشفير البنية الهيكلية لريادة v22.');
      }
    } catch(e) {
      error('خطأ غير متوقع', 'شفرة التصدير تالفة أو معدلة خارجياً.');
    }
  };

  return (
    <div className="flex flex-col gap-6 text-right pb-12" dir="rtl">
      
      {/* HEADER BANNER */}
      <div className="bg-[#0e141c] border border-white/10 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-center gap-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500/10 rounded-full blur-3xl"></div>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-brand-400">
            <Chrome className="w-5 h-5 text-[#18C29C]" />
            <span className="text-xs font-black uppercase">عالم ملحقات وتسهيلات السير العضوي لريادة</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white">ملحقات المتصفح وشريط ريادة الذكي (Browser Extension Sandbox)</h2>
          <p className="text-xs text-white/50 leading-relaxed max-w-4xl">
            نقوم بتمكين البائع من نقل وتجميع وإدارة معروضاته محلياً عبر الملحق المرافق وشريط الأدوات التفاعلي. 
            <strong> لا نحتاج خوادم مركزية أو واجهات API ثقيلة</strong> لجمع البيانات، بل يعتمد النظام على الكشط التلقائي بمجرد تصفحك مجموعات فيس بوك أو صفحات واد كنيس لحرق العقبات البيروقراطية.
          </p>
        </div>

        {/* Action tabs selectors */}
        <div className="flex flex-wrap gap-2 shrink-0 border-t md:border-t-0 pt-4 md:pt-0">
          <Button 
            onClick={() => setActiveTab('extension')}
            className={`text-xs px-4 h-9 font-bold ${activeTab === 'extension' ? 'bg-[#18C29C] text-black' : 'bg-white/5 hover:bg-white/10 text-white'}`}
          >
            الملحق الرفيق (Riyada Companion)
          </Button>
          <Button 
            onClick={() => setActiveTab('toolbar')}
            className={`text-xs px-4 h-9 font-bold ${activeTab === 'toolbar' ? 'bg-[#18C29C] text-black' : 'bg-white/5 hover:bg-white/10 text-white'}`}
          >
            شريط الأدوات التفاعلي (User Toolbar)
          </Button>
          <Button 
            onClick={() => setActiveTab('pwa')}
            className={`text-xs px-4 h-9 font-bold ${activeTab === 'pwa' ? 'bg-[#18C29C] text-black' : 'bg-white/5 hover:bg-white/10 text-white'}`}
          >
            بوابة الفتح المستقل (Open Tab)
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* BIG DISPLAY CONTAINER */}
        <div className="lg:col-span-2 space-y-6">
          
          <AnimatePresence mode="wait">
            
            {/* TAB 1: EXTENSION SCRAPING HANDY SIMULATOR */}
            {activeTab === 'extension' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6"
              >
                <Card className="p-6 border-white/5 space-y-4 text-right">
                  <div className="border-b border-white/5 pb-2.5">
                    <h3 className="text-xs font-bold text-white flex items-center gap-1.5 justify-start">
                      <Sparkles className="w-4 h-4 text-[#18C29C]" />
                      <span>محاكاة جلب المعروضات من مجموعات الفيسبوك والسوق المفتوح الجزائري</span>
                    </h3>
                    <p className="text-[10px] text-white/40">ألصق رابط صفحة السلعة من فيس بوك أو واد كنيس، وسيترجم ملحق ريادة التفاصيل تلقائياً داخل جهازك.</p>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <input 
                      type="text" 
                      placeholder="أدخل عنوان URL لمنتج أو إعلان وظيفي ومطابقتها..."
                      value={extUrl}
                      onChange={e => setExtUrl(e.target.value)}
                      className="flex-1 bg-[#121620] border border-white/10 p-2.5 rounded-xl text-xs text-white outline-none focus:border-brand-500/55 font-mono"
                    />
                    <Button 
                      onClick={handleSimulateUrlScrape}
                      disabled={isScraping}
                      className="bg-brand-500 hover:bg-brand-600 text-black text-xs font-extrabold h-11 shrink-0 px-5"
                    >
                      {isScraping ? 'كابينة التحليل كشط مسودة...' : 'جلب وتوليد مسودة ريادة 🚀'}
                    </Button>
                  </div>

                  {/* Showing simulated draft result */}
                  {scrapedDraft && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-black/30 border border-white/10 p-5 rounded-2xl space-y-4"
                    >
                      <span className="bg-[#18C29C] text-black px-2 py-0.5 rounded text-[8px] font-black uppercase inline-block">
                        تفكيك المسودة بنجاح (Isolated Sandboxed Draft)
                      </span>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1 text-right">
                          <label className="text-[9px] text-white/40 block">اسم السلعة المستنتج:</label>
                          <input 
                            type="text" 
                            value={scrapedDraft.title}
                            onChange={e => setScrapedDraft({ ...scrapedDraft, title: e.target.value })}
                            className="w-full bg-[#121620] border border-white/5 rounded-lg p-2 text-xs text-white focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1 text-right">
                            <label className="text-[9px] text-white/40 block">السعر (دج):</label>
                            <input 
                              type="number" 
                              value={scrapedDraft.price}
                              onChange={e => setScrapedDraft({ ...scrapedDraft, price: Number(e.target.value) })}
                              className="w-full bg-[#121620] border border-white/5 rounded-lg p-2 text-xs text-emerald-400 font-mono text-center focus:outline-none"
                            />
                          </div>
                          <div className="space-y-1 text-right">
                            <label className="text-[9px] text-white/40 block">الولاية المترجمة:</label>
                            <select 
                              value={scrapedDraft.wilaya}
                              onChange={e => setScrapedDraft({ ...scrapedDraft, wilaya: e.target.value })}
                              className="w-full bg-[#121620] border border-white/5 rounded-lg p-2 text-xs text-white focus:outline-none"
                            >
                              {ALGERIAN_WILAYAS.map(w => (
                                <option key={w.id} value={w.name}>{w.name}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="col-span-full space-y-1 text-right">
                          <label className="text-[9px] text-white/40 block">الوصف المترجم عاطفياً:</label>
                          <textarea 
                            rows={3}
                            value={scrapedDraft.description}
                            onChange={e => setScrapedDraft({ ...scrapedDraft, description: e.target.value })}
                            className="w-full bg-[#121620] border border-white/5 rounded-lg p-2 text-xs text-white/70 resize-none focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Control keys for scraped layout */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-white/5 text-right">
                        
                        <button 
                          onClick={handleSaveToRiyadaDraft}
                          className="bg-[#18C29C] text-black rounded-xl text-[10px] font-black h-9 hover:opacity-90 flex items-center justify-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>تثبيت ونشر في ريادة</span>
                        </button>

                        <button 
                          onClick={handleCopyListingText}
                          className="bg-white/5 hover:bg-white/10 text-white rounded-xl text-[10px] font-bold h-9 flex items-center justify-center gap-1 border border-white/5"
                        >
                          {hasCopiedText ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>نسخ الكلمات بنقرة 📝</span>
                        </button>

                        <button 
                          onClick={handleGeneratePosterAndQR}
                          className="bg-white/5 hover:bg-white/10 text-white rounded-xl text-[10px] font-bold h-9 flex items-center justify-center gap-1 border border-white/5"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>توليد QR وملصق</span>
                        </button>

                        <button 
                          onClick={() => {
                            window.open(scrapedDraft.sourceUrl, '_blank');
                          }}
                          className="bg-white/5 hover:bg-white/10 text-white rounded-xl text-[10px] font-bold h-9 flex items-center justify-center gap-1 border border-white/5"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>الرابط الأصلي</span>
                        </button>

                      </div>

                    </motion.div>
                  )}
                </Card>

                {/* Information on user intent routing */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <Card className="p-5 border-white/5 space-y-3">
                    <h4 className="text-xs font-bold text-[#18C29C] leading-snug">🔒 الخصوصية والأمن والسيادة اللامركزية</h4>
                    <p className="text-[10px] text-white/55 leading-relaxed">
                      ملحق ريادة الرفيق v22 يعمل <strong>محلياً بالكامل</strong> داخل متصفحك. لا يرسل روابط فيسبوك أو معرّفات زبائنك لشركات الفلترة أو أي خادم وسيط. يتم تحليلات كبت البيانات ومعالجة الصور داخل كابينة آيس بوكس على متصفحك، مما يمنح المتاجر خصوصية وأمان مطلق من الهجمات.
                    </p>
                  </Card>

                  <Card className="p-5 border-white/5 space-y-3">
                    <h4 className="text-xs font-bold text-[#18C29C] leading-snug">⚡ تعليق ودمج الإعلان بنقرة واحدة</h4>
                    <p className="text-[10px] text-white/55 leading-relaxed">
                      فور الانتهاء من المعالجة التلقائية، تستطيع توليد الباركود QR للمتجر وحرق الرمز في بوستر فيروسي (Viral Poster) لتتم مشاركته على إنستقرام، وبذلك تسجل كفاءة نقل الحركة والنشاط دون وسطاء.
                    </p>
                  </Card>
                </div>
              </motion.div>
            )}

            {/* TAB 2: SELLER TOOLBAR BROWSER MODULE */}
            {activeTab === 'toolbar' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6"
              >
                {/* Simulated Floating Toolbar Showcase */}
                <Card className="p-6 border-brand-500/10 bg-[#0c131d] space-y-5 relative">
                  <div className="absolute top-2.5 left-3 px-2 py-0.5 rounded bg-[#18C29C]/10 text-[#18C29C] border border-[#18C29C]/10 text-[9px] font-mono leading-none">
                    RIYADA SELLER TOOLBAR v22
                  </div>

                  <div className="border-b border-white/5 pb-2.5 text-right">
                    <h3 className="text-xs font-black text-white">محاكاة شريط أدوات البائع بالمتصفح</h3>
                    <p className="text-[10px] text-white/40 leading-relaxed">يركب هذا الشريط أسفل متصفحك للقيام بالإجراءات السريعة ومقارنة أسعار المنتجات في 58 ولاية فوراً.</p>
                  </div>

                  {/* 2.1 Price Matching comparison simulator */}
                  <div className="p-4 rounded-xl bg-black/25 border border-white/5 space-y-3">
                    <span className="text-[9px] text-[#18C29C] font-extrabold uppercase tracking-wider block">أداة تحديد مقارنة الأسعار في الجزائر</span>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="space-y-1">
                        <label className="text-[9px] text-white/40">المنتج للمقارنة:</label>
                        <input 
                          type="text" 
                          value={priceItemName}
                          onChange={e => setPriceItemName(e.target.value)}
                          className="w-full bg-[#121620] border border-white/10 rounded-lg p-2 text-xs text-white font-bold"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] text-white/40">الولاية المستهدفة:</label>
                        <select 
                          value={priceWilaya}
                          onChange={e => setPriceWilaya(e.target.value)}
                          className="w-full h-9 bg-[#121620] border border-white/10 rounded-lg px-2 text-xs text-white"
                        >
                          {ALGERIAN_WILAYAS.map(w => (
                            <option key={w.id} value={w.name}>{w.name}</option>
                          ))}
                        </select>
                      </div>
                      <div className="flex items-end">
                        <Button 
                          onClick={handleCheckAlgPrice}
                          className="w-full bg-brand-500 hover:bg-brand-600 text-black text-[10px] font-black h-9"
                        >
                          مقارنة بالمتوسط الإقليمي 📊
                        </Button>
                      </div>
                    </div>

                    {/* Results matched panel */}
                    {checkedPriceResults && (
                      <motion.div 
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-[#121620] border border-brand-500/10 p-4 rounded-xl space-y-2.5 text-right font-sans"
                      >
                        <div className="flex justify-between items-center text-xs">
                          <strong className="text-white">{checkedPriceResults.itemName}</strong>
                          <span className="text-brand-400 bg-brand-400/5 px-2 py-0.5 rounded text-[9px]">مؤشر ولاية {checkedPriceResults.wilaya}</span>
                        </div>

                        <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-center pt-2 border-t border-white/5">
                          <div className="p-2 bg-black/30 rounded-lg">
                            <span className="text-[8px] text-white/30 block">أقل بيع مرصود</span>
                            <span className="text-emerald-400 font-bold block mt-0.5">{formatDZD(checkedPriceResults.minObserved)}</span>
                          </div>
                          <div className="p-2 bg-black/45 rounded-lg border border-brand-500/10">
                            <span className="text-[8px] text-brand-400 font-bold block">المتوسط المعتمد</span>
                            <span className="text-white font-extrabold block mt-0.5">{formatDZD(checkedPriceResults.averageWilayaPrice)}</span>
                          </div>
                          <div className="p-2 bg-black/30 rounded-lg">
                            <span className="text-[8px] text-white/30 block">أقصى بيع مرصود</span>
                            <span className="text-rose-400 font-bold block mt-0.5">{formatDZD(checkedPriceResults.maxObserved)}</span>
                          </div>
                        </div>

                        <div className="text-[10px] flex justify-between items-center bg-black/20 p-2.5 rounded-lg text-white/70">
                          <span>{checkedPriceResults.alertMsg}</span>
                          <span className="font-mono text-brand-400 text-xs font-black">الطلب: {checkedPriceResults.demandScore}%</span>
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* 2.2 Backup Export / Import storage */}
                  <div className="p-4 rounded-xl bg-black/25 border border-white/5 space-y-3">
                    <span className="text-[9px] text-[#18C29C] font-extrabold uppercase tracking-wider block">أداة الحفظ والتصدير الخارجي المشفر (Local State Backup)</span>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* Export block */}
                      <div className="p-3 bg-[#111924] rounded-xl border border-white/5 flex flex-col justify-between whitespace-normal text-right gap-3">
                        <div className="space-y-1">
                          <strong className="text-[10px] text-white block">تحرير نسخة احتياطية من متجرك (Export)</strong>
                          <p className="text-[9px] text-white/40 leading-relaxed">تقوم هذه الأداة بضغط وتجميع كافة سلعك وإعداداتك محلياً لنسخها في ملف نصي كإجراء وقائي.</p>
                        </div>
                        <Button
                          onClick={handleExportStateString}
                          className="bg-brand-500 text-black text-[10px] font-black w-full h-8 flex items-center justify-center gap-1.5"
                        >
                          <Download className="w-3.5 h-3.5" />
                          توليد وتشفير شفرة التصدير 💾
                        </Button>

                        {backupKey && (
                          <div className="text-[9px] font-mono text-[#18C29C] bg-black/40 p-2 rounded break-all max-h-16 overflow-y-auto">
                            {backupKey}
                          </div>
                        )}
                      </div>

                      {/* Import block */}
                      <div className="p-3 bg-[#111924] rounded-xl border border-white/5 flex flex-col justify-between text-right gap-3">
                        <div className="space-y-1">
                          <strong className="text-[10px] text-white block">استعادة النسخة وتلقين مخزن ريادة (Import)</strong>
                          <p className="text-[9px] text-white/40 leading-relaxed">ألصق شفرة النسخة لتأشير واستعادة معروضاتك وإعدادات المتجر في ثوانٍ معدودة.</p>
                        </div>
                        
                        <input 
                          type="text" 
                          placeholder="مثال: eyJ3b3Jrc3BhY2VJZCI6InNpbSIsInRpbWVzdGFtcCI6MTY4..."
                          value={importString}
                          onChange={e => setImportString(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-[9px] font-mono text-white outline-none"
                        />

                        <Button
                          onClick={handleImportStateString}
                          className="bg-white/10 hover:bg-white/15 text-white text-[10px] font-bold w-full h-8 flex items-center justify-center gap-1.5 border border-white/5"
                        >
                          <Upload className="w-3.5 h-3.5" />
                          استرداد مسودة التجميع 🔗
                        </Button>
                      </div>

                    </div>
                  </div>
                </Card>
              </motion.div>
            )}

            {/* TAB 3: PWA & OPEN IN NEW TAB EXTENSION */}
            {activeTab === 'pwa' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="space-y-6 animate-fade-in"
              >
                <Card className="p-6 border-cyan-500/20 bg-[#070f19] space-y-6 relative overflow-hidden">
                  <div className="absolute -top-12 -left-12 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl"></div>
                  
                  <div className="border-b border-white/5 pb-3 text-right">
                    <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-0.5 rounded text-[9px] font-black uppercase inline-block mb-2">
                      PWA & Independent Tab Gateway
                    </span>
                    <h3 className="text-sm font-black text-white">تحرير المنصة من إطارات المعاينة (Iframe Bypass & Speed booster)</h3>
                    <p className="text-[10px] text-white/50 leading-relaxed mt-1">
                      نظراً لأن بعض بيئات التطوير تقوم بحمل التطبيق داخل إطار معزول (iFrame)، فإن بعض واجهات المتصفح المتقدمة مثل (نظام بريدي موب، ومصادقة الدفع، والكاميرا لمسح الباركود، وتخزين الكوكيز المشترك) قد تواجه قيوداً أمنية.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    
                    {/* Content */}
                    <div className="space-y-3.5 text-right font-sans">
                      <h4 className="text-xs font-bold text-cyan-400 flex items-center justify-end gap-1.5">
                        <span>ميزات الفتح في تبويب مستقل:</span>
                        <Sparkles className="w-4 h-4 text-cyan-400" />
                      </h4>
                      
                      <ul className="space-y-2 text-[10px] text-white/70">
                        <li className="flex items-center justify-end gap-1.5">
                          <span>تصفح خالي تماماً من قيود الأمان لمتصفحات الجيل الثالث</span>
                          <span className="w-1.5 h-1.5 bg-[#18C29C] rounded-full"></span>
                        </li>
                        <li className="flex items-center justify-end gap-1.5">
                          <span>دعم تفعيل وضع ملء الشاشة وتجربة متجر حقيقي متكامل</span>
                          <span className="w-1.5 h-1.5 bg-[#18C29C] rounded-full"></span>
                        </li>
                        <li className="flex items-center justify-end gap-1.5">
                          <span>سرعة تحميل فائقة وتفعيل التخزين المؤقت العضوي (PWA)</span>
                          <span className="w-1.5 h-1.5 bg-[#18C29C] rounded-full"></span>
                        </li>
                        <li className="flex items-center justify-end gap-1.5">
                          <span>تكامل تام مع شريط أدوات الكشط وملحقات المتصفح</span>
                          <span className="w-1.5 h-1.5 bg-[#18C29C] rounded-full"></span>
                        </li>
                      </ul>

                      <div className="pt-2">
                        <Button 
                          onClick={() => {
                            window.open(window.location.origin + window.location.pathname, '_blank');
                          }}
                          className="w-full bg-cyan-500 hover:bg-cyan-600 text-black text-xs font-black py-4 h-11 flex items-center justify-center gap-2 rounded-xl shadow-lg shadow-cyan-500/10 transition-all"
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>فتح ريادة الآن في تبويب خارجي مستقل 🚀</span>
                        </Button>
                      </div>
                    </div>

                    {/* Quick phone preview QR */}
                    <div className="bg-black/40 border border-white/5 p-4 rounded-2xl flex flex-col items-center justify-center gap-3.5 text-center">
                      <span className="text-[9px] text-white/40 block">امسح الكود لفتح المتجر بهاتفك المحمول</span>
                      <div className="p-3 bg-white rounded-2xl">
                        <QRCodeSVG value={window.location.origin + window.location.pathname} size={120} />
                      </div>
                      <span className="text-[10px] font-mono text-cyan-400 break-all leading-normal max-w-xs block">
                        {window.location.origin + window.location.pathname}
                      </span>
                    </div>

                  </div>

                </Card>
              </motion.div>
            )}

          </AnimatePresence>

        </div>

        {/* RIGHT QUICK BAR: VISUAL STATUS, SHORTCUTS AND FAQ */}
        <div className="space-y-6">
          
          <Card className="p-5 border-white/5 bg-[#0e141c] space-y-4 text-right">
            <h3 className="text-xs font-bold text-white flex items-center gap-1 border-b border-white/5 pb-2">
              <Settings className="w-5 h-5 text-[#18C29C]" />
              <span>تعليمات التكامل والهيكل الذاتي</span>
            </h3>

            <div className="space-y-3 font-sans text-[10px] text-white/70 leading-relaxed">
              <p>
                تم تخطيط شريط ريادة v22 كـ <strong>Companion Plug</strong> ليتصرف كخادم كشط داخلي يحمي الخصوصية. 
              </p>
              <div className="p-3 rounded-lg bg-black/20 border border-white/5 text-[9px] text-[#18C29C] space-y-1">
                <div>✓ <b>لا توجد ملفات تعريف ارتباط خارجية</b></div>
                <div>✓ <b>تدرج المعروضات محلياً بـ IndexedDB</b></div>
                <div>✓ <b>تشغيل PWA أونلاين وتأليف في وضع غير متصل</b></div>
              </div>
              <p className="text-white/44">
                تستطيع استخدام هذه الأداة لتجهيز مخزنك وتصديره لإعادة استيراده لاحقاً بمرونة كاملة في حال مسح المتصفح.
              </p>
            </div>
          </Card>

        </div>

      </div>

      {/* FLYER/POSTER GENERATED OVERLAY MODAL */}
      <AnimatePresence>
        {showPosterModal && generatedPoster && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-gradient-to-tr from-[#121622] via-[#0D101A] to-[#121622] border border-brand-500/20 text-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl relative p-6 text-center space-y-6 flex flex-col items-center"
            >
              <div className="space-y-1">
                <span className="text-[#18C29C] bg-brand-500/10 px-2 py-0.5 rounded text-[8px] font-black uppercase">
                  RIYADA PROMOTIONAL VIRAL FLYER
                </span>
                <h4 className="text-sm font-bold text-white leading-snug mt-1">{generatedPoster.title}</h4>
              </div>

              {/* Poster Card design container */}
              <div className="w-64 bg-white text-gray-900 rounded-2xl p-4 flex flex-col items-center gap-3.5 shadow-md">
                <div className="text-center">
                  <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wide block">سوق ريادة الجزائري</span>
                  <strong className="text-sm block text-[#151c28] mt-0.5">{generatedPoster.title}</strong>
                </div>

                {/* QR SVG generated */}
                <div className="p-2.5 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-center">
                  <QRCodeSVG value={generatedPoster.qrValue} size={110} />
                </div>

                <div className="w-full flex justify-between items-center text-xs font-mono font-bold bg-gray-50 px-3 py-2 rounded-xl border border-gray-100">
                  <span className="text-gray-400">ولايـة: {generatedPoster.wilaya}</span>
                  <span className="text-emerald-500 font-black">{generatedPoster.price} دج</span>
                </div>

                <p className="text-[8px] text-gray-400 text-center leading-normal">
                  امسح الكود لزيارة المتجر وطلب السلعة عبر بريدي موب كلياً من متصفحك!
                </p>
              </div>

              {/* Close and actions on modal */}
              <div className="w-full grid grid-cols-2 gap-3 mt-4">
                <Button 
                  onClick={() => {
                    success('تم تنزيل البوستر بنجاح 🖼️', 'تم توليد الصورة وإرسالها للتخزين بجهازك.');
                    setShowPosterModal(false);
                  }}
                  className="bg-brand-500 text-black text-[10px] font-black h-9"
                >
                  الحصول على الملصق 💾
                </Button>
                <Button 
                  onClick={() => setShowPosterModal(false)}
                  className="bg-white/5 hover:bg-white/10 text-white border border-white/5 text-[10px] font-bold h-9"
                >
                  الرجوع
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
