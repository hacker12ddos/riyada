import React from 'react';
import { ShieldCheck, Heart, Eye, Target, Users } from 'lucide-react';
import { Card } from '../components/ui/Card';

export default function About() {
  return (
    <div className="max-w-4xl mx-auto space-y-12 py-6">
      <div className="text-center space-y-4">
        <div className="inline-flex p-3 bg-brand-500/10 rounded-2xl border border-brand-500/20 text-[#18C29C] mb-2">
          <ShieldCheck className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-extrabold text-white sm:text-4xl">
          ريادة • نظام تشغيل التجارة الجزائري الجديد
        </h1>
        <p className="text-sm text-white/60 max-w-2xl mx-auto leading-relaxed">
          ريادة هي منصة سيادية لامركزية بالكامل ومبنية محلياً لتمكين الشركات الحرفية، المتاجر المصغرة، والخدمات الحرة بالجزائر من الازدهار الرقمي دون قيود أو عمولات وسيطة.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 bg-[#0E141C] border border-white/5 space-y-3">
          <div className="flex items-center gap-3 text-[#18C29C]">
            <Target className="w-6 h-6" />
            <h3 className="text-lg font-bold text-white">رؤيتنا (Vision)</h3>
          </div>
          <p className="text-xs text-white/50 leading-relaxed">
            الوصول إلى تجارة رقمية لامركزية حقيقية بالجزائر، تفكك الاحتكار وتجعل السوق مفتوحاً بالكامل لكل تاجر أو مقدم خدمة من الـ 58 ولاية، وبناء بنية تحتية رقمية تدار كلياً من المتصفح دون الحاجة لخوادم وسيطة تتحكم برأس المال أو تفرض رسوماً تعجيزية.
          </p>
        </Card>

        <Card className="p-6 bg-[#0E141C] border border-white/5 space-y-3">
          <div className="flex items-center gap-3 text-[#18C29C]">
            <Eye className="w-6 h-6" />
            <h3 className="text-lg font-bold text-white">رسالتنا (Mission)</h3>
          </div>
          <p className="text-xs text-white/50 leading-relaxed">
            تمكين كل بائع، صانع تقليدي، ومحترف خدمات في الجزائر من إطلاق متجر رقمي متكامل الهوية مزود بأدوات احترافية للتقييم، الفوترة، إدارة المخازن وتتبع الأرباح وإدارة الطلبيات بضمانات الثقة والأمان الرقمي خلال دقائق معدودة وبأبسط الموارد الذاتية.
          </p>
        </Card>
      </div>

      <div className="space-y-6">
        <h2 className="text-xl font-bold text-white text-center">المبادئ الأساسية الحاكمة لريادة</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-[#0E141C] border border-white/5 text-center space-y-2">
            <span className="text-xl font-bold text-[#18C29C] block">01</span>
            <h4 className="text-sm font-bold text-white">ثقة كليّة بالبائعين</h4>
            <p className="text-[11px] text-white/50 leading-relaxed">
              تعتمد ريادة على حساب نقاط الثقة وتقارير التعليقات الحقيقية الناتجة عن تعاملات الزبائن لتطهير السوق ذاتياً وحظر المنتهكين تدريجياً.
            </p>
          </div>
          <div className="p-5 rounded-2xl bg-[#0E141C] border border-white/5 text-center space-y-2">
            <span className="text-xl font-bold text-[#18C29C] block">02</span>
            <h4 className="text-sm font-bold text-white">شفافية الدفع والتوريد</h4>
            <p className="text-[11px] text-white/50 leading-relaxed">
              تنظيم تدفق التحصيل بآليات توثيق الحوالات CCP وتكامل Chargily المباشر لحفظ الحقوق وتسهيل التدقيق دون تجميد أو تأخير مالي.
            </p>
          </div>
          <div className="p-5 rounded-2xl bg-[#0E141C] border border-white/5 text-center space-y-2">
            <span className="text-xl font-bold text-[#18C29C] block">03</span>
            <h4 className="text-sm font-bold text-white">استقلالية المنصة وتجردها</h4>
            <p className="text-[11px] text-white/50 leading-relaxed">
              ريادة لا تلعب دور الوكيل أو المستفيد المباشر ولا تحتجّ بملكية المعاملات، تظل دائماً منصة حيادية ميسّرة للعمليات بين البائع والمشتري.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-[#151C26] border border-[#18C29C]/10 rounded-3xl p-6 text-center space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">فلسفة التخلص من الوسطاء (Zero-Middleman Philosophy)</h3>
        <p className="text-xs text-white/60 leading-relaxed max-w-2xl mx-auto">
          نحن نؤمن بأن الحرفيين والشباب المبتكرين في الجزائر هم قاطرة التنمية الحقيقية. عندما تنعدم العمولات ويتحول التسويق الرقمي وبناء الواجهات ليكون حراً بالكامل ومحفوظاً كلياً باسم التاجر داخل جهازه الشخصي (IndexedDB)، تندثر أسعار السمسرة وتزداد جودة السلع وتنتقل القيمة لتعود بالنفع مباشرة للمواطن والاقتصاد الوطني.
        </p>
      </div>
    </div>
  );
}
