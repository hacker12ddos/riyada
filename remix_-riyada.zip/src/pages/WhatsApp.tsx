import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { 
  MessageSquare, 
  User, 
  Plus, 
  Send, 
  Smartphone, 
  CheckCircle2, 
  XSquare, 
  Clock, 
  DollarSign, 
  MessageCircle, 
  ArrowLeftRight,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { formatDZD } from '../lib/utils';
import { useWorkspace } from '../contexts/WorkspaceContext';
import { useToast } from '../contexts/ToastContext';
import { getNegotiationThreads, saveNegotiationThread, NegotiateThread } from '../lib/threads';

export default function WhatsAppEngine() {
  const { activeWorkspace } = useWorkspace();
  const { success, error } = useToast();
  const [threads, setThreads] = useState<NegotiateThread[]>([]);
  const [selectedThread, setSelectedThread] = useState<NegotiateThread | null>(null);
  
  // Interactive message state
  const [replyText, setReplyText] = useState('');
  const [counterOffer, setCounterOffer] = useState('');

  useEffect(() => {
    loadThreads();
  }, [activeWorkspace]);

  const loadThreads = () => {
    const all = getNegotiationThreads();
    // Filter threads that belong to current workspace
    const workspaceThreads = all.filter(t => t.vendorId === activeWorkspace?.id || !t.vendorId);
    // Sort by last update first
    workspaceThreads.sort((a, b) => b.updatedAt - a.updatedAt);
    setThreads(workspaceThreads);

    // Keep active selection in sync
    if (selectedThread) {
      const updated = workspaceThreads.find(t => t.id === selectedThread.id);
      if (updated) setSelectedThread(updated);
    }
  };

  const handleSendReply = (customText?: string, customOfferPrice?: number) => {
    if (!selectedThread) return;
    const msgText = customText || replyText;
    if (!msgText && !customOfferPrice) return;

    const updatedMessages = [
      ...selectedThread.messages,
      {
        id: crypto.randomUUID(),
        sender: 'seller' as const,
        text: msgText || `عرضت سعراً مقابلاً قدره ${formatDZD(customOfferPrice || 0)}`,
        timestamp: Date.now(),
        offerPrice: customOfferPrice
      }
    ];

    const updated: NegotiateThread = {
      ...selectedThread,
      messages: updatedMessages,
      status: customOfferPrice ? 'negotiation' : selectedThread.status,
      sellerOfferPrice: customOfferPrice || selectedThread.sellerOfferPrice,
    };

    saveNegotiationThread(updated);
    if (!customText) setReplyText('');
    setCounterOffer('');
    loadThreads();
    success('تم الإرسال', 'تم إرسال ردك وعرضك المقابل للمشتري عبر نظام ريادة الداخلي.');
  };

  const handleSetStatus = (newStatus: NegotiateThread['status']) => {
    if (!selectedThread) return;
    const textNote = newStatus === 'deal_accepted' 
      ? '✓ تهانينا! وافق البائع على السعر المقترح وتم إبرام الصفقة بنجاح.' 
      : '✕ تم رفض العرض المقترح أو إغلاق التفاوض من قبل البائع.';
      
    const updatedMessages = [
      ...selectedThread.messages,
      {
        id: crypto.randomUUID(),
        sender: 'seller' as const,
        text: textNote,
        timestamp: Date.now()
      }
    ];

    const updated: NegotiateThread = {
      ...selectedThread,
      status: newStatus,
      messages: updatedMessages
    };

    saveNegotiationThread(updated);
    loadThreads();
    success('تحديث الصفقة', newStatus === 'deal_accepted' ? 'تم قبول الصفقة وتأكيد السعر!' : 'تم إغلاق المفاوضات.');
  };

  const getStatusLabelColor = (status: string) => {
    switch (status) {
      case 'initiated': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
      case 'offer_sent': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'negotiation': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'deal_accepted': return 'bg-emerald-500/10 text-[#18C29C] border-emerald-500/20';
      case 'deal_rejected': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      default: return 'bg-white/10 text-white/50 border-white/20';
    }
  };

  const getStatusTextLabel = (status: string) => {
    switch (status) {
      case 'initiated': return 'استفسار أولي';
      case 'offer_sent': return 'عرض مالي مستلم';
      case 'negotiation': return 'تفاوض مستمر';
      case 'deal_accepted': return 'مقبول ومؤكد';
      case 'deal_rejected': return 'مرفوض/ملغي';
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">مركز صفقات ريادة والمحادثات الآمنة 💬</h1>
          <p className="text-white/50 text-sm">تفاوض، وافق على العروض، وتواصل بالكامل مع المشترين داخل المنصة دون وسيط.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Threads List */}
        <div className="lg:col-span-5 space-y-4">
          <Card className="p-4 bg-[#0E141C] border border-white/10">
            <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#18C29C]" />
              صندوق المراسلات والصفقات ({threads.length})
            </h2>

            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {threads.map((t) => {
                const latestMsg = t.messages[t.messages.length - 1];
                return (
                  <div
                    key={t.id}
                    onClick={() => {
                      setSelectedThread(t);
                    }}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      selectedThread?.id === t.id 
                        ? 'bg-gradient-to-r from-[#18C29C]/10 to-transparent border-[#18C29C]' 
                        : 'bg-[#070A0F] border-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-1.5">
                      <div className="space-y-0.5">
                        <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                          {t.buyerName}
                          <span className="text-[9px] text-white/30 font-mono">({t.id})</span>
                        </h4>
                        <span className="text-[10px] text-white/40 block">المنتج: {t.productName}</span>
                      </div>
                      <span className={`text-[9px] px-2 py-0.5 rounded border ${getStatusLabelColor(t.status)}`}>
                        {getStatusTextLabel(t.status)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-[11px] text-white/60">
                      <p className="truncate max-w-[180px] text-white/50">{latestMsg?.text || 'لا توجد رسائل الحين'}</p>
                      {t.buyerOfferPrice && (
                        <span className="font-mono text-[#18C29C] font-semibold">
                          عرضه: {formatDZD(t.buyerOfferPrice)}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}

              {threads.length === 0 && (
                <div className="text-center py-16 space-y-3">
                  <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mx-auto text-white/30">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <h4 className="text-xs font-bold text-white">لا توجد مفاوضات رقمية حتى الآن</h4>
                  <p className="text-[10px] text-white/40 leading-relaxed max-w-sm mx-auto">
                    بمجرد أن يستعين زبائن ومرتادو المنصة بـ "نموذج التفاوض والمراسلة الفوري" على سلعك، ستتلقى الإشعارات والصفقات هنا للرد المباشر بأسعارك المقابلة.
                  </p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Right Side: Chat Panel and Actions */}
        <div className="lg:col-span-7">
          {selectedThread ? (
            <Card className="bg-[#0E141C] border border-white/10 p-5 space-y-4">
              {/* Product brief info */}
              <div className="flex justify-between items-start border-b border-white/5 pb-3">
                <div className="space-y-1">
                  <span className="text-[10px] bg-[#18C29C]/10 text-[#18C29C] px-2 py-0.5 rounded">رقم الصفقة: {selectedThread.id}</span>
                  <h3 className="text-sm font-bold text-white">{selectedThread.productName}</h3>
                  <div className="flex items-center gap-3 text-xs text-white/50">
                    <span>السعر الأصلي المكلّف:</span>
                    <span className="font-mono font-bold text-white">{formatDZD(selectedThread.productPrice)}</span>
                  </div>
                </div>

                {/* Status indicator Actions */}
                <div className="text-left space-y-1.5 shrink-0">
                  <span className={`text-xs px-2.5 py-1 rounded-full border ${getStatusLabelColor(selectedThread.status)}`}>
                    {getStatusTextLabel(selectedThread.status)}
                  </span>
                  
                  {/* Option to export to Whatsapp */}
                  <div className="pt-2">
                    <Button 
                      onClick={() => {
                        const msg = `السلام عليكم، رداً على تفاوضك في ريادة بخصوص: "${selectedThread.productName}"...`;
                        window.open(`https://wa.me/${selectedThread.buyerPhone}?text=${encodeURIComponent(msg)}`, '_blank');
                      }}
                      className="text-[10px] bg-[#25D366] hover:bg-[#128C7E] text-white h-7 px-2 border-0 gap-1 flex items-center justify-center font-bold"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      التحويل لواتساب البائع
                    </Button>
                  </div>
                </div>
              </div>

              {/* Chat Thread history container */}
              <div className="h-[250px] overflow-y-auto space-y-3 bg-[#070A0F] p-4 rounded-2xl border border-white/5 flex flex-col justify-end">
                <div className="overflow-y-auto space-y-3 pr-1">
                  {selectedThread.messages.map((m) => {
                    const isSeller = m.sender === 'seller';
                    return (
                      <div key={m.id} className={`flex ${isSeller ? 'justify-start' : 'justify-end'}`}>
                        <div className={`max-w-[85%] rounded-2xl p-3 text-xs ${isSeller ? 'bg-[#151C26] text-white rounded-tr-none border border-white/5' : 'bg-[#18C29C]/10 text-white rounded-tl-none border border-[#18C29C]/25'}`}>
                          <div className="text-[10px] text-white/40 mb-1 flex justify-between gap-4 font-mono">
                            <span>{isSeller ? 'أنت (البائع)' : selectedThread.buyerName}</span>
                            <span>{new Date(m.timestamp).toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          <p className="leading-relaxed">{m.text}</p>
                          {m.offerPrice && (
                            <div className="mt-1.5 pt-1 border-t border-white/5 text-[11px] font-bold text-[#18C29C] font-mono">
                              القيمة المشترطة: {formatDZD(m.offerPrice)}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Deal counter offer bar */}
              {selectedThread.status !== 'deal_accepted' && selectedThread.status !== 'deal_rejected' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#070A0F] p-4 rounded-xl border border-white/5">
                  <div className="space-y-1">
                    <span className="text-[10px] text-white/50 block">اقتراح عرض مالي مقابل (Counter Offer):</span>
                    <div className="flex gap-2">
                      <input 
                        type="number" 
                        placeholder="مثال: 4500 دج"
                        value={counterOffer}
                        onChange={e => setCounterOffer(e.target.value)}
                        className="w-full bg-[#0E141C] border border-white/10 rounded-lg px-3 py-1 text-xs text-white text-center font-mono focus:border-[#18C29C]"
                      />
                      <Button 
                        size="sm"
                        disabled={!counterOffer}
                        onClick={() => {
                          handleSendReply(`أقترح عليك كبائع سعراً مقابلاً قدره ${formatDZD(Number(counterOffer))}. ما رأيك؟`, Number(counterOffer));
                        }}
                        className="text-xs font-bold"
                      >
                         تقديم العرض المقابل
                      </Button>
                    </div>
                  </div>

                  <div className="flex flex-col justify-end gap-2">
                    <span className="text-[10px] text-white/50 block text-center">أو البت رسمياً في الصفقة الآن:</span>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleSetStatus('deal_accepted')}
                        className="flex-1 bg-[#18C29C] hover:opacity-90 text-black py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        قبول السعر وحجز الصفقة
                      </button>
                      <button 
                        onClick={() => handleSetStatus('deal_rejected')}
                        className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 py-2 rounded-lg text-xs font-bold border border-red-500/20"
                      >
                        رفض وإلغاء
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Regular message reply input bar */}
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="اكتب ردك للزبون هنا لتفصيل التوصيل أو الاستعلام..."
                  value={replyText}
                  onChange={e => setReplyText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleSendReply();
                  }}
                  className="flex-1 bg-[#070A0F] border border-white/10 rounded-xl px-4 py-2 text-xs text-white outline-none focus:border-[#18C29C]"
                />
                <Button 
                  onClick={() => handleSendReply()}
                  className="bg-[#18C29C] hover:opacity-90 text-black border-0 px-4"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ) : (
            <Card className="p-8 text-center bg-[#0E141C] border border-white/10 text-white/40 select-none py-28 space-y-3">
              <Sparkles className="w-10 h-10 text-brand-500 mx-auto opacity-50 animate-pulse" />
              <h3 className="text-sm font-bold text-white">اختر محادثة من القائمة لعرض تاريخ المفاوضات</h3>
              <p className="text-xs text-white/40 max-w-sm mx-auto">
                لوحة الردور الذكية تمنحك إمكانية تقديم شروط السلعة، تخفيض واقتناص السعر، وقبول صفقات ريادة بمرونة كاملة في الوقت الحقيقي.
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
