/**
 * RIYADA SYSTEM SECURE WEBHOOK CHANNEL - CHARGILY PAY V2
 * Receives and cryptographically verifies incoming webhook notifications from Chargily Pay V2.
 * Strictly enforces signature checking, idempotency, and the payment state machine.
 */

import { updateOrderStatus } from '../../lib/services/ordersService';
import { sentryServer } from '../../lib/sentryServer';
import { logTelemetry, publish } from '../../lib/infrastructure';
import { verifyWebhookSignature } from '../../lib/payments/verifySignature';
import { isProcessed, markAsProcessed } from '../../lib/payments/idempotency';
import { savePaymentEvent } from '../../lib/db/paymentEvents';
import { enqueueRetry } from '../../lib/payments/retryQueue';
import { getDB } from '../../lib/db';

/**
 * Route handler simulation processor to verify and record completed transactions.
 * Fully migrated to Chargily Pay V2 standards.
 */
export async function processChargilyWebhook(
  rawBody: string,
  signatureHeader: string
): Promise<{ success: boolean; message: string; statusCode: number }> {
  try {
    // 1. Strict Cryptographic Signature Gate Check
    const signatureValid = await verifyWebhookSignature(rawBody, signatureHeader);
    if (!signatureValid) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'error',
        message: '[SECURITY_ALERT] Invalid webhook signature detected! Aborting transaction processing.'
      });
      sentryServer.captureRealtimeError('webhook-unverified-access', 'connect', new Error('Signature mismatch on webhook callback.'));
      return { success: false, message: 'توقيع التحقق غير صالح من خوادم Chargily PAY V2.', statusCode: 401 };
    }

    const payload = JSON.parse(rawBody);
    
    // Parse the modern Chargily Pay V2 Event Wrapper if present, else fallback
    const eventType = payload.type || 'checkout.paid';
    const data = payload.data || payload;

    const checkoutId = data.id;
    const checkoutStatus = data.status;
    const orderId = data.metadata?.orderId;
    const amount = data.amount;

    if (!checkoutId || !orderId) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'error',
        message: `[PAYMENT_ABUSE] Received malformed webhook payload content without transaction ID or order ID reference.`
      });
      return { success: false, message: 'محددات الطلبية أو المعالجة مشوهة في حزمة البيانات.', statusCode: 400 };
    }

    // 2. Pre-save raw payload as an audited event BEFORE running transitions
    // Store with the checkoutId as the key
    await savePaymentEvent({
      id: checkoutId,
      orderId,
      status: checkoutStatus,
      payload: rawBody
    });

    // 3. Prevent duplicate webhook replays using our Idempotency Lock
    if (isProcessed(checkoutId)) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'info',
        message: `[IDEMPOTENCY_BLOCK] Payment checkout ${checkoutId} already successfully processed. Skipping replay.`
      });
      return { success: true, message: 'الدفعة تمت معالجتها مسبقاً وتأمينها بنجاح.', statusCode: 200 };
    }

    // 4. Verify that the order actually exists in our Aiven Database source of truth
    const db = await getDB();
    const orderRecord = await db.get('orders', orderId);

    if (!orderRecord) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'error',
        message: `[PAYMENT_FRAUD_DETECTED] Webhook received for non-existent order registration ID: "${orderId}".`
      });
      sentryServer.captureApiError('/api/webhooks/chargily', new Error(`Unknown Order ID: ${orderId}`), payload);
      return { success: false, message: 'التحقق فشل: الطلب المدفوع غير مسجل بالنظام.', statusCode: 404 };
    }

    // 5. Prevent double payments on already paid Orders
    if (orderRecord.status === 'paid' || orderRecord.paymentStatus === 'PAID') {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'info',
        message: `[PAYMENT_SAFETY] Order "${orderId}" is already marked PAID. Double-credit processing aborted.`
      });
      markAsProcessed(checkoutId);
      return { success: true, message: 'الطلب مدفوع ومؤمن مسبقاً بقاعدة البيانات.', statusCode: 200 };
    }

    // 6. Action state machine modification only for successful payment confirmations
    if (checkoutStatus === 'paid' || eventType === 'checkout.paid') {
      markAsProcessed(checkoutId);

      // Transition order status with automated db update and retry safety enqueuer
      const success = await enqueueRetry(orderId, async () => {
        const orderToUpdate = await db.get('orders', orderId);
        if (orderToUpdate) {
          orderToUpdate.status = 'paid';
          orderToUpdate.paymentStatus = 'PAID';
          await db.put('orders', orderToUpdate);
          return true;
        }
        return false;
      });

      if (success) {
        // Disseminate real-time notification block
        await publish('payment_confirmed', { orderId, amount, transactionId: checkoutId });
        
        logTelemetry({
          source: 'AIVEN_POSTGRES',
          type: 'success',
          message: `[VERIFIED_PAYMENT_V2_SUCCESS] Webhook confirms payment ID ${checkoutId} for Order ${orderId}. Status updated to PAID.`
        });
        
        return { success: true, message: 'تم استلام وتفعيل الدفع ومزامنة البيانات كلياً بنجاح عبر بوابة V2.', statusCode: 200 };
      } else {
        throw new Error('Database updates timed out or locked during order status update.');
      }
    }

    // Handle failure notification if checkout fails - map to 'cancelled' status supported by DB & FAILED paymentStatus
    if (checkoutStatus === 'failed' || eventType === 'checkout.failed') {
      const success = await enqueueRetry(orderId, async () => {
        const orderToUpdate = await db.get('orders', orderId);
        if (orderToUpdate) {
          orderToUpdate.status = 'cancelled';
          orderToUpdate.paymentStatus = 'FAILED';
          await db.put('orders', orderToUpdate);
          return true;
        }
        return false;
      });

      if (success) {
        await publish('payment_failed', { orderId, transactionId: checkoutId });
        logTelemetry({
          source: 'AIVEN_POSTGRES',
          type: 'warning',
          message: `[PAYMENT_FAILED_RECEIVED] Webhook reports failed payment ID ${checkoutId} for Order ${orderId}.`
        });
      }
    }

    // Handle expired notification
    if (checkoutStatus === 'expired' || eventType === 'checkout.expired') {
      const success = await enqueueRetry(orderId, async () => {
        const orderToUpdate = await db.get('orders', orderId);
        if (orderToUpdate) {
          orderToUpdate.status = 'expired';
          orderToUpdate.paymentStatus = 'EXPIRED';
          await db.put('orders', orderToUpdate);
          return true;
        }
        return false;
      });

      if (success) {
        logTelemetry({
          source: 'AIVEN_POSTGRES',
          type: 'warning',
          message: `[PAYMENT_EXPIRED_RECEIVED] Webhook reports expired payment ID ${checkoutId} for Order ${orderId}.`
        });
      }
    }

    return { success: true, message: 'تلقينا إشعار عملية الدفع بنجاح.', statusCode: 200 };

  } catch (error: any) {
    sentryServer.captureApiError('/api/webhooks/chargily', error, { rawBody });
    return { success: false, message: error.message || 'خطأ تقني أثناء معالجة دفع الاستحقاق.', statusCode: 500 };
  }
}
