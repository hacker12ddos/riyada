/**
 * RIYADA API ENDPOINT - CREATE CHARGILY PAY V2 CHECKOUT
 * Creates secure checkout sessions for user orders.
 * Validates inputs, checks rate limits, and uses the backend-only secret key to sign checkouts.
 */

import { createCheckoutSession } from '../../lib/payments/chargilyPayClient';
import { countAndCheckRateLimit } from '../../lib/security/rateLimit';
import { sentryServer } from '../../lib/sentryServer';
import { logTelemetry } from '../../lib/infrastructure';
import { getDB } from '../../lib/db';

export interface CheckoutRequestPayload {
  orderId: string;
  amount: number;
  email?: string;
}

/**
 * Handles incoming checkout creations safely.
 * Implements strict Zero Trust and rate limiting defenses.
 */
export async function handleCreateCheckout(
  payload: CheckoutRequestPayload,
  clientIp: string
): Promise<{ success: boolean; data?: any; error?: string; statusCode: number }> {
  try {
    const { orderId, amount, email } = payload;

    // 1. Input sanitization and validity check
    if (!orderId || typeof orderId !== 'string') {
      return { success: false, error: 'معرّف الطلبية غير صالح أو مفقود.', statusCode: 400 };
    }
    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return { success: false, error: 'مبلغ الطلبية غير صالح.', statusCode: 400 };
    }

    // 2. Strict Rate Limiting on IP
    const limiter = countAndCheckRateLimit(`checkout_creation_${clientIp}`, 10, 60000); // Max 10 per minute
    if (!limiter.allowed) {
      return { success: false, error: limiter.message, statusCode: 429 };
    }

    // 3. Security check: Verifying order exists in Primary Database
    const db = await getDB();
    const orderRecord = await db.get('orders', orderId);

    if (!orderRecord) {
      logTelemetry({
        source: 'AIVEN_POSTGRES',
        type: 'error',
        message: `[SECURITY_WARN] Attempt to create checkout for unregistered order ID: "${orderId}"`
      });
      return { success: false, error: 'الطلب المحدد غير موجود بقاعدة البيانات.', statusCode: 404 };
    }

    // 4. Securely calling Chargily Pay V2
    const checkoutResult = await createCheckoutSession(orderId, amount, email);

    logTelemetry({
      source: 'AIVEN_POSTGRES',
      type: 'success',
      message: `[PAYMENT_INIT_SUCCESS] Registered Chargily checkout ID ${checkoutResult.id} for Order: "${orderId}"`
    });

    return {
      success: true,
      data: checkoutResult,
      statusCode: 200
    };

  } catch (error: any) {
    sentryServer.captureApiError('/api/payments/createCheckout', error, payload);
    return {
      success: false,
      error: 'حدث خطأ غير متوقع أثناء تكوين جلسة الدفع الآمنة.',
      statusCode: 500
    };
  }
}
